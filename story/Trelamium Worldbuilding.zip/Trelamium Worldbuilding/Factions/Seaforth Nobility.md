---
title: "Seaforth Nobility"
date: 2026-10-11
type: faction
status: canon
tags: [faction]
---

# Seaforth Nobility

*The noble class of Seaforth that refused Cthulhu the throne because of his common blood.*

Cthulhu's father, the king, belonged to this class. When the king died of an illness, a story spread that Cthulhu had killed him, and the nobility refused to crown a half-commoner.

## Connections

- **Rules:** [Seaforth](../Realms/Seaforth.md)
- **Rejected:** [Cthulhu](../Characters/Cthulhu.md)
- **Overthrown in:** [The Seaforth Revolution](../Timeline/The%20Seaforth%20Revolution.md) *(outcome unconfirmed)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
