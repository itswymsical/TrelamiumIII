---
title: "The Three Witches"
date: 2026-10-11
type: faction
status: concept
tags: [faction]
---

# The Three Witches

*Three women of great significance in Terraria's story, who created the souls inside the mechanical bosses: Malicia, Saraphine and Farewynn.*

From Gerjingle's August 2025 notes. Each witch created an energy, the Souls of Fright, Sight and Might that the mechanical bosses drop, and each is felt in her presence:

- [Malicia](../Characters/Malicia.md), the Witch of Fright: near her, people are engulfed in fear.
- [Saraphine](../Characters/Saraphine.md), the Witch of Sight: near her, people feel unprotected.
- [Farewynn](../Characters/Farewynn.md), the Witch of Might: near her, people feel empowered and proud, and inferior at the same time.

## Connections

- **Members:** [Malicia](../Characters/Malicia.md), [Saraphine](../Characters/Saraphine.md), [Farewynn](../Characters/Farewynn.md)
- **Created the souls of:** [The Mechanical Bosses](../Characters/The%20Mechanical%20Bosses.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
