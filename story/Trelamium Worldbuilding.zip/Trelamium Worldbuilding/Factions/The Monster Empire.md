---
title: "The Monster Empire"
date: 2026-10-11
type: faction
status: concept
tags: [faction]
---

# The Monster Empire

*The alliance of "monster"-harboring worlds that the Dryads branded unholy and that Queen Flaropha set out to destroy.*

In the August 2025 notes, the [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md) convinced the Royals of [Excellia](../Realms/Excellia.md) that the Monster Empire was "unholy". [Queen Flaropha](../Characters/Queen%20Flaropha.md) then set out to destroy the less "divine" worlds, betraying [The Underworld](../Realms/The%20Underworld.md), [Archaea](../Realms/Archaea.md), [Seaforth](../Realms/Seaforth.md) and others.

## Connections

- **Worlds:** [The Underworld](../Realms/The%20Underworld.md), [Archaea](../Realms/Archaea.md), [Seaforth](../Realms/Seaforth.md) *(inferred)*
- **Branded unholy by:** [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md)
- **Enemies:** [Excellia](../Realms/Excellia.md), [Queen Flaropha](../Characters/Queen%20Flaropha.md)
- **War:** [The Man and Monster War](../Timeline/The%20Man%20and%20Monster%20War.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
