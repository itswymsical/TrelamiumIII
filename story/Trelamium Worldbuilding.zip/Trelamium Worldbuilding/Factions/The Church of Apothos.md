---
title: "The Church of Apothos"
date: 2026-10-11
type: faction
status: canon
tags: [faction, antagonist]
aliases: ["The Alchemist Cult", "Church of Apathos", "The Cult"]
---

# The Church of Apothos

*The original alchemist cult and the true central antagonist: ancient Anthropos who worshipped the end of wanting and made the Trelamium God. Older and larger in scope than Cthulhu.*

The Church grew from the ancient [Anthropos](../Peoples/Anthropos.md). When the monolithic Anthropos first began to doubt their shared mythos, the skeptics formed a secret society, which leads to the Church *(inferred)*. After [The Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md), magick began to be worked through [Alchemy](../Magick%20and%20Systems/Alchemy.md), and everything the Hero does with alchemy echoes the Church's practice, though not its intention.

The Church did not worship the dark. It worshipped the end of wanting. Studying [Architecture](../Cosmology/Architecture.md), its members decided every wound begins with [Quality](../Cosmology/Quality.md) and sought to unmake it. In [Revelation](../Timeline/Revelation.md), one member completed the rite, emptied himself, and became the vessel [Iniki](../Characters/Iniki.md) fit: the [Trelamium God](../Characters/The%20Trelamium%20God.md).

**Goal:** not to eradicate light, but to become the subsuming overseer of reality: fold everything back into darkness and make a new [Vault](../Cosmology/The%20Vault.md) within itself.

**Relation to Cthulhu:** the [Assailant Crusade](The%20Assailant%20Crusade.md) serves the same end whether [Cthulhu](../Characters/Cthulhu.md) knows it or not. If he succeeds, Trelamium takes over regardless of what he wants.

## Connections

- **Formed from:** [Anthropos](../Peoples/Anthropos.md)
- **After:** [The Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md)
- **Era:** [Primordial Age III](../Timeline/Primordial%20Age%20III.md), [Revelation](../Timeline/Revelation.md)
- **Practiced:** [Alchemy](../Magick%20and%20Systems/Alchemy.md), [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Made:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)
- **Serves:** [Trelamium](../Cosmology/Trelamium.md), [Iniki](../Characters/Iniki.md)
- **Goal:** [The Vault](../Cosmology/The%20Vault.md)
- **Unknowing ally:** [The Assailant Crusade](The%20Assailant%20Crusade.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
