---
title: "The Assailant Crusade"
date: 2026-10-11
type: faction
status: canon
tags: [faction, antagonist]
aliases: ["Assailants", "The Crusade"]
---

# The Assailant Crusade

*Cthulhu's multidimensional empire of cultists, warriors and soldiers of every race. It serves Trelamium whether Cthulhu knows it or not.*

Cultists, warriors and soldiers of every shape, size, race and ethnicity, scattered across [Terraria](../Realms/Terraria.md) and other dimensions: the stormtroopers of Cthulhu's empire. "Assailants" is the umbrella term for all of them. They believe the crusade holds something for them. It doesn't: [Cthulhu](../Characters/Cthulhu.md) is manipulating them.

**Strongholds:** [The Corruption](../Realms/The%20Corruption.md), [The Crimson](../Realms/The%20Crimson.md) and the [Obsidian Forest](../Realms/Obsidian%20Forest.md), small fortresses and camps the player can fight for loot, likely with a mini-boss or two. The higher Assailants also send the [Goblin Army](The%20Goblin%20Army.md) to raid the Hero's town for resources and power.

**Ranks, lowest to highest:** [Fiends](Assailant%20Ranks/Fiends.md) → [Sinners](Assailant%20Ranks/Sinners.md) → [Disasters](Assailant%20Ranks/Disasters.md) → [Tragedies](Assailant%20Ranks/Tragedies.md) → [Honoraries](Assailant%20Ranks/Honoraries.md) → [The Elect](Assailant%20Ranks/The%20Elect.md) → [Paladins](Assailant%20Ranks/Paladins.md), with Cthulhu (the Moon Lord) above them all. The names grow less insulting and more imposing as they rise. A **Supreme** sits above the rank in their title and commands it: [Corithian](../Characters/Corithian.md) is the Supreme Fiend.

**Foot soldiers:** the Fiend-rank troops in the Corruption and Crimson camps are the [Soma Whisperer](Assailant%20Troops/Soma%20Whisperer.md), the [Null Herald](Assailant%20Troops/Null%20Herald.md) and the [Echo Knight](Assailant%20Troops/Echo%20Knight.md), combat types with no special lore. The pale gold and purple Assailants may get their own name, such as Grunts, and the one with a flail could be a boss. Gerjingle plans a Dark Souls feel for them.

**Driven off:** some worlds have fought the Crusade off. They aren't entirely safe, but the people who led those fights are honored as [Heroes of the Land](Heroes%20of%20the%20Land.md): [Dahlia](../Characters/Dahlia.md) in [Sylvanwalde](../Realms/Sylvanwalde.md) and [Eustace](../Characters/Eustace.md) in [Archaea](../Realms/Archaea.md). The Paladin [Nisha](../Characters/Nisha.md) completely destroyed the Elysians' world, [Elysia](../Realms/Elysia.md).

The [Void Whisperers](The%20Void%20Whisperers.md) helped spread Cthulhu's influence to the other worlds, and the foreword of the [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md) suggests the Assailants killed [John Substrate](../Characters/John%20Substrate.md).

## Connections

- **Led by:** [Cthulhu](../Characters/Cthulhu.md)
- **Born from:** [The Seaforth Revolution](../Timeline/The%20Seaforth%20Revolution.md)
- **Wields:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Top rank:** [Paladins](Assailant%20Ranks/Paladins.md): [Fullbone](../Characters/Fullbone.md), [Erahoka](../Characters/Erahoka.md), [Nisha](../Characters/Nisha.md), [Callisto](../Characters/Callisto.md)
- **Supremes:** [Corithian](../Characters/Corithian.md)
- **Members:** [Eosforos](../Characters/Eosforos.md), [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)
- **Troops:** [Soma Whisperer](Assailant%20Troops/Soma%20Whisperer.md), [Null Herald](Assailant%20Troops/Null%20Herald.md), [Echo Knight](Assailant%20Troops/Echo%20Knight.md)
- **Commands:** [The Goblin Army](The%20Goblin%20Army.md)
- **Strongholds:** [The Corruption](../Realms/The%20Corruption.md), [The Crimson](../Realms/The%20Crimson.md), [Obsidian Forest](../Realms/Obsidian%20Forest.md)
- **Targets:** [Terraria](../Realms/Terraria.md)
- **Driven off by:** [Heroes of the Land](Heroes%20of%20the%20Land.md) in [Sylvanwalde](../Realms/Sylvanwalde.md) and [Archaea](../Realms/Archaea.md)
- **Destroyed:** [Elysia](../Realms/Elysia.md)
- **Aided by:** [The Void Whisperers](The%20Void%20Whisperers.md)
- **Unknowingly serves:** [The Church of Apothos](The%20Church%20of%20Apothos.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
