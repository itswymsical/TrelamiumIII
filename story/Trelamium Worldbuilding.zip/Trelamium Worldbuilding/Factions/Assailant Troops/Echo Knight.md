---
title: "Echo Knight"
date: 2026-10-11
type: troop
status: canon
tags: [troop, assailant-crusade]
---

# Echo Knight

*A Fiend-rank Assailant fought in the Corruption and Crimson camps. A combat type with no special lore.*

## Connections

- **Rank:** [Fiends](../Assailant%20Ranks/Fiends.md)
- **Commanded by:** [Corithian](../../Characters/Corithian.md)
- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Found in:** [The Corruption](../../Realms/The%20Corruption.md), [The Crimson](../../Realms/The%20Crimson.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
