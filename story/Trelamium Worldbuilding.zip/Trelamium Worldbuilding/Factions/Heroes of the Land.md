---
title: "Heroes of the Land"
date: 2026-10-11
type: title
status: canon
tags: [title]
aliases: ["Hero of the Land", "Hero of Reality"]
---

# Heroes of the Land

*The title for those who led their worlds in fighting off Cthulhu's Assailant Crusade. Their worlds aren't entirely safe, but the Crusade has been warded off.*

Each hero is known as the hero of their land:

- [Dahlia](../Characters/Dahlia.md), hero of [Sylvanwalde](../Realms/Sylvanwalde.md).
- [Eustace](../Characters/Eustace.md), hero of [Archaea](../Realms/Archaea.md).

[The Hero](../Characters/The%20Hero.md) walks in their footsteps, first as the hero of [Terraria](../Realms/Terraria.md), and finally as the hero of reality when they stop [Iniki](../Characters/Iniki.md).

## Connections

- **Heroes:** [Dahlia](../Characters/Dahlia.md), [Eustace](../Characters/Eustace.md)
- **Becoming one:** [The Hero](../Characters/The%20Hero.md)
- **Fought:** [The Assailant Crusade](The%20Assailant%20Crusade.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
