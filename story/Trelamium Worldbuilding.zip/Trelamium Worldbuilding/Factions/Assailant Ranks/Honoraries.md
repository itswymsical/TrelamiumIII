---
title: "Honoraries"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Honoraries

*The fifth rank of the Assailant Crusade.*

Rank 5 of 7.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Next rank down:** [Tragedies](Tragedies.md)
- **Next rank up:** [The Elect](The%20Elect.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
