---
title: "Tragedies"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Tragedies

*The fourth rank of the Assailant Crusade.*

Rank 4 of 7.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Next rank down:** [Disasters](Disasters.md)
- **Next rank up:** [Honoraries](Honoraries.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
