---
title: "The Elect"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# The Elect

*The sixth rank of the Assailant Crusade, just below the Paladins.*

Rank 6 of 7.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Next rank down:** [Honoraries](Honoraries.md)
- **Next rank up:** [Paladins](Paladins.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
