---
title: "Disasters"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Disasters

*The third rank of the Assailant Crusade.*

Rank 3 of 7.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Next rank down:** [Sinners](Sinners.md)
- **Next rank up:** [Tragedies](Tragedies.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
