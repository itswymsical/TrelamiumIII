---
title: "Paladins"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Paladins

*The top rank of the Assailant Crusade, right below the Moon Lord. Four Paladins serve Cthulhu, each with private goals.*

Rank 7 of 7. Each Paladin has private goals. Cthulhu knows this and works to keep them from gaining the upper hand, so the top of the Crusade is a five-way power struggle.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Members:** [Fullbone](../../Characters/Fullbone.md), [Erahoka](../../Characters/Erahoka.md), [Nisha](../../Characters/Nisha.md), [Callisto](../../Characters/Callisto.md)
- **Next rank down:** [The Elect](The%20Elect.md)
- **Answers to:** [Cthulhu](../../Characters/Cthulhu.md)

Sources: [Lore Bible](../../Sources/Lore%20Bible.md) · [Latest Retcons](../../Sources/Latest%20Retcons.md)
