---
title: "Sinners"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Sinners

*The second rank of the Assailant Crusade.*

Rank 2 of 7.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Next rank down:** [Fiends](Fiends.md)
- **Next rank up:** [Disasters](Disasters.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md)
