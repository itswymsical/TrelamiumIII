---
title: "Fiends"
date: 2026-10-11
type: rank
status: canon
tags: [rank, assailant-crusade]
---

# Fiends

*The lowest rank of the Assailant Crusade, commanded by the Supreme Fiend Corithian. Fiend troops hold the Corruption and Crimson camps.*

Rank 1 of 7. The rank names start insulting here and grow more imposing toward the top. The camps in [The Corruption](../../Realms/The%20Corruption.md) and [The Crimson](../../Realms/The%20Crimson.md) are held by Fiend types: plain combat troops with no special lore.

## Connections

- **Faction:** [The Assailant Crusade](../The%20Assailant%20Crusade.md)
- **Commanded by:** [Corithian](../../Characters/Corithian.md), the Supreme Fiend
- **Troop types:** [Soma Whisperer](../Assailant%20Troops/Soma%20Whisperer.md), [Null Herald](../Assailant%20Troops/Null%20Herald.md), [Echo Knight](../Assailant%20Troops/Echo%20Knight.md)
- **Next rank up:** [Sinners](Sinners.md)

Sources: [Latest Retcons](../../Sources/Latest%20Retcons.md) · [Legacy Content](../../Sources/Legacy%20Content.md)
