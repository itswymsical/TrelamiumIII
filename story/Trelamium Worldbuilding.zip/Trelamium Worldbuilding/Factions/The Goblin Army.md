---
title: "The Goblin Army"
date: 2026-10-11
type: faction
status: canon
tags: [faction, antagonist]
aliases: ["Goblin tribe"]
---

# The Goblin Army

*The war band of an unnamed goblin tribe that hates technology and wants power. On the Assailants' orders, it raids the Hero's town for resources.*

The tribe joined the Assailants for power, and the [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md) blames its "archaic mindset". The higher Assailants send it to Terraria to strip the Hero's town of resources. It brings the Tinkerer along, tied to a stake for execution, and once the army is defeated the Hero can free him.

## Connections

- **People:** [Goblins](../Peoples/Goblins.md)
- **Ordered by:** [The Assailant Crusade](The%20Assailant%20Crusade.md)
- **Raids:** [Terraria](../Realms/Terraria.md)
- **Captive:** [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
