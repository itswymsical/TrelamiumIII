---
title: "The Void Whisperers"
date: 2026-10-11
type: faction
status: concept
tags: [faction]
---

# The Void Whisperers

*Followers of Apothos, which its first followers called the Void Hymn. They helped spread Cthulhu's influence to the other worlds; Yakvala is one of their remnants.*

In the August 2025 notes, Apothos grew "out of order" in the era before the Great War, while the [Archivers](../Peoples/Archivers.md) were rekindling Terraria's survival. Its first followers called it the Void Hymn, before Cthulhu's rise. The Void Whisperers were key to spreading [Cthulhu](../Characters/Cthulhu.md)'s influence to the other worlds.

## Connections

- **Follow:** [Apothos](../Magick%20and%20Systems/Apothos.md), as the Void Hymn
- **Aided:** [Cthulhu](../Characters/Cthulhu.md), [The Assailant Crusade](The%20Assailant%20Crusade.md)
- **Remnants include:** [Yakvala](../Characters/Yakvala.md)
- **Era:** before [The Ancient Great War](../Timeline/The%20Ancient%20Great%20War.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
