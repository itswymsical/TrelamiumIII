---
title: "Kraken"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Kraken

*A wanderer type, like Sonder. Not yet defined beyond that.*

In the mod the Kraken greets the Hero with a startled "Huh? Hello there."

## Connections

- **Fellow wanderer:** [Sonder](Sonder.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
