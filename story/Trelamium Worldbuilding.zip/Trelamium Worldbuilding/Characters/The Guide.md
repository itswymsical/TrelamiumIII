---
title: "The Guide"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# The Guide

*The Hero's first friend in Terraria. The Guide gives the first job, recognizes Apothos when the Eye dies, calls in the Dryad, and dies going into hardmode before Saint Jerwin brings him back.*

The Guide's first job teaches the Hero to build a town: gather materials, then put up rooms with walls, a door, a light, a table and a chair, until "that's a town". At 5 ft 8 in, he's the chats' measure of a modern Terrarian.

When the [Eye of Cthulhu](Eye%20of%20Cthulhu.md) dies, the Guide watches something pull it apart and recognizes it as [Apothos](../Magick%20and%20Systems/Apothos.md), an ancient magick he once read about. Promising not to leave the Hero to face it alone, he sends for [The Dryad](The%20Dryad.md), "a friend of mine, from another world entirely".

When the [Wall of Flesh](Wall%20of%20Flesh.md) falls, the Guide dies. The Hero and the other townsfolk push through early hardmode looking for a way to revive him, and [Saint Jerwin](Saint%20Jerwin.md) finds one: the Shimmer, as a spiritual medium that reconnects his soul to his body. The revival carries a moral and psychological cost.

## Connections

- **Helps:** [The Hero](The%20Hero.md)
- **Friend of:** [The Dryad](The%20Dryad.md)
- **Recognizes:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Dies with:** [Wall of Flesh](Wall%20of%20Flesh.md)
- **Revived by:** [Saint Jerwin](Saint%20Jerwin.md)
- **Lives in:** [Terraria](../Realms/Terraria.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
