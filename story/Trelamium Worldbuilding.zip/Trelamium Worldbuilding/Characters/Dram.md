---
title: "Dram"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Dram

*A Chaotican, half Vesper (an Archaean people) and half Bone Demon, who is Titan's grandson and Naka's partner. He stands 5 ft 2 in.*

## Connections

- **Homeland:** [Chaotica](../Realms/Chaotica.md)
- **Peoples:** [Vespers](../Peoples/Vespers.md), [Bone Demons](../Peoples/Bone%20Demons.md)
- **Grandfather:** [Titan](Titan.md)
- **Partner:** [Naka](Naka.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
