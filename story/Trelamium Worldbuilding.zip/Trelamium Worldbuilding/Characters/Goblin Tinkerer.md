---
title: "Goblin Tinkerer"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Goblin Tinkerer

*A goblin inventor whose anti-technology tribe set him up for execution during its raid. Freed by the Hero, he joins the town and builds contraptions.*

His tribe despises technology, so they tied him to a stake to be executed during the [Goblin Army](../Factions/The%20Goblin%20Army.md)'s raid. After the army is beaten, the Hero unties him and he moves into the town, grateful to be free of his tribe. He gives the Hero contraptions and technology, starting with the W.A.L.L. Bomb (the Wave-Actuated Lattice Layering device): press the button and suddenly there are walls everywhere.

## Connections

- **People:** [Goblins](../Peoples/Goblins.md)
- **Escaped:** [The Goblin Army](../Factions/The%20Goblin%20Army.md)
- **Freed by:** [The Hero](The%20Hero.md)
- **Lives in:** [Terraria](../Realms/Terraria.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
