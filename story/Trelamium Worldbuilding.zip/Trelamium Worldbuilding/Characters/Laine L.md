---
title: "Laine L"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["Laine L.", "Lane L"]
---

# Laine L

*A rational Anthropos philosopher of the 1800s P.E., steeped in phenomenology, who slid into paranoia about illuminance, silhouettes and architecture, and came to believe he had corrupted the woman he loved, Hesper.*

> [!NOTE] To be rewritten
> His story predates most of the current lore and will be rewritten. This note keeps the general idea and a summary of the current draft.

**The idea.** Laine was a purely rational man who slowly came apart into paranoia, talking about the [Illuminance](../Cosmology/Illuminance.md) and the [Silhouettes](../Cosmology/Silhouettes.md) of reality, and about darkness and [Architecture](../Cosmology/Architecture.md) corrupting the people around him and himself. He fell for [Hesper](Hesper.md), a country girl who never cared for the city, and pulled her into his reality. Being with him changed her completely, and he believes he corrupted her. In the end he understood that his infatuation was never with Hesper but with the idea of what she could be to him, and some part of that realization drove him mad.

**The current draft** is his book series *Illuminance*, shelved in [Reverie](../Realms/Reverie.md):

- He names the light people give off "the Illuminance", the wrong word: illuminance is light that falls on a thing, and he meant luminance.
- He measures the "civil temperature" of parishes and, in the eleventh, finds Hesper hanging washing.
- He takes her to a house on Cardell Street, publishes her name despite a promise, and shows her to forty-one visitors until she becomes fixed and unchanging, "a portrait of herself".
- In the last chapter he withdraws the Illuminance and renames it "the false light": something that comes off light, is not light, and grows under looking.
- He ends meaning to take her home in the spring.

The draft's dates run from 1803 to 1809.

## Connections

- **People:** [Anthropos](../Peoples/Anthropos.md)
- **Loved:** [Hesper](Hesper.md)
- **Wrote about:** [Illuminance](../Cosmology/Illuminance.md), [Silhouettes](../Cosmology/Silhouettes.md), [Architecture](../Cosmology/Architecture.md)
- **Books in:** [Reverie](../Realms/Reverie.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
