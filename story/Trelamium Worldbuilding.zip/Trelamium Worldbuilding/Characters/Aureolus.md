---
title: "Aureolus"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Aureolus

*Ruler of the Nimbus Kingdom and father of Cumulor.*

## Connections

- **Rules:** [Nimbus Kingdom](../Realms/Nimbus%20Kingdom.md)
- **Son:** [Cumulor](Cumulor.md)
- **People:** [Nimbus People](../Peoples/Nimbus%20People.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
