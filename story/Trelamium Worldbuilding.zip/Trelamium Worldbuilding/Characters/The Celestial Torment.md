---
title: "The Celestial Torment"
date: 2026-10-11
type: character
status: concept
tags: [character]
aliases: ["The Torment"]
---

# The Celestial Torment

*Red's opposite and eternal equal, a demiurge who co-designed the Terraria universe.*

## Connections

- **Is a:** [demiurge](../Cosmology/Demiurges.md)
- **Equal and opposite:** [The Red God](The%20Red%20God.md)
- **Designed:** [Terraria](../Realms/Terraria.md)'s universe

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
