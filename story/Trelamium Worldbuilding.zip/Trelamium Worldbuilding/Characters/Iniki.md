---
title: "Iniki"
date: 2026-10-11
type: character
status: canon
tags: [character, antagonist]
aliases: ["Dark Incarnate", "Iminki"]
---

# Iniki

*Darkness incarnate and the final antagonist. It waited since the Vault for a form that would not resist it, then filled the Trelamium God.*

Iniki has waited since [The Vault](../Cosmology/The%20Vault.md) for a form that would not resist it. It carries the dark's oldest memory: the Vault, where nothing had yet been given quality. When one member of the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) emptied himself completely, Iniki entered him. It was not possession, "for there was no one left to possess. It was fit." Together they are the [Trelamium God](The%20Trelamium%20God.md).

In the world itself, Iniki is only a fable. [Permafrost](Permafrost.md) is one of the few who learned it is real, by way of Apothos. When Illuminant beings began channeling Iniki, tribalism entered the world.

The Hero faces Iniki after the Moon Lord.

## Connections

- **Origin:** [The Vault](../Cosmology/The%20Vault.md)
- **Fills:** [The Trelamium God](The%20Trelamium%20God.md)
- **Manifests as:** [Iniki Manifestations](../Peoples/Iniki%20Manifestations.md)
- **Served by:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Channeled by:** Illuminant beings ([Illuminance](../Cosmology/Illuminance.md))
- **Known to:** [Permafrost](Permafrost.md)
- **Opposed by:** [The Hero](The%20Hero.md), after the Moon Lord

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
