---
title: "Eater of Worlds"
date: 2026-10-11
type: character
status: proposed
tags: [character]
---

# Eater of Worlds

*Proposed tie-in: the dead soldiers' twisted souls, compacted by Fullbone into one devouring body.*

> [!WARNING] Proposed
> This comes from the Lore Bible's suggested tie-ins. It is not canon yet.

An Assailant fortress in the Corruption holds the summoning ritual. Clearing the camp's mini-boss gives the summon item or a lore page about Fullbone. On its death, Fullbone's Apothos tries to reclaim the remains and the Hero's [Ingress](../Realms/Ingress.md) training lets them resist, a variation on the Eye's cutscene.

## Connections

- **Made by:** [Fullbone](Fullbone.md)
- **Home:** [The Corruption](../Realms/The%20Corruption.md)
- **Kind:** [Annelids](../Peoples/Annelids.md)
- **Made from:** the dead of [The Ancient Great War](../Timeline/The%20Ancient%20Great%20War.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
