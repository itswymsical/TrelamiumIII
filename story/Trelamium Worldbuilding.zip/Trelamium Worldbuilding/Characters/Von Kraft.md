---
title: "Von Kraft"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Von Kraft

*One of Yakvala's last creations, newly designed by Gerjingle in September 2026.*

## Connections

- **Made by:** [Yakvala](Yakvala.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
