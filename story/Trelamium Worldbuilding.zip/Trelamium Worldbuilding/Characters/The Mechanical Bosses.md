---
title: "The Mechanical Bosses"
date: 2026-10-11
type: character
status: concept
tags: [character]
aliases: ["The Mechs", "The Twins", "The Destroyer", "Skeletron Prime"]
---

# The Mechanical Bosses

*The hardmode mechs: built by Yakvala as benevolent protectors, inhabited by souls the Three Witches created, and later twisted into monsters.*

## Connections

- **Built by:** [Yakvala](Yakvala.md)
- **Souls made by:** [The Three Witches](../Factions/The%20Three%20Witches.md): [Malicia](Malicia.md) (Fright), [Saraphine](Saraphine.md) (Sight), [Farewynn](Farewynn.md) (Might)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
