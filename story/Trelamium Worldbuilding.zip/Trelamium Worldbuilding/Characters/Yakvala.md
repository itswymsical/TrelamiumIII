---
title: "Yakvala"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Yakvala

*The ancient lead engineer of the Elysians, who built the mechanical bosses as protectors and later twisted them into monsters. Dead by the present.*

Yakvala was extremely old and alive during [Excellia](../Realms/Excellia.md)'s era. He built the [Mechanical Bosses](The%20Mechanical%20Bosses.md) as benevolent protectors, back when the worlds still worked together. Two versions of his fall exist:

- **August 2025:** after [The Call of Light](../Timeline/The%20Call%20of%20Light.md) he lost faith in the future of the worlds, was corrupted by [Apothos](../Magick%20and%20Systems/Apothos.md), and altered his creations into monsters in favor of [Queen Flaropha](Queen%20Flaropha.md). He is one of the remnants of the [Void Whisperers](../Factions/The%20Void%20Whisperers.md).
- **September 2026:** he lost his mind during [The Man and Monster War](../Timeline/The%20Man%20and%20Monster%20War.md) after Queen Flaropha tortured him, and turned the mechs into what they are in the game.

[Von Kraft](Von%20Kraft.md) is one of his last creations.

## Connections

- **People:** [Elysians](../Peoples/Elysians.md), as lead engineer
- **Built:** [The Mechanical Bosses](The%20Mechanical%20Bosses.md)
- **Created:** [Von Kraft](Von%20Kraft.md)
- **Corrupted by:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Tortured by:** [Queen Flaropha](Queen%20Flaropha.md)
- **Remnant of:** [The Void Whisperers](../Factions/The%20Void%20Whisperers.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
