---
title: "Glacier"
date: 2026-10-11
type: character
status: canon
tags: [character, boss]
---

# Glacier

*Permafrost's eye, a Hyperborean watcher that works like a summon or stand. The Hero fights Glacier on Permafrost's frozen mountain as his challenge. One of the four new bosses.*

The old eye sprite once represented the frost giant himself. Now the eye is Glacier, a summon or stand of [Permafrost](Permafrost.md), and fighting it on his frozen mountain in [Hyperborea](../Realms/Hyperborea.md) is the challenge Permafrost sets the Hero. A mix of watcher and Hyperborean, it is classed as a watcher. Gerjingle is redesigning it.

## Connections

- **Kind:** [Watchers](../Peoples/Watchers.md)
- **Origin:** [Hyperborea](../Realms/Hyperborea.md), [Hyperboreans](../Peoples/Hyperboreans.md)
- **Belongs to:** [Permafrost](Permafrost.md)
- **Fought by:** [The Hero](The%20Hero.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
