---
title: "Corithian"
date: 2026-10-11
type: character
status: canon
tags: [character, assailant-crusade]
aliases: ["Supreme Fiend Corithian", "Corinthians"]
---

# Corithian

*The Supreme Fiend: commander of the Assailants' lowest rank, a priest-like practitioner of Apothos, and the opposite of Saint Jerwin.*

From the September 29, 2026 chat. A priest-looking figure drawn beside [Erahoka](Erahoka.md), he practices [Apothos](../Magick%20and%20Systems/Apothos.md) and works as a dark mirror of [Saint Jerwin](Saint%20Jerwin.md). "Supremes" sit above the rank in their title and command it, so as Supreme Fiend he commands the [Fiends](../Factions/Assailant%20Ranks/Fiends.md).

## Connections

- **Rank:** Supreme of the [Fiends](../Factions/Assailant%20Ranks/Fiends.md)
- **Faction:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Practices:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Opposite of:** [Saint Jerwin](Saint%20Jerwin.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
