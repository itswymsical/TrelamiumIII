---
title: "Wooden Warden"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The Guardian of Ingress"]
---

# Wooden Warden

*The Guardian of Ingress: a sentient wooden golem ordered to protect the Scar of Ingress and what lies behind it. Awakened at the Altar of Ingress.*

Its bestiary entry calls it "the Protector of the Ligneous Fortress". The Hero awakens it at the Altar of Ingress, and the Dryad's job asks them to get past it to reach [Reverie](../Realms/Reverie.md).

## Connections

- **Guards:** [Scar of Ingress](../Realms/Scar%20of%20Ingress.md)
- **Protects:** [Temple of Ingress](../Realms/Temple%20of%20Ingress.md)
- **Realm:** [Ingress](../Realms/Ingress.md)
- **Blocks the way to:** [Reverie](../Realms/Reverie.md) *(inferred)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
