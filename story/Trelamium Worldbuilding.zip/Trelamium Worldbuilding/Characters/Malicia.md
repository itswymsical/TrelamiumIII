---
title: "Malicia"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Malicia

*The Witch of Fright. She made Fright Energy to control how fear spreads, so the world could find its bravery, and became fear's personification.*

Without her, many of the great fighting forces in the story would never have formed: their founders wouldn't have found the courage to fight their oppressors. The price was her own nature, and people near her are engulfed in fear.

## Connections

- **One of:** [The Three Witches](../Factions/The%20Three%20Witches.md)
- **Made the soul of:** [The Mechanical Bosses](The%20Mechanical%20Bosses.md), with Fright Energy

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
