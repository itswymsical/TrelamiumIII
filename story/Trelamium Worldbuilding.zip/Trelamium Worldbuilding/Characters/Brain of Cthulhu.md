---
title: "Brain of Cthulhu"
date: 2026-10-11
type: character
status: proposed
tags: [character]
---

# Brain of Cthulhu

*Proposed tie-in: grown by Fullbone from the dead soldiers' blood. It is literally Cthulhu's brain, a remote organ that thinks through Apothos.*

> [!WARNING] Proposed
> This comes from the Lore Bible's suggested tie-ins. It is not canon yet.

Where the [Eye of Cthulhu](Eye%20of%20Cthulhu.md) watches, the Brain thinks through [Apothos](../Magick%20and%20Systems/Apothos.md), which fits its illusion-based fight. An Assailant fortress in the Crimson holds the summoning ritual.

## Connections

- **Made by:** [Fullbone](Fullbone.md)
- **Home:** [The Crimson](../Realms/The%20Crimson.md)
- **Belongs to:** [Cthulhu](Cthulhu.md)
- **Thinks through:** [Apothos](../Magick%20and%20Systems/Apothos.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
