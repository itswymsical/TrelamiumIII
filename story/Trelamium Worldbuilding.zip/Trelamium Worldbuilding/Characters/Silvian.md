---
title: "Silvian"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["Sylvian"]
---

# Silvian

*A friendly herb gardener of about 24 and the nephew of John Substrate, the greatest alchemist who ever lived. After his first job he gives the Hero his late uncle's Alchemist's Almanac.*

Silvian keeps an herb garden and talks like a friendly local. His first job for the Hero is gathering herbs (dayblooms, blinkroots and magnolias) for the garden. Once it's done, he hands over his uncle's [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md). He has read it so many times he knows it by heart, and a book like that "oughta be out there gettin' used". He asks the Hero to fill in the pages his uncle left blank.

From then on he acts as the Hero's alchemy tutor. Hold up an item and ask for help, and he explains what it is, what it leans toward and how to brew with it, quoting "Uncle J" as he goes. He counts [Argie](Argie.md), his uncle's old apprentice, as a friend.

## Connections

- **Uncle:** [John Substrate](John%20Substrate.md)
- **Friend:** [Argie](Argie.md)
- **Gives the Hero:** [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md)
- **Teaches:** [Alchemy](../Magick%20and%20Systems/Alchemy.md)
- **Helps:** [The Hero](The%20Hero.md)
- **Gives:** [Silvian's First Job](../Jobs/Silvian's%20First%20Job.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
