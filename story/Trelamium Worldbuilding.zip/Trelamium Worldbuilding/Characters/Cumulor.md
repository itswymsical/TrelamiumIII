---
title: "Cumulor"
date: 2026-10-11
type: character
status: concept
tags: [character, boss]
aliases: ["The Exiled Son"]
---

# Cumulor

*The Exiled Son: a boss of the Nimbus Kingdom and son of its ruler, Aureolus. One of the four new bosses.*

Begun long ago and left unfinished, Cumulor was meant to be fought in a sky dimension of Greedy Gods. In September 2026 he was named among the new bosses with [Glacier](Glacier.md), [Pyron](Pyron.md) and [The Azolinth](The%20Azolinth.md). His old boss lore is due for a rewrite.

## Connections

- **Father:** [Aureolus](Aureolus.md)
- **Homeland:** [Nimbus Kingdom](../Realms/Nimbus%20Kingdom.md)
- **People:** [Nimbus People](../Peoples/Nimbus%20People.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
