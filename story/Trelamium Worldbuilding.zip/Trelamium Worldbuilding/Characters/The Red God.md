---
title: "The Red God"
date: 2026-10-11
type: character
status: concept
tags: [character]
aliases: ["Red"]
---

# The Red God

*Red, the personification of creation: a demiurge who designed the Terraria universe and answers to higher forces. He steps in only when someone tries to do too much.*

From Gerjingle's September 2026 notes. Many forces existed before Red and [The Celestial Torment](The%20Celestial%20Torment.md); those two are simply the ones who designed the Terraria universe, and Terraria is its epicenter. Because Red has a personality, he isn't a true force but a demigod or [demiurge](../Cosmology/Demiurges.md), "more of the blueprint guy" than the great creator. Groups worship him as the being who made them, but there are beings he answers to, revealed the one time he speaks with the Hero.

He wasn't created to be the Red God; he became it after finding his purpose, an origin a little like the Anthropos'. He could destroy as much as the Torment, but doesn't want to. Beings like the two of them come into existence as equals and stay equal forever, so neither can usurp the other, "almost like children".

## Connections

- **Is a:** [demiurge](../Cosmology/Demiurges.md)
- **Equal and opposite:** [The Celestial Torment](The%20Celestial%20Torment.md)
- **Designed:** [Terraria](../Realms/Terraria.md)'s universe
- **Meets:** [The Hero](The%20Hero.md), once

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
