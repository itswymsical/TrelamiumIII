---
title: "Wall of Flesh"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Wall of Flesh

*A guardian gone wild, made with destructive magick to protect the demons from a planned purge. It holds the souls of the billions it consumed.*

From Gerjingle's September 2026 notes. The Wall was made as a protective measure against the [Archivers](../Peoples/Archivers.md), [Excellia](../Realms/Excellia.md) and [Sylvanwalde](../Realms/Sylvanwalde.md), who were planning to purge the [Demons](../Peoples/Demons.md). It consumed billions, and entire races of creatures and people were wiped out. When it dies, it releases those damaged souls, tortured in "the worst place to ever exist". Almost none can be saved, which is why even unicorns and pixies turn hostile in hardmode. The [Tax Collector](Tax%20Collector.md) is the exception.

Its death is also when [The Guide](The%20Guide.md) dies, starting the search for a way to revive him.

## Connections

- **Protects:** [Demons](../Peoples/Demons.md)
- **Made against:** [Archivers](../Peoples/Archivers.md), [Excellia](../Realms/Excellia.md), [Sylvanwalde](../Realms/Sylvanwalde.md)
- **Guards:** [The Underworld](../Realms/The%20Underworld.md)
- **Released:** [Tax Collector](Tax%20Collector.md)
- **Takes with it:** [The Guide](The%20Guide.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
