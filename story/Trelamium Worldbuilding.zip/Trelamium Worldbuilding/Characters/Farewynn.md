---
title: "Farewynn"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Farewynn

*The Witch of Might, from Gerjingle's notes. She made Might Energy to grant power to whatever she chooses, for the entertainment of watching the conflict that follows.*

She created the Blessed Swordsman and raised the most powerful nations in history, granting her power to whoever earns her grace. For entertainment she also created some of the most powerful beasts ever to roam the realm, among them the Queen Slime and the Infinity Sovereigns. She loves to watch death. Near her, people feel empowered and proud, and inferior at the same time.

## Connections

- **One of:** [The Three Witches](../Factions/The%20Three%20Witches.md)
- **Made the soul of:** [The Mechanical Bosses](The%20Mechanical%20Bosses.md), with Might Energy
- **Possibly blessed:** [Gouhtri](Gouhtri.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
