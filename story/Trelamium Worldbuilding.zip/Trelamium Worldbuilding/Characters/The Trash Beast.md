---
title: "The Trash Beast"
date: 2026-10-11
type: character
status: proposed
tags: [character]
aliases: ["The hoarder"]
---

# The Trash Beast

*A planned static mini-boss that hoards everything it finds beneath spawn. Defeated, it turns out to be a tiny creature in a pot, and it becomes a town pet. Working name, from the 2025 plan.*

Its lair is a "trash room" in the cavern layer directly under spawn, and nearby enemies drift toward it. It is built from the junk it has found and sits on a pile of loot that bursts out when it dies. Fairies lead the Hero to it, eager to show off the loot. Defeated, it begs for mercy, and the Hero can bring it home as a town pet that hops around in its pot, with filler missions later. Its personality is like Marvel's Collector.

It drops a Chronicle ([The Chronicles](../Magick%20and%20Systems/The%20Chronicles.md)) and tells the Guide that a second one was stolen from it by a band of Assailants, pointing the Hero toward their base in the Corruption.

## Connections

- **Found by way of:** [Fairies](../Peoples/Fairies.md)
- **Drops:** [The Chronicles](../Magick%20and%20Systems/The%20Chronicles.md)
- **Robbed by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Lives in:** [Terraria](../Realms/Terraria.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
