---
title: "The Trelamium God"
date: 2026-10-11
type: character
status: concept
tags: [character, antagonist]
aliases: ["The Iniki God", "Deity of Trelamium"]
---

# The Trelamium God

*An Anthropos who gave away his name, history and wanting, then was filled by Iniki. He walks toward the Vault to close it. Name pending.*

"The Trelamium God" is a working name.

In [Revelation](../Timeline/Revelation.md), one member of the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) completed the rite. He gave away his name, his history and the ache beneath it until nothing in him could be called experience. He was no longer [Anthropos](../Peoples/Anthropos.md): "a silhouette with no one inside it." [Iniki](Iniki.md) entered that empty form, and Trelamium had its deity.

The Lore Bible describes the result as running on [Trelamium](../Cosmology/Trelamium.md), with no sense of self: purely operational. His only will is the dark's oldest memory.

He walks toward [The Vault](../Cosmology/The%20Vault.md) to close it again, with every quality of the world folded into the silence of structure.

## Connections

- **Vessel:** an [Anthropos](../Peoples/Anthropos.md) of [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Filled by:** [Iniki](Iniki.md)
- **Deity of:** [Trelamium](../Cosmology/Trelamium.md)
- **Made in:** [Revelation](../Timeline/Revelation.md)
- **Walks toward:** [The Vault](../Cosmology/The%20Vault.md)
- **Opposite of:** [Qualia](../Cosmology/Qualia.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
