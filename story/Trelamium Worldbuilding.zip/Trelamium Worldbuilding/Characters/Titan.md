---
title: "Titan"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Titan

*Dram's grandfather, being redesigned as "a special case". Nothing else is set.*

## Connections

- **Grandson:** [Dram](Dram.md)
- **Homeland:** [Chaotica](../Realms/Chaotica.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
