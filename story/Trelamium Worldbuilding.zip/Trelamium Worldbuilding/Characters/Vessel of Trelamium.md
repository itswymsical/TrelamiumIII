---
title: "Vessel of Trelamium"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Vessel of Trelamium

*The vessel Trelamium sent into the earth. It planted seeds inside the Anthropos' architecture.*

In [Primordial Age II](../Timeline/Primordial%20Age%20II.md), [Trelamium](../Cosmology/Trelamium.md) sent a vessel into the earth alongside the light's. Where the [Vessel of Luminance](Vessel%20of%20Luminance.md) shone through the Anthropos' [Architecture](../Cosmology/Architecture.md), this one planted seeds within it.

## Connections

- **Sent by:** [Trelamium](../Cosmology/Trelamium.md)
- **Era:** [Primordial Age II](../Timeline/Primordial%20Age%20II.md)
- **Counterpart:** [Vessel of Luminance](Vessel%20of%20Luminance.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
