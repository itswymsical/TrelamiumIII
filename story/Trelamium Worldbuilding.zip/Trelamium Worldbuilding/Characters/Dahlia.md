---
title: "Dahlia"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Dahlia

*An elf and the hero of Sylvanwalde. One of the only elves free of the elves' prejudice, she and her crew stopped Cthulhu's Crusade there.*

Among the classist elves of [Sylvanwalde](../Realms/Sylvanwalde.md), only Dahlia and her son stand apart. With her own crew, which included a mage and [The Tamer](The%20Tamer.md), she stopped the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) in Sylvanwalde, which made her one of the [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md).

## Connections

- **People:** [Elves](../Peoples/Elves.md)
- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **Title:** [Hero of Sylvanwalde](../Factions/Heroes%20of%20the%20Land.md)
- **Crew:** [The Tamer](The%20Tamer.md), an unnamed mage, and others
- **Stopped:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md), in Sylvanwalde

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
