---
title: "Sonder"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Sonder

*A mysterious, esoteric wanderer who appears at random and trades stories for an answer to one question: have you felt sonder?*

In the mod, Sonder is "a mere wanderer of the world" with many stories to tell. Before telling them, Sonder asks whether the Hero has experienced sonder: the realization that every passerby lives a life as vivid and complex as your own.

## Connections

- **Fellow wanderer:** [Kraken](Kraken.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
