---
title: "Cthulhu"
date: 2026-10-11
type: character
status: canon
tags: [character, antagonist]
aliases: ["Moon Lord"]
---

# Cthulhu

*The half-commoner prince of Seaforth who found Apothos and leads the Assailant Crusade. The Hero fights him as the Moon Lord.*

His mother was a commoner and his father the king of [Seaforth](../Realms/Seaforth.md). When the king died of illness, a story spread that Cthulhu had killed him, and the [Seaforth Nobility](../Factions/Seaforth%20Nobility.md) refused him the throne. During the revolution that followed he discovered [Apothos](../Magick%20and%20Systems/Apothos.md). Seaforth stopped being enough: in his words, humanity and all beings must be controlled because their own interpretations elude them from the truth.

He wants control of all realities because a noble class once denied him his own. He manipulates his own followers, and the four [Paladins](../Factions/Assailant%20Ranks/Paladins.md) beneath him each pursue private goals. He knows, and works to keep them from gaining the upper hand.

He is a pawn of a larger plan. If the Crusade succeeds, [Trelamium](../Cosmology/Trelamium.md) takes over regardless of what he wants.

## Connections

- **People:** [Cephalopods](../Peoples/Cephalopods.md) *(tentative)*
- **Homeland:** [Seaforth](../Realms/Seaforth.md)
- **Rejected by:** [Seaforth Nobility](../Factions/Seaforth%20Nobility.md)
- **Leads:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Wields:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Remote organs:** [Eye of Cthulhu](Eye%20of%20Cthulhu.md), [Brain of Cthulhu](Brain%20of%20Cthulhu.md) *(proposed)*
- **Power struggle with:** [Fullbone](Fullbone.md), [Erahoka](Erahoka.md), [Nisha](Nisha.md), [Callisto](Callisto.md)
- **Unknowingly serves:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Opposed by:** [The Hero](The%20Hero.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
