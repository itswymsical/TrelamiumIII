---
title: "Callisto"
date: 2026-10-11
type: character
status: concept
tags: [character, assailant-crusade]
---

# Callisto

*A Paladin of the Crusade with a private agenda.*

## Connections

- **Rank:** [Paladins](../Factions/Assailant%20Ranks/Paladins.md)
- **Serves, for now:** [Cthulhu](Cthulhu.md)
- **Rivals:** [Fullbone](Fullbone.md), [Erahoka](Erahoka.md), [Nisha](Nisha.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
