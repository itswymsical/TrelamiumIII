---
title: "Permafrost"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Permafrost

*The only frost giant in the story: a sorcerer of ice magick who studied Apothos, learned of Iniki, met the Trelamium God, and is climbing toward becoming a demiurge. He judges whether the Hero is worth teaching.*

Frost giants are dull and brutish in Norse myth, and Permafrost is the deliberate opposite. Born a frost giant, he made the life of a sorcerer his path. Studying [Apothos](../Magick%20and%20Systems/Apothos.md) led him to [Iniki](Iniki.md), which most of the world knows only as a fable, and down an esoteric road that turned a passionate mage into a jaded, deeply aware being. He is cold and observational. He has met whoever the [Trelamium God](The%20Trelamium%20God.md) turns out to be, and may have written apocrypha on Iniki's essence and Apothos magick. What he knows and can do is close to inconceivable; he is climbing toward becoming a [demiurge](../Cosmology/Demiurges.md) in the domain of knowledge.

He lives on a frozen mountain in [Hyperborea](../Realms/Hyperborea.md). When the Hero finds him, he remarks how long it's been since anyone ventured into these frozen lands, then weighs whether they're worthy of anything worth sharing. The test is a fight with [Glacier](Glacier.md), his eye.

In the September 2026 chat this character was first called Glacier; the name moved to the eye, and the mage became Permafrost.

## Connections

- **People:** [Frost Giants](../Peoples/Frost%20Giants.md), as its only member
- **Home:** a frozen mountain in [Hyperborea](../Realms/Hyperborea.md)
- **Studied:** [Apothos](../Magick%20and%20Systems/Apothos.md), [Iniki](Iniki.md)
- **Has met:** [The Trelamium God](The%20Trelamium%20God.md)
- **Climbing toward:** [Demiurges](../Cosmology/Demiurges.md)
- **Eye and challenge:** [Glacier](Glacier.md)
- **Rival:** [Pyron](Pyron.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
