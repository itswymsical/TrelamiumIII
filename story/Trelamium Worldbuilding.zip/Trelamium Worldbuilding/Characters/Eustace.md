---
title: "Eustace"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The Cowboy"]
---

# Eustace

*A cowboy, the Vespers' leader and most respected figure, and the hero of Archaea. He has an apprentice who hasn't been named yet.*

Eustace is the hero of Archaea: one of the [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md) who led their people in fighting off Cthulhu's [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md). [Sophie](Sophie.md) holds him in great respect.

## Connections

- **People:** [Vespers](../Peoples/Vespers.md) *(inferred)*
- **Home:** [Cactus County](../Realms/Cactus%20County.md)
- **Title:** [Hero of Archaea](../Factions/Heroes%20of%20the%20Land.md)
- **Respected by:** [Sophie](Sophie.md)
- **Fought off:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
