---
title: "Eye of Cthulhu"
date: 2026-10-11
type: character
status: canon
tags: [character, assailant-crusade]
aliases: ["The Watcher"]
---

# Eye of Cthulhu

*Cthulhu's literal eye, the Watcher, which surveys Terraria for anything producing mass qualia. Its death breaks a seal and lets Apothos back into the world.*

The eye of the being later fought as the Moon Lord. As one of the [Watchers](../Peoples/Watchers.md), it surveys [Terraria](../Realms/Terraria.md) for anything producing mass amounts of [Qualia](../Cosmology/Qualia.md). The Hero is one, so it attacks.

On its death, Assailants using [Apothos](../Magick%20and%20Systems/Apothos.md) pull its remains into a [Trelamium](../Cosmology/Trelamium.md) vortex (cutscene implemented). [The Guide](The%20Guide.md) watches something take the Eye apart piece by piece and recognizes it as Apothos, an ancient magick that nullifies whatever it takes hold of: "with the Eye gone, it's back in the world." [The Dryad](The%20Dryad.md) feels the seal break from [Ingress](../Realms/Ingress.md).

This fight is the early game's turning point: before it the Hero learns alchemy, and after it the Dryad sends them to Ingress.

## Connections

- **Belongs to:** [Cthulhu](Cthulhu.md)
- **Kind:** [Watchers](../Peoples/Watchers.md)
- **Hunts:** [The Hero](The%20Hero.md), [Qualia](../Cosmology/Qualia.md)
- **Remains taken into:** [Trelamium](../Cosmology/Trelamium.md)
- **Its death releases:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Faction:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
