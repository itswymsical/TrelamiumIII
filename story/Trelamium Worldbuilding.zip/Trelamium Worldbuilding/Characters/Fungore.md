---
title: "Fungore"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The Malevolent Myconid"]
---

# Fungore

*The Malevolent Myconid, a standalone boss with no part in the Crusade.*

A fruiting body grown large enough to walk. Its bestiary hints that it buried itself to escape something, and that whatever brings it back up is louder. Fungore is a filler character with no tie to the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md).

## Connections

- **People:** [Myconids](../Peoples/Myconids.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
