---
title: "The Hero"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The Player"]
---

# The Hero

*The player. They produce qualia in mass amounts, which draws the watchers, and must stop the Moon Lord and then Iniki, becoming the hero of Terraria and finally of reality.*

The Hero belongs to no faction. Their experience generates [Qualia](../Cosmology/Qualia.md) in mass amounts, so the [Eye of Cthulhu](Eye%20of%20Cthulhu.md) hunts them. They learn [Alchemy](../Magick%20and%20Systems/Alchemy.md) from the [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md) that [Silvian](Silvian.md) passes on: the same language the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) used, though not with the same intention.

After the Eye, [The Guide](The%20Guide.md) calls in [The Dryad](The%20Dryad.md), who sends them inward to [Ingress](../Realms/Ingress.md), where they gain the [Clarifying Language](../Magick%20and%20Systems/Clarifying%20Language.md) needed to fight [Apothos](../Magick%20and%20Systems/Apothos.md).

They walk in the footsteps of the [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md), like [Dahlia](Dahlia.md) and [Eustace](Eustace.md): first as the hero of Terraria, and in the end, by stopping [Iniki](Iniki.md), as the hero of reality.

## Connections

- **Home:** [Terraria](../Realms/Terraria.md)
- **First job from:** [The Guide](The%20Guide.md)
- **Produces:** [Qualia](../Cosmology/Qualia.md), earned as [Experiential Points](../Magick%20and%20Systems/Experiential%20Points.md)
- **Learns from:** the [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md), given by [Silvian](Silvian.md)
- **Guided by:** [The Dryad](The%20Dryad.md)
- **Journeys to:** [Ingress](../Realms/Ingress.md), [Reverie](../Realms/Reverie.md)
- **Frees:** [Goblin Tinkerer](Goblin%20Tinkerer.md)
- **Hunted by:** [Eye of Cthulhu](Eye%20of%20Cthulhu.md)
- **Must stop:** [Cthulhu](Cthulhu.md), then [Iniki](Iniki.md)
- **Becomes:** one of the [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md), then the hero of reality
- **Reads:** books from [Reverie](../Realms/Reverie.md), lent by [Edith](Edith.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
