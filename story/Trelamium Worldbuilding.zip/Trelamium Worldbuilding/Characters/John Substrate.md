---
title: "John Substrate"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["Uncle J", "Uncle John"]
---

# John Substrate

*The greatest alchemist who ever existed, uncle of Silvian, teacher of Argie, and author of the Alchemist's Almanac. He died at about 43, most likely at the Assailants' hands.*

The name is a joke and meant seriously at once: a substrate is what lies underneath, the base a reaction works on. The mod's lore glossary defines *substratica* as "having to do with the nature of what underlies".

He inspired a young [Argie](Argie.md) to take up mycology and taught her as his apprentice. He wrote the [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md) in his own hand and left it to his nephew [Silvian](Silvian.md). Its foreword opens: "If you're reading this, then the assailants have done their work and I've done my dying." It also asks Silvian to let Argie know he has the book.

## Connections

- **Nephew:** [Silvian](Silvian.md)
- **Apprentice:** [Argie](Argie.md)
- **Wrote:** [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md)
- **Practiced:** [Alchemy](../Magick%20and%20Systems/Alchemy.md)
- **Killed by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) *(inferred from the Almanac)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
