---
title: "Eosforos"
date: 2026-10-11
type: character
status: canon
tags: [character, assailant-crusade]
---

# Eosforos

*Half goat, half Anthropos, with a goofy personality. He works under the Assailants for Cthulhu and is planned as a pre-hardmode boss.*

The name is a spelling of the Greek *Eosphoros*, "dawn-bringer", the morning star. Gerjingle has a sprite for him that may be remade; its cape shares a color with another character's poncho.

## Connections

- **People:** [Hybrid Anthropoi](../Peoples/Hybrid%20Anthropoi.md)
- **Faction:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Serves:** [Cthulhu](Cthulhu.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
