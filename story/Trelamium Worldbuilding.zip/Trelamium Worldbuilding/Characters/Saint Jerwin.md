---
title: "Saint Jerwin"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Saint Jerwin

*A priest and a Quint who practices Illuminant Magick. After the Guide dies, he finds a way to revive him through the Shimmer.*

In the September 2026 plan, when [The Guide](The%20Guide.md) dies going into hardmode, the Hero and the other townsfolk push through early hardmode looking for a way to bring him back. Saint Jerwin finds it: the Shimmer, used as a spiritual medium to rebuild the connection between the Guide's soul and body. The revival is meant to be a moral and psychological obstacle, and it becomes the catalyst for a downward spiral.

[Corithian](Corithian.md), the Supreme Fiend, is his dark opposite: a priest of Apothos.

## Connections

- **People:** [Quints](../Peoples/Quints.md)
- **Practices:** [Illuminant Magick](../Magick%20and%20Systems/Illuminant%20Magick.md)
- **Revives:** [The Guide](The%20Guide.md)
- **Opposite:** [Corithian](Corithian.md)
- **Role:** [Magick Practitioners](../Magick%20and%20Systems/Magick%20Practitioners.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
