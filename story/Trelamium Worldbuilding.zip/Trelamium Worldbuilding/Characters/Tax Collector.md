---
title: "Tax Collector"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Tax Collector

*The one soul released by the Wall of Flesh that wasn't beyond saving.*

When the [Wall of Flesh](Wall%20of%20Flesh.md) died, it released damaged souls tortured in "the worst place to ever exist". Almost all of them are beyond saving, which is why even mystic creatures like unicorns and pixies are hostile. The Tax Collector is the exception.

## Connections

- **Released by:** [Wall of Flesh](Wall%20of%20Flesh.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
