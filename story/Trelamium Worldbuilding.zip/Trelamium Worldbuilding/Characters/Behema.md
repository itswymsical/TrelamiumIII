---
title: "Behema"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Behema

*A figure who may be a demiurge, which would explain how Behema made Chaotica.*

## Connections

- **Made:** [Chaotica](../Realms/Chaotica.md) *(if a demiurge)*
- **Possibly one of:** [Demiurges](../Cosmology/Demiurges.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
