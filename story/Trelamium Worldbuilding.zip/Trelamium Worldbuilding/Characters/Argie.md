---
title: "Argie"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["Argentina"]
---

# Argie

*Argie, or Argentina: a mycologist who lives in the Glowshroom Grotto and was once John Substrate's young apprentice. A sideline character early on who matters later.*

She's about 25. As a kid she wanted to learn mycology, and [John Substrate](John%20Substrate.md) inspired her; she grew up as his apprentice and friend. She knows [Silvian](Silvian.md) too: ask him about her and he'll tell you she's a friend of his.

The [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md) was written for Silvian, and its foreword asks him to let Argie know he has the book. She's an old friend, and she'd want to know it's still out there.

Early in the game she gives the Hero access to [Mycology](../Magick%20and%20Systems/Mycology.md) content and specific, low-level forms of [Alchemy](../Magick%20and%20Systems/Alchemy.md). She becomes important later.

## Connections

- **Home:** [Glowshroom Grotto](../Realms/Glowshroom%20Grotto.md)
- **Teacher:** [John Substrate](John%20Substrate.md)
- **Friend:** [Silvian](Silvian.md)
- **Teaches:** [Mycology](../Magick%20and%20Systems/Mycology.md), low-level [Alchemy](../Magick%20and%20Systems/Alchemy.md)
- **Mentioned in:** [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
