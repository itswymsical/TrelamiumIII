---
title: "Pyron"
date: 2026-10-11
type: character
status: canon
tags: [character, boss]
---

# Pyron

*A demon warrior from Chaotica, Permafrost's rival, and one of the four new bosses. He stands at a level only beings like Permafrost reach.*

In September 2026 Pyron was named among the new bosses with [Glacier](Glacier.md), [Cumulor](Cumulor.md) and [The Azolinth](The%20Azolinth.md). He is placed on Permafrost's level of power, far above a protector like [Gouhtri](Gouhtri.md).

## Connections

- **People:** [Demons](../Peoples/Demons.md)
- **Homeland:** [Chaotica](../Realms/Chaotica.md)
- **Rival:** [Permafrost](Permafrost.md)
- **Level:** [Demiurges](../Cosmology/Demiurges.md) *(implied)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
