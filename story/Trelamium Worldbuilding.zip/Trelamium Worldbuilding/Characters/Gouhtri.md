---
title: "Gouhtri"
date: 2026-10-11
type: character
status: concept
tags: [character]
aliases: ["The Great Gouhtri"]
---

# Gouhtri

*An ancient knight so devoted to knighthood that he never removes his armor and has become it, living far past any human lifespan. Close to a demiurge, with no wish to be more.*

"The Great Gouhtri" stands 11 ft 8 in, from an age when the [Taijitons](../Peoples/Taijitons.md) were much larger than people are now. No human could live as long as he has, even with his blessing. He is enormously powerful, and his purpose as a protector brings him close to being a [demiurge](../Cosmology/Demiurges.md). But that purpose concerns the material world and his simple values, so it doesn't lift him to the level of [Permafrost](Permafrost.md) or [Pyron](Pyron.md), and he doesn't want to be more than he is. Gerjingle redesigned him in September 2026.

## Connections

- **People:** [Taijitons](../Peoples/Taijitons.md) *(inferred)*
- **Close to:** [Demiurges](../Cosmology/Demiurges.md)
- **Blessing possibly from:** [Farewynn](Farewynn.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
