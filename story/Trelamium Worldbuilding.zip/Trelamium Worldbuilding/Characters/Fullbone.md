---
title: "Fullbone"
date: 2026-10-11
type: character
status: concept
tags: [character, assailant-crusade]
---

# Fullbone

*A Paladin of the Crusade and a power-hungry maniac with no morality. Responsible for the Corruption and the Crimson.*

Created by the co-director. One of the four [Paladins](../Factions/Assailant%20Ranks/Paladins.md), with private goals inside the five-way power struggle around [Cthulhu](Cthulhu.md).

Fullbone made [The Corruption](../Realms/The%20Corruption.md) and [The Crimson](../Realms/The%20Crimson.md), apparently from the dead of [The Ancient Great War](../Timeline/The%20Ancient%20Great%20War.md).

Proposed: the [Eater of Worlds](Eater%20of%20Worlds.md) and [Brain of Cthulhu](Brain%20of%20Cthulhu.md) are Fullbone's work too. When they die, Fullbone's Apothos tries to reclaim the remains and the Hero, trained in [Ingress](../Realms/Ingress.md), resists.

## Connections

- **Rank:** [Paladins](../Factions/Assailant%20Ranks/Paladins.md)
- **Serves, for now:** [Cthulhu](Cthulhu.md)
- **Created:** [The Corruption](../Realms/The%20Corruption.md), [The Crimson](../Realms/The%20Crimson.md)
- **Proposed creations:** [Eater of Worlds](Eater%20of%20Worlds.md), [Brain of Cthulhu](Brain%20of%20Cthulhu.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
