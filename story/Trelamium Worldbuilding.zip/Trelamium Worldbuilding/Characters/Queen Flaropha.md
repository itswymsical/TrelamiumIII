---
title: "Queen Flaropha"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Queen Flaropha

*A queen of the old wars who, aided by the Dryads, set out to destroy the less "divine" worlds, and who tortured Yakvala.*

The [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md) aided her. She betrayed [The Underworld](../Realms/The%20Underworld.md), [Archaea](../Realms/Archaea.md), [Seaforth](../Realms/Seaforth.md) and the other monster worlds. In the 2026 version she tortured [Yakvala](Yakvala.md) during [The Man and Monster War](../Timeline/The%20Man%20and%20Monster%20War.md) until he lost his mind.

## Connections

- **Aided by:** [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md)
- **Enemy:** [The Monster Empire](../Factions/The%20Monster%20Empire.md)
- **Tortured:** [Yakvala](Yakvala.md)
- **Realm:** [Excellia](../Realms/Excellia.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
