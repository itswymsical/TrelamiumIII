---
title: "Vessel of Luminance"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Vessel of Luminance

*The vessel of light that Luminance sent to moderate the Anthropos' wars. It shines through their architecture.*

In [Primordial Age II](../Timeline/Primordial%20Age%20II.md), [Luminance](../Cosmology/Luminance.md) saw the destruction of the Anthropos and sent a vessel of light to earth to moderate their quarrels and wars. It chose to shine through the [Architecture](../Cosmology/Architecture.md) they had built.

## Connections

- **Sent by:** [Luminance](../Cosmology/Luminance.md)
- **Era:** [Primordial Age II](../Timeline/Primordial%20Age%20II.md)
- **Counterpart:** [Vessel of Trelamium](Vessel%20of%20Trelamium.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
