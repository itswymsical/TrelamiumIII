---
title: "Edith"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Edith

*An Entfolk who keeps the front desk of the Library of Reverie and lends its books.*

Edith welcomes the Hero to Reverie and lends books by shelf: philosophy, history and fiction. A returned book has to come back with every page accounted for.

## Connections

- **People:** [Entfolk](../Peoples/Entfolk.md)
- **Keeps:** [Reverie](../Realms/Reverie.md)
- **Lends to:** [The Hero](The%20Hero.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
