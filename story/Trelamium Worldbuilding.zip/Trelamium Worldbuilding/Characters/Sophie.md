---
title: "Sophie"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# Sophie

*An Elysian engineer of gadgets and androids who lives in Archaea's cyber city. She is the city resident the Vespers respect most.*

Sophie keeps her gadgets in the city, but she has deep respect for the people of [Cactus County](../Realms/Cactus%20County.md) and for [Eustace](Eustace.md). When she visits them she brings none of her tech, only empty hands and open arms, and that's why the [Vespers](../Peoples/Vespers.md) respect her above every other Archaean. In the mod she's an NPC with a breezy greeting and little patience for being stared at.

## Connections

- **People:** [Elysians](../Peoples/Elysians.md)
- **Lives in:** [Archaea City](../Realms/Archaea%20City.md)
- **Respects:** [Eustace](Eustace.md), the [Vespers](../Peoples/Vespers.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
