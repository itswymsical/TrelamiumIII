---
title: "Saraphine"
date: 2026-10-11
type: character
status: concept
tags: [character]
aliases: ["Saraphine R. Ethers", "Saraphine S. Ethers", "Saraphine Z. Ethers"]
---

# Saraphine

*The Witch of Sight. She made Sight Energy to see the truth of the world and of every person, and lives as three personalities.*

Her sensitive past split her into personalities:

- **Saraphine R. Ethers** sees the future in its entirety.
- **Saraphine S. Ethers** sees the past of anything she witnesses.
- **Saraphine Z. Ethers**, the two combined, perceives the whole present and is close to omniscient, but she can stay awake only ten minutes before sleeping for six months while the other two take over.

Near her, people feel unprotected.

## Connections

- **One of:** [The Three Witches](../Factions/The%20Three%20Witches.md)
- **Made the soul of:** [The Mechanical Bosses](The%20Mechanical%20Bosses.md), with Sight Energy

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
