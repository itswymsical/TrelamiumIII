---
title: "King Slime"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The Gelatinous Monarch"]
---

# King Slime

*The Gelatinous Monarch: an ordinary blue slime given a crown filled with Apothos magick, which surged it with power.*

King Slime started as a single blue slime. Someone gave it a crown filled with [Apothos](../Magick%20and%20Systems/Apothos.md) magick, and the surge of power made it King Slime. For all that, it isn't especially powerful.

## Connections

- **Rules:** [Slimes](../Peoples/Slimes.md)
- **Crowned with:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Found in:** [Terraria](../Realms/Terraria.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
