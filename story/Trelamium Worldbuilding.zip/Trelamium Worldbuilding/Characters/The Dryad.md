---
title: "The Dryad"
date: 2026-10-11
type: character
status: canon
tags: [character]
---

# The Dryad

*A dryad from Sylvanwalde and the Hero's guide into Ingress. An old friend of the Guide, she crosses over through a rift after the Eye falls.*

From [Sylvanwalde](../Realms/Sylvanwalde.md), and one of the [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md). When the [Eye of Cthulhu](Eye%20of%20Cthulhu.md) dies, she feels the seal break even from [Ingress](../Realms/Ingress.md). [The Guide](The%20Guide.md), an old friend, calls her in, and she steps out of a rift near the Hero's town.

She tells the Hero that Apothos can't be fought the way they're used to, but it can be mitigated, and that she can teach them how. Then she opens a rift by the world's spawn and sends them through Ingress, past whatever guards it, into the Library of [Reverie](../Realms/Reverie.md).

## Connections

- **People:** [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md)
- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **Friend of:** [The Guide](The%20Guide.md)
- **Guides:** [The Hero](The%20Hero.md)
- **Opens the way to:** [Ingress](../Realms/Ingress.md), [Reverie](../Realms/Reverie.md)
- **Teaches against:** [Apothos](../Magick%20and%20Systems/Apothos.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
