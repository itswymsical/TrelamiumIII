---
title: "The Azolinth"
date: 2026-10-11
type: character
status: concept
tags: [character, boss]
---

# The Azolinth

*One of the four new bosses named in September 2026. Nothing else is defined.*

## Connections

- **Named with:** [Glacier](Glacier.md), [Pyron](Pyron.md), [Cumulor](Cumulor.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
