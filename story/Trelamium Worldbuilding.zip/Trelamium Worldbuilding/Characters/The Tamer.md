---
title: "The Tamer"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# The Tamer

*A woman in Dahlia's crew, known as the Tamer. Her name isn't settled yet.*

## Connections

- **Crew of:** [Dahlia](Dahlia.md)
- **Fought:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md), in [Sylvanwalde](../Realms/Sylvanwalde.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
