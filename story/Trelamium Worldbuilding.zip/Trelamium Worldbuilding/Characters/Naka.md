---
title: "Naka"
date: 2026-10-11
type: character
status: concept
tags: [character]
---

# Naka

*Dram's partner. Nothing else is set.*

## Connections

- **Partner:** [Dram](Dram.md)
- **Homeland:** [Chaotica](../Realms/Chaotica.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
