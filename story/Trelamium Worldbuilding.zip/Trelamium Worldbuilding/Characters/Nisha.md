---
title: "Nisha"
date: 2026-10-11
type: character
status: canon
tags: [character, assailant-crusade]
---

# Nisha

*A Paladin of the Crusade who completely destroyed Elysia, the Elysians' home planet, and has it out for the Anthropi.*

## Connections

- **Rank:** [Paladins](../Factions/Assailant%20Ranks/Paladins.md)
- **Serves, for now:** [Cthulhu](Cthulhu.md)
- **Rivals:** [Fullbone](Fullbone.md), [Erahoka](Erahoka.md), [Callisto](Callisto.md)
- **Destroyed:** [Elysia](../Realms/Elysia.md)
- **Hates:** [Anthropos](../Peoples/Anthropos.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
