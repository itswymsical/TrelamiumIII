---
title: "Hesper"
date: 2026-10-11
type: character
status: canon
tags: [character]
aliases: ["The evening star"]
---

# Hesper

*A country woman Laine L. loved and pulled into his world, who was never the same after. She will be a significant character in the future.*

Her name means the evening star. In the current draft she is quick, impatient with fools, vain about her hands, and content where she is: "I am not bright in the way you think. I am bright here." Laine takes her from her village to the city, and over the years she changes completely, until she is calm, gracious and unchanging. She is still alive at the end of his book.

## Connections

- **Loved by:** [Laine L](Laine%20L.md)
- **People:** [Anthropos](../Peoples/Anthropos.md) *(inferred)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
