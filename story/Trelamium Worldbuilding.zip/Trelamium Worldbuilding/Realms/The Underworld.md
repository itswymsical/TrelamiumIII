---
title: "The Underworld"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# The Underworld

*The vanilla Underworld: one of the "monster"-harboring worlds betrayed in the old wars, and the Wall of Flesh's domain.*

In the August 2025 notes, [Queen Flaropha](../Characters/Queen%20Flaropha.md) and the Dryads betrayed the Underworld along with [Archaea](Archaea.md), [Seaforth](Seaforth.md) and the other monster worlds. The [Wall of Flesh](../Characters/Wall%20of%20Flesh.md) guards it.

## Connections

- **Guarded by:** [Wall of Flesh](../Characters/Wall%20of%20Flesh.md)
- **Part of:** [The Monster Empire](../Factions/The%20Monster%20Empire.md) *(inferred)*
- **Betrayed by:** [Queen Flaropha](../Characters/Queen%20Flaropha.md)
- **Related:** [Chaotica](Chaotica.md), the old name for ancient hell

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
