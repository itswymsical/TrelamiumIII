---
title: "Temple of Ingress"
date: 2026-10-11
type: place
status: canon
tags: [place]
aliases: ["Ligneous Fortress", "Altar of Ingress"]
---

# Temple of Ingress

*The temple, or Ligneous Fortress, that the Wooden Warden protects. The Hero awakens the Warden at its Altar of Ingress.*

The Lore Bible calls it a temple; the Warden's bestiary entry calls the Warden "the Protector of the Ligneous Fortress". At the Altar of Ingress, the Hero can awaken the Warden.

## Connections

- **Located in:** [Ingress](Ingress.md)
- **Protected by:** [Wooden Warden](../Characters/Wooden%20Warden.md)
- **Near:** [Scar of Ingress](Scar%20of%20Ingress.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
