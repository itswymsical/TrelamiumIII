---
title: "Reverie"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
aliases: ["Library of Reverie", "Breviary"]
---

# Reverie

*The Library of Reverie, a subworld where every book that has ever existed rests somewhere. Edith keeps the front desk and lends books that teach lore and magick.*

The Hero reaches it through [Ingress](Ingress.md), past the [Wooden Warden](../Characters/Wooden%20Warden.md). The stacks are walkways reached by rope. [Edith](../Characters/Edith.md) keeps the front desk and lends books by shelf (philosophy, history and fiction), and every borrowed book has to come back with every page accounted for. Reading them grants [Experiential Points](../Magick%20and%20Systems/Experiential%20Points.md). The Lore Bible called these the Breviary books.

"Reverie" comes from the old French *resverie*: delirium, raving, a mind wandering out of its own house. [Laine L](../Characters/Laine%20L.md) builds the last chapter of his book on that meaning.

**Known books:**

- *Illuminance I* and *Illuminance II*, by [Laine L](../Characters/Laine%20L.md). The second volume isn't written yet.
- *Root and Reason*, *Of Quiet Seasons* and *The Weight of Light*: titles only so far.

The mod's book files also hold *Corridor of Darkness* (an unnamed writer, shut in for 111 days, "keeping the luminant light waiting"), *Annie's Diary* (a lonely girl and her pet "babu") and *A Proclamation* (Abraham Lincoln's Emancipation Proclamation).

## Connections

- **Reached through:** [Ingress](Ingress.md), past the [Wooden Warden](../Characters/Wooden%20Warden.md)
- **Keeper:** [Edith](../Characters/Edith.md)
- **Holds the works of:** [Laine L](../Characters/Laine%20L.md)
- **Grants:** [Experiential Points](../Magick%20and%20Systems/Experiential%20Points.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
