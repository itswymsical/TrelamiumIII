---
title: "Scar of Ingress"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# Scar of Ingress

*A wound in Ingress that the Wooden Warden was ordered to protect, along with whatever lies behind it.*

The Warden's bestiary calls it "a sentient golem ordered to protect the Scar of Ingress, and what lies behind it". The Dryad's job sends the Hero "past whatever guards it, and into the Library of Reverie", so the Scar most likely opens onto [Reverie](Reverie.md) *(inferred)*. The way back through it reads "Return to Ingress".

## Connections

- **Located in:** [Ingress](Ingress.md)
- **Guarded by:** [Wooden Warden](../Characters/Wooden%20Warden.md)
- **Opens onto:** [Reverie](Reverie.md) *(inferred)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
