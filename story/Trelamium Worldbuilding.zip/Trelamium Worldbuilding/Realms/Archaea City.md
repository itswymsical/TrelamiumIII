---
title: "Archaea City"
date: 2026-10-11
type: place
status: canon
tags: [place]
aliases: ["The cyber city"]
---

# Archaea City

*Archaea's massive cyberpunk city: very progressive and super fast with technology, at the cost of the land and of how it treats others. Working name.*

"Archaea City" is a working name. The [Vespers](../Peoples/Vespers.md) of [Cactus County](Cactus%20County.md) won't associate with its people because of what they've done to the land and how they treat others. [Sophie](../Characters/Sophie.md) lives here.

## Connections

- **Part of:** [Archaea](Archaea.md)
- **Home of:** [Sophie](../Characters/Sophie.md)
- **Shunned by:** [Vespers](../Peoples/Vespers.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
