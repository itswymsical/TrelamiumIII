---
title: "Obsidian Forest"
date: 2026-10-11
type: place
status: proposed
tags: [place]
---

# Obsidian Forest

*A planned cavern-layer biome just above hell, and one of the Assailants' three strongholds.*

In the August 2025 plan, the Assailants hold strongholds in [The Corruption](The%20Corruption.md), [The Crimson](The%20Crimson.md) and the Obsidian Forest. The Corruption stronghold comes first, and the Obsidian Forest ties into the rest of that act once it's cleared.

## Connections

- **Located in:** [Terraria](Terraria.md), just above [The Underworld](The%20Underworld.md)
- **Held by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
