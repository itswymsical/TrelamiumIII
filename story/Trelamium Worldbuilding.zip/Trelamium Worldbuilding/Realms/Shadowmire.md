---
title: "Shadowmire"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# Shadowmire

*The district of Sylvanwalde where the Gleplins live and mine coal and other resources.*

## Connections

- **Part of:** [Sylvanwalde](Sylvanwalde.md)
- **Home of:** [Gleplins](../Peoples/Gleplins.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
