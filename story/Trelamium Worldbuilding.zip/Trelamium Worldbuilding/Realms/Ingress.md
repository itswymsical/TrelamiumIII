---
title: "Ingress"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Ingress

*An inner state played as a full subworld: a forest of wooden folk over a maze of caverns, with the Scar of Ingress guarded at its heart. The Hero goes there to learn self-understanding.*

The only dimension that is an inner state rather than a place. After the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) falls, [The Dryad](../Characters/The%20Dryad.md) opens a rift by the world's spawn and sends the Hero inward to understand themselves. A matching rift by Ingress's own spawn leads home.

In game it is a full subworld:

- **The surface:** a fantasy forest of ligneous folk ([Entfolk](../Peoples/Entfolk.md) and the [Mud-Spirit Folk](../Peoples/Mud-Spirit%20Folk.md)), with living trees that never grow close to where you arrive.
- **Brambleroot:** the cavern network beneath all of Ingress, where every cavern connects to another. Bushwhacks, bundles of foliage walking on their roots, wander its Garden of Ingress.
- **The heart:** "Something was built at the heart of the Ingress caverns", most likely the [Temple of Ingress](Temple%20of%20Ingress.md) *(inferred)*.
- **The way on:** the [Wooden Warden](../Characters/Wooden%20Warden.md) guards the [Scar of Ingress](Scar%20of%20Ingress.md) "and what lies behind it", which leads to [Reverie](Reverie.md) *(inferred)*.

Ingress gives the Hero the [Clarifying Language](../Magick%20and%20Systems/Clarifying%20Language.md) that counters [Apothos](../Magick%20and%20Systems/Apothos.md), which a sword or bow cannot.

## Connections

- **Entered through:** the rift of [The Dryad](../Characters/The%20Dryad.md)
- **Visited by:** [The Hero](../Characters/The%20Hero.md)
- **Peoples:** [Entfolk](../Peoples/Entfolk.md), [Mud-Spirit Folk](../Peoples/Mud-Spirit%20Folk.md)
- **Places:** [Temple of Ingress](Temple%20of%20Ingress.md), [Scar of Ingress](Scar%20of%20Ingress.md)
- **Guardian:** [Wooden Warden](../Characters/Wooden%20Warden.md)
- **Leads to:** [Reverie](Reverie.md) *(inferred)*
- **Teaches:** [Clarifying Language](../Magick%20and%20Systems/Clarifying%20Language.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
