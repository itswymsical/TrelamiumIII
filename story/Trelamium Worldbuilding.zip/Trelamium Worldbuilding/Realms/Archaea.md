---
title: "Archaea"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Archaea

*A world split between a massive, fast-moving cyberpunk city and the traditional Vespers of Cactus County on its outskirts. Its hero, Eustace, warded off the Crusade.*

Archaea's heart is [Archaea City](Archaea%20City.md), a huge cyberpunk city: very progressive and racing ahead with technology. Out past it lies [Cactus County](Cactus%20County.md), home of the [Vespers](../Peoples/Vespers.md), who are traditional and conservative and keep their distance from the city because of what it has done to the land and how it treats others.

[Eustace](../Characters/Eustace.md), the Vespers' most respected figure, is the hero of Archaea: one of the [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md) who led their worlds in fighting off the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md). [Sophie](../Characters/Sophie.md), an Elysian engineer from the city, is the one city resident the Vespers truly respect.

In the 2025 notes, Archaea was also one of the "monster"-harboring worlds that [Queen Flaropha](../Characters/Queen%20Flaropha.md) betrayed.

## Connections

- **Places:** [Archaea City](Archaea%20City.md), [Cactus County](Cactus%20County.md)
- **Peoples:** [Archaeans](../Peoples/Archaeans.md), [Vespers](../Peoples/Vespers.md)
- **Hero:** [Eustace](../Characters/Eustace.md)
- **Fought off:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) *(inferred from Eustace's title)*
- **Part of:** [The Monster Empire](../Factions/The%20Monster%20Empire.md) *(inferred, 2025)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
