---
title: "Glowshroom Grotto"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# Glowshroom Grotto

*An underground microbiome that always spawns inside one of the world's glowing mushroom biomes. Argie lives there.*

## Connections

- **Located in:** [Terraria](Terraria.md), inside a glowing mushroom biome
- **Home of:** [Argie](../Characters/Argie.md)
- **Related:** [Mycology](../Magick%20and%20Systems/Mycology.md), [Myconids](../Peoples/Myconids.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
