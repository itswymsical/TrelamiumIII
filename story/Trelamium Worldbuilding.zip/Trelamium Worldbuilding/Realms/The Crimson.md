---
title: "The Crimson"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# The Crimson

*An evil biome in Terraria that Fullbone created, and one of the Assailants' strongholds.*

The Assailants keep small fortresses and camps here that the player can raid for loot, likely with a mini-boss or two. The camps are held by Fiend-rank troops: the [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), the [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md) and the [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md).

Proposed: the [Brain of Cthulhu](../Characters/Brain%20of%20Cthulhu.md) is grown from the dead soldiers' blood, and an Assailant fortress here holds its summoning ritual.

## Connections

- **Created by:** [Fullbone](../Characters/Fullbone.md)
- **Located in:** [Terraria](Terraria.md)
- **Made from:** the dead of [The Ancient Great War](../Timeline/The%20Ancient%20Great%20War.md) *(open question)*
- **Occupied by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Troops:** [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md), [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md)
- **Boss (proposed):** [Brain of Cthulhu](../Characters/Brain%20of%20Cthulhu.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
