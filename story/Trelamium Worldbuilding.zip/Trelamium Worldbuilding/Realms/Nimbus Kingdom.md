---
title: "Nimbus Kingdom"
date: 2026-10-11
type: realm
status: concept
tags: [realm]
aliases: ["Sky dimension"]
---

# Nimbus Kingdom

*A sky dimension filled with Greedy Gods, the nimbus people, ruled by Aureolus. Working name.*

"Nimbus Kingdom" is a working name. It was planned as the setting for the unfinished boss [Cumulor](../Characters/Cumulor.md), the Exiled Son.

## Connections

- **Ruler:** [Aureolus](../Characters/Aureolus.md)
- **People:** [Nimbus People](../Peoples/Nimbus%20People.md)
- **Exile:** [Cumulor](../Characters/Cumulor.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
