---
title: "Elysia"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Elysia

*The Elysians' home planet, completely eradicated by the Paladin Nisha.*

## Connections

- **People:** [Elysians](../Peoples/Elysians.md)
- **Destroyed by:** [Nisha](../Characters/Nisha.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
