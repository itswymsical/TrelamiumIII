---
title: "Sylvanwalde"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
aliases: ["Sylvan Walde", "Sylvanwald"]
---

# Sylvanwalde

*The Dryad's homeland: a taiga subworld split into three districts and ruled from the surface by classist elves. Dahlia turned back the Crusade here.*

Planned as a subworld rather than part of the main world, probably a taiga. A great tree sustains the realm, in the spirit of Yggdrasil. The surface has a classic fantasy-RPG feel, with taverns, side missions and quests and an old Scottish or Irish flavor.

Sylvanwalde is cut into three districts:

- **[Sylvanwalde Surface](Sylvanwalde%20Surface.md):** home of the ruling [Elves](../Peoples/Elves.md), with the [Fairies](../Peoples/Fairies.md) living among them as second-class citizens.
- **[Druid's Garden](Druid's%20Garden.md):** the Druid's Garden.
- **[Shadowmire](Shadowmire.md):** where the [Gleplins](../Peoples/Gleplins.md) live and mine coal and other resources.

Discrimination runs through all of it. The elves hold power, think highly of themselves, and look down on everyone beneath them. Two elves are the exception: [Dahlia](../Characters/Dahlia.md) and her son. Dahlia is the hero of Sylvanwalde; with her crew she stopped the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) here.

In the old wars, Sylvanwalde joined the [Archivers](../Peoples/Archivers.md) and [Excellia](Excellia.md) in planning to purge the [Demons](../Peoples/Demons.md), and the [Wall of Flesh](../Characters/Wall%20of%20Flesh.md) was made to stop them.

## Connections

- **Districts:** [Sylvanwalde Surface](Sylvanwalde%20Surface.md), [Druid's Garden](Druid's%20Garden.md), [Shadowmire](Shadowmire.md)
- **Peoples:** [Elves](../Peoples/Elves.md), [Fairies](../Peoples/Fairies.md), [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md), [Gleplins](../Peoples/Gleplins.md)
- **Homeland of:** [The Dryad](../Characters/The%20Dryad.md), [Dahlia](../Characters/Dahlia.md)
- **Defended from:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Planned to purge:** [Demons](../Peoples/Demons.md), with [Archivers](../Peoples/Archivers.md) and [Excellia](Excellia.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
