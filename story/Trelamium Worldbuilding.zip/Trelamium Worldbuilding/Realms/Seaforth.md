---
title: "Seaforth"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
aliases: ["Sea Forth"]
---

# Seaforth

*Cthulhu's homeland, ruled by a nobility that denied him the throne. The Sea Folk come from here.*

A dimension ruled by the [Seaforth Nobility](../Factions/Seaforth%20Nobility.md). [Cthulhu](../Characters/Cthulhu.md) was born here to a commoner mother and the king. When the nobility refused him the throne, the [Seaforth Revolution](../Timeline/The%20Seaforth%20Revolution.md) began, and with it the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md).

## Connections

- **Ruled by:** [Seaforth Nobility](../Factions/Seaforth%20Nobility.md)
- **Peoples:** [Sea Folk](../Peoples/Sea%20Folk.md), [Cephalopods](../Peoples/Cephalopods.md) *(inferred from Cthulhu)*
- **Birthplace of:** [Cthulhu](../Characters/Cthulhu.md)
- **Event:** [The Seaforth Revolution](../Timeline/The%20Seaforth%20Revolution.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
