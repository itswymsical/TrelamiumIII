---
title: "Terraria"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Terraria

*The vanilla world, the epicenter of the universe, and the first dimension the Assailants target.*

Where the game begins and the Hero lives. In Gerjingle's cosmology, Terraria is the epicenter of the universe that [The Red God](../Characters/The%20Red%20God.md) and [The Celestial Torment](../Characters/The%20Celestial%20Torment.md) designed. The [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) targets it first, holding strongholds in [The Corruption](The%20Corruption.md), [The Crimson](The%20Crimson.md) and the [Obsidian Forest](Obsidian%20Forest.md).

Most vanilla creatures live here: [Goblins](../Peoples/Goblins.md), [Skeletons](../Peoples/Skeletons.md), [Zombies](../Peoples/Zombies.md), [Slimes](../Peoples/Slimes.md), [Watchers](../Peoples/Watchers.md), [Myconids](../Peoples/Myconids.md) and [Annelids](../Peoples/Annelids.md). [Argie](../Characters/Argie.md) lives in the [Glowshroom Grotto](Glowshroom%20Grotto.md), a microbiome inside a glowing mushroom biome, and [The Underworld](The%20Underworld.md) lies beneath it all.

## Connections

- **Home of:** [The Hero](../Characters/The%20Hero.md)
- **Contains:** [The Corruption](The%20Corruption.md), [The Crimson](The%20Crimson.md), [Obsidian Forest](Obsidian%20Forest.md), [Glowshroom Grotto](Glowshroom%20Grotto.md)
- **Below it:** [The Underworld](The%20Underworld.md)
- **Designed by:** [The Red God](../Characters/The%20Red%20God.md), [The Celestial Torment](../Characters/The%20Celestial%20Torment.md)
- **Targeted by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Watched by:** [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
