---
title: "Hyperborea"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Hyperborea

*A frozen dimension, home of the Hyperboreans and of the frost giant Permafrost, who lives on one of its frozen mountains.*

In Greek myth, Hyperborea is the land "beyond the north wind". In game it is cold and seldom visited. [Permafrost](../Characters/Permafrost.md) lives on a frozen mountain there and greets the Hero by saying it's been a long time since anyone ventured into these frozen lands. [Glacier](../Characters/Glacier.md), Permafrost's eye, is a Hyperborean watcher.

## Connections

- **People:** [Hyperboreans](../Peoples/Hyperboreans.md), [Frost Giants](../Peoples/Frost%20Giants.md) *(inferred from Permafrost)*
- **Home of:** [Permafrost](../Characters/Permafrost.md), [Glacier](../Characters/Glacier.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
