---
title: "Cactus County"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# Cactus County

*The outskirts of Archaea's cyber city, where the traditional Vespers live.*

## Connections

- **Part of:** [Archaea](Archaea.md), outside [Archaea City](Archaea%20City.md)
- **Home of:** [Vespers](../Peoples/Vespers.md), [Eustace](../Characters/Eustace.md)
- **Welcomed visitor:** [Sophie](../Characters/Sophie.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
