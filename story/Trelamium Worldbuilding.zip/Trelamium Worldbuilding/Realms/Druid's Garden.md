---
title: "Druid's Garden"
date: 2026-10-11
type: place
status: canon
tags: [place]
aliases: ["The Druid's Garden"]
---

# Druid's Garden

*One of the three districts of Sylvanwalde.*

## Connections

- **Part of:** [Sylvanwalde](Sylvanwalde.md)
- **Home of:** [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md) *(inferred from its name)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
