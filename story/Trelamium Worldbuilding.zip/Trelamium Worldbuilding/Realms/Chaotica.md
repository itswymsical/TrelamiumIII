---
title: "Chaotica"
date: 2026-10-11
type: realm
status: canon
tags: [realm]
---

# Chaotica

*An old name for ancient hell, possibly made by Behema. Home of Pyron, and of Dram and his family.*

Gerjingle is drawing up a relation chart for its characters.

## Connections

- **Home of:** [Pyron](../Characters/Pyron.md), [Dram](../Characters/Dram.md), [Titan](../Characters/Titan.md) *(inferred)*, [Naka](../Characters/Naka.md) *(inferred)*
- **Peoples:** [Demons](../Peoples/Demons.md), [Bone Demons](../Peoples/Bone%20Demons.md) *(inferred)*
- **Made by:** [Behema](../Characters/Behema.md) *(if Behema is a demiurge)*
- **Related:** [The Underworld](The%20Underworld.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
