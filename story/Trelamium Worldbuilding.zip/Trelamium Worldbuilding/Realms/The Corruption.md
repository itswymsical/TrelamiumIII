---
title: "The Corruption"
date: 2026-10-11
type: place
status: canon
tags: [place]
---

# The Corruption

*An evil biome in Terraria that Fullbone created, and the Assailants' first stronghold.*

The Assailants keep their first stronghold here: small fortresses and camps the player can raid for loot, likely with a mini-boss or two. The camps are held by Fiend-rank troops: the [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), the [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md) and the [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md). A barbarian Assailant boss, fought before the Eater of Worlds, has been floated for these camps.

Proposed: the [Eater of Worlds](../Characters/Eater%20of%20Worlds.md) is the dead soldiers' twisted souls compacted into one body, and an Assailant fortress here holds its summoning ritual.

## Connections

- **Created by:** [Fullbone](../Characters/Fullbone.md)
- **Located in:** [Terraria](Terraria.md)
- **Made from:** the dead of [The Ancient Great War](../Timeline/The%20Ancient%20Great%20War.md) *(open question)*
- **Occupied by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Troops:** [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md), [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md)
- **Boss (proposed):** [Eater of Worlds](../Characters/Eater%20of%20Worlds.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
