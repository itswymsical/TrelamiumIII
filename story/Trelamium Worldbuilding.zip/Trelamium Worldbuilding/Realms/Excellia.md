---
title: "Excellia"
date: 2026-10-11
type: realm
status: concept
tags: [realm]
---

# Excellia

*A realm of the old history whose royals the Dryads turned against the Monster Empire. Yakvala's story belongs to it.*

In the August 2025 notes, the [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md) convinced the Royals of Excellia that the [Monster Empire](../Factions/The%20Monster%20Empire.md) was "unholy" and should be purged, which pushed Excellia toward betraying the other worlds. In the September 2026 notes, Excellia joined the [Archivers](../Peoples/Archivers.md) and [Sylvanwalde](Sylvanwalde.md) in planning to purge the [Demons](../Peoples/Demons.md), and the [Wall of Flesh](../Characters/Wall%20of%20Flesh.md) was made to stop them. [Yakvala](../Characters/Yakvala.md), who built the mechs, is "mostly part of Excellia lore".

## Connections

- **Turned by:** [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md)
- **Enemy of:** [The Monster Empire](../Factions/The%20Monster%20Empire.md)
- **Planned to purge:** [Demons](../Peoples/Demons.md), with [Archivers](../Peoples/Archivers.md) and [Sylvanwalde](Sylvanwalde.md)
- **Figures:** [Yakvala](../Characters/Yakvala.md); [Queen Flaropha](../Characters/Queen%20Flaropha.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
