---
title: "Sylvanwalde Surface"
date: 2026-10-11
type: place
status: canon
tags: [place]
aliases: ["The Surface"]
---

# Sylvanwalde Surface

*The surface district of Sylvanwalde, where the ruling elves live and the fairies are treated as second-class citizens.*

## Connections

- **Part of:** [Sylvanwalde](Sylvanwalde.md)
- **Ruled by:** [Elves](../Peoples/Elves.md)
- **Also home to:** [Fairies](../Peoples/Fairies.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
