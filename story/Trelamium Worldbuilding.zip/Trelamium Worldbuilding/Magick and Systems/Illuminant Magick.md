---
title: "Illuminant Magick"
date: 2026-10-11
type: magick
status: concept
tags: [magick]
---

# Illuminant Magick

*A type of magick practiced by Saint Jerwin. Not yet defined.*

## Connections

- **Practiced by:** [Saint Jerwin](../Characters/Saint%20Jerwin.md)
- **Related:** [Illuminance](../Cosmology/Illuminance.md), [Luminance](../Cosmology/Luminance.md) *(inferred from the name)*
- **Documented by:** [Archivers](../Peoples/Archivers.md) *(inferred)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
