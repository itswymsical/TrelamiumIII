---
title: "Apothos"
date: 2026-10-11
type: magick
status: canon
tags: [magick]
aliases: ["Apathos", "Void Hymn", "Apothos magick"]
---

# Apothos

*The ancient magick of Cthulhu and the Assailants. It nullifies whatever it takes hold of; a sword can't fight it, but clarifying language and self-understanding can mitigate it.*

Like everything dark, Apothos grows from the dark's side of the seeding of [Quality](../Cosmology/Quality.md). Its first followers, before Cthulhu rose, called it the Void Hymn ([The Void Whisperers](../Factions/The%20Void%20Whisperers.md)). The Chronicle shows the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) practicing it in [Primordial Age III](../Timeline/Primordial%20Age%20III.md). [Cthulhu](../Characters/Cthulhu.md) discovered it during [The Seaforth Revolution](../Timeline/The%20Seaforth%20Revolution.md), and the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) wields it. In game, [The Guide](../Characters/The%20Guide.md) describes it as an ancient, dangerous magick that nullifies anything it gets hold of.

The death of the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) loosened a seal and let it back into the world. Assailants use it to pull the Eye's remains into a [Trelamium](../Cosmology/Trelamium.md) vortex, and a crown full of it turned a blue slime into [King Slime](../Characters/King%20Slime.md). It corrupted [Yakvala](../Characters/Yakvala.md), and [Permafrost](../Characters/Permafrost.md) studied it until it led him to [Iniki](../Characters/Iniki.md). [Corithian](../Characters/Corithian.md) practices it as a priest.

It can't be fought with a sword or bow. It can be mitigated with [Clarifying Language](Clarifying%20Language.md) and self-understanding, which the Hero gains in [Ingress](../Realms/Ingress.md).

## Connections

- **Grows from:** [Quality](../Cosmology/Quality.md), on the dark's side
- **First followers:** [The Void Whisperers](../Factions/The%20Void%20Whisperers.md)
- **Practiced by:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md), [Corithian](../Characters/Corithian.md)
- **Discovered by:** [Cthulhu](../Characters/Cthulhu.md)
- **Wielded by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Released by the death of:** [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)
- **Corrupted:** [Yakvala](../Characters/Yakvala.md)
- **Studied by:** [Permafrost](../Characters/Permafrost.md)
- **Countered by:** [Clarifying Language](Clarifying%20Language.md)
- **Feeds:** [Trelamium](../Cosmology/Trelamium.md)
- **Empowers:** [King Slime](../Characters/King%20Slime.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
