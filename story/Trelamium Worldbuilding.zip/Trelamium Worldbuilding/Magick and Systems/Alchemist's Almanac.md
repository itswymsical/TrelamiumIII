---
title: "Alchemist's Almanac"
date: 2026-10-11
type: system
status: canon
tags: [system]
aliases: ["The Alchemist's Almanac", "Uncle J's almanac"]
---

# Alchemist's Almanac

*John Substrate's handwritten alchemy book. Silvian gives it to the Hero, and it teaches alchemy one earned page at a time.*

Every page is in John Substrate's own hand, with room left in the back "for whatever he didn't know". The book sorts itself: Recipes lists every brew the Hero can make, Ingredients explains each reagent, and dropping an item into its side slot shows only what uses it. Most pages stay blank until earned: "Secrets are earned, not handed over."

It opens with a foreword to [Silvian](../Characters/Silvian.md), followed by short chapters on the seven principles, the six temperaments, solvents and solutes, potency, and a little Latin. Each ingredient gets a dry one-line description in Uncle J's voice.

Because the alchemy system is deep, the Hero keeps learning from the Almanac for the whole game.

## Connections

- **Written by:** [John Substrate](../Characters/John%20Substrate.md)
- **Given by:** [Silvian](../Characters/Silvian.md)
- **Teaches:** [Alchemy](Alchemy.md)
- **Owned by:** [The Hero](../Characters/The%20Hero.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
