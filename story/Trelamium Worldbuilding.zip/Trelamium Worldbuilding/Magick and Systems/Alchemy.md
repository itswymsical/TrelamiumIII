---
title: "Alchemy"
date: 2026-10-11
type: magick
status: canon
tags: [magick]
---

# Alchemy

*The language and symbolism the Anthropos used to work magick after their revolution. The Church practiced it; the Hero learns it from John Substrate's almanac.*

After [The Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md), the Anthropos worked magick through the language and symbolism of alchemy, which produced dark forces, grimoires and new types of magick. The [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) grew out of the practice.

The greatest alchemist who ever lived was [John Substrate](../Characters/John%20Substrate.md). His [Alchemist's Almanac](Alchemist's%20Almanac.md) reaches the Hero through his nephew [Silvian](../Characters/Silvian.md), and his old apprentice [Argie](../Characters/Argie.md) teaches its low-level forms through [Mycology](Mycology.md). The system is deep, so the learning never really stops. It also carries the setting's central idea: ideals and perception shape who you are (see [Demiurges](../Cosmology/Demiurges.md)).

**How it works, per the Almanac and Silvian:**

- Every brew starts with a **solvent**, usually bottled water, in the alchemy station's large slot. **Solutes** (herbs, ores, fish) dissolve into it, and **reagents** (salts, acids, powders) change a brew without steering it. The result is a **solution**, which can be drunk or built on.
- **Seven principles** decide what a brew does: Vital, Specular, Martial, Brisk, Fortune, Harmony and Bane. Each has a metal; gold is Vital and iron is Martial.
- **Six temperaments**, in three opposed pairs, describe how a substance behaves: acidic and alkaline, volatile and kinetic, catalytic and inert. Opposites cancel.
- **Potency** runs from one to five stars, set by how many portions of a solute go in.

**In game (implemented):** transmute items into potions and serums, turn liquids into other liquids, and craft gear, with elemental and chemical damage types and the Controller class built on top.

## Connections

- **Born in:** [The Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md)
- **Practiced by:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md), [John Substrate](../Characters/John%20Substrate.md), [The Hero](../Characters/The%20Hero.md)
- **Taught by:** [Alchemist's Almanac](Alchemist's%20Almanac.md), [Silvian](../Characters/Silvian.md), [Argie](../Characters/Argie.md)
- **Branches:** [Mycology](Mycology.md)
- **System design:** [Alchemy System](../Alchemy%20System.canvas)
- **Related magick:** [Apothos](Apothos.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
