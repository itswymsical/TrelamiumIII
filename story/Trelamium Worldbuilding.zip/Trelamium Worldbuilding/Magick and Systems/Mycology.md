---
title: "Mycology"
date: 2026-10-11
type: magick
status: canon
tags: [magick]
---

# Mycology

*The study of fungi, and the way into low-level alchemy that Argie opens for the Hero.*

Early in the game, [Argie](../Characters/Argie.md) gives the Hero access to mycology content and specific low-level forms of [Alchemy](Alchemy.md). She learned it as John Substrate's young apprentice.

## Connections

- **Taught by:** [Argie](../Characters/Argie.md)
- **Branch of:** [Alchemy](Alchemy.md)
- **Home of its teacher:** [Glowshroom Grotto](../Realms/Glowshroom%20Grotto.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
