---
title: "Magick Practitioners"
date: 2026-10-11
type: role
status: canon
tags: [role]
---

# Magick Practitioners

*A role some characters hold across factions: practitioners of a school of magick.*

## Connections

- **Known practitioners:** [Saint Jerwin](../Characters/Saint%20Jerwin.md) ([Illuminant Magick](Illuminant%20Magick.md)); the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md), [Cthulhu](../Characters/Cthulhu.md) and [Corithian](../Characters/Corithian.md) ([Apothos](Apothos.md)); [Permafrost](../Characters/Permafrost.md) (ice magick, and a scholar of Apothos); [John Substrate](../Characters/John%20Substrate.md) and [The Hero](../Characters/The%20Hero.md) ([Alchemy](Alchemy.md)); [Argie](../Characters/Argie.md) ([Mycology](Mycology.md))

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
