---
title: "Experiential Points"
date: 2026-10-11
type: system
status: canon
tags: [system]
aliases: ["XP"]
---

# Experiential Points

*The game's form of qualia, earned from sandbox actions rather than kills and spent on skills. Implemented.*

Earned by collecting specific items, breaking specific blocks, building certain structures and encountering enemies, so the economy doesn't rest on trivial repeatable acts like breaking pots, looting chests or selling. Reading [Reverie](../Realms/Reverie.md) books also grants them.

Spent on **skills**, such as a custom dash, accessory effects, or throwing the pickaxe as a boomerang. Some are implemented.

Thematically this is [Qualia](../Cosmology/Qualia.md), the same thing the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) hunts.

## Connections

- **Lore form:** [Qualia](../Cosmology/Qualia.md)
- **Earned by:** [The Hero](../Characters/The%20Hero.md)
- **Granted by:** [Reverie](../Realms/Reverie.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
