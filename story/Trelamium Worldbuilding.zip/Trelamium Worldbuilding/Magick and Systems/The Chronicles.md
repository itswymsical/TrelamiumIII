---
title: "The Chronicles"
date: 2026-10-11
type: system
status: proposed
tags: [system]
---

# The Chronicles

*In-world books, planned in 2025, that carry the early story and lead up to the Eye of Cthulhu.*

From the August 2025 plan, where the books were the catalyst for the Eye fight:

1. A Chronicle drops from the [Trash Beast](../Characters/The%20Trash%20Beast.md), and the Hero brings it to [The Guide](../Characters/The%20Guide.md).
2. The beast mentions a second Chronicle, stolen by Assailants, and points to their base in [The Corruption](../Realms/The%20Corruption.md).
3. While the Hero prepares, slime starts raining from the sky, the slime rain that brings [King Slime](../Characters/King%20Slime.md).
4. Then the Assailants come into play in Act 2, across their strongholds in the Corruption, [The Crimson](../Realms/The%20Crimson.md) and the [Obsidian Forest](../Realms/Obsidian%20Forest.md).

An earlier version spawned a Chronicle after the Hero broke 25 pots during the Merchant's first job.

## Connections

- **Dropped by:** [The Trash Beast](../Characters/The%20Trash%20Beast.md)
- **Read by:** [The Guide](../Characters/The%20Guide.md)
- **Stolen by:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)
- **Lead to:** [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
