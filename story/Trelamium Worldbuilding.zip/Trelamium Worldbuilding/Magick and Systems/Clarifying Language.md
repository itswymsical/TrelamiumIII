---
title: "Clarifying Language"
date: 2026-10-11
type: magick
status: canon
tags: [magick]
aliases: ["Self-understanding"]
---

# Clarifying Language

*The counter to Apothos: language that clarifies, and the self-understanding the Hero gains in Ingress.*

The Dryad tells the Hero that Apothos can't be fought with a sword. [Ingress](../Realms/Ingress.md) gives them the clarifying language to fight it.

**Proposed mechanic:** a tangible unlock after Ingress, such as a skill or alchemical rite that breaks Apothos shields or Assailant wards.

## Connections

- **Counters:** [Apothos](Apothos.md)
- **Learned in:** [Ingress](../Realms/Ingress.md)
- **Learned by:** [The Hero](../Characters/The%20Hero.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
