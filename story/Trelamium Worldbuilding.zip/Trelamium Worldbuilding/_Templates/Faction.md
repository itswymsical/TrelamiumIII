---
title: "{{title}}"
date: "{{date}}"
type: faction
status: concept
tags: [faction]
aliases: []
---

# {{title}}

*One-line summary of the group and its goal.*

## Connections

- **Led by:**
- **Members:**
- **Goal:**
- **Allies:**
- **Enemies:**

Sources:
