---
title: "{{title}}"
date: "{{date}}"
type: realm
status: concept
tags: [realm]
aliases: []
---

# {{title}}

*One-line summary of the place.*

## Connections

- **Peoples:**
- **Notable figures:**
- **Places within:**
- **Ruled or held by:**

Sources:
