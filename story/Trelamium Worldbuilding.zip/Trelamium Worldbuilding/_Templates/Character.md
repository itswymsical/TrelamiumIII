---
title: "{{title}}"
date: "{{date}}"
type: character
status: concept
tags: [character]
aliases: []
---

# {{title}}

*One-line summary of who they are and why they matter.*

## Connections

- **People:**
- **Homeland:**
- **Faction:**
- **Rank or role:**
- **Allies:**
- **Rivals:**

Sources:
