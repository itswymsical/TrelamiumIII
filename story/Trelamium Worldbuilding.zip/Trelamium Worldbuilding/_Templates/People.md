---
title: "{{title}}"
date: "{{date}}"
type: people
status: concept
tags: [people]
aliases: []
---

# {{title}}

*One-line summary of what they are.*

## Connections

- **Homeland:**
- **Known members:**
- **Neighbors:**
- **Allied with:**

Sources:
