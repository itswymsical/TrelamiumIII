# Trelamium Worldbuilding

The lore wiki for Trelamium, kept as an Obsidian vault. To browse it on GitHub, begin at [Start Here](Start%20Here.md). To edit it, open this folder in Obsidian with "Open folder as vault".

- [Start Here](Start%20Here.md): the root index of every section
- [Open Questions](Open%20Questions.md): every unresolved lore decision, in one place
- Canvases (`World Map.canvas`, `Deep History.canvas`, `Alchemy System.canvas`) open only in Obsidian; GitHub shows them as raw JSON
