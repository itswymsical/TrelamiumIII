---
title: "Start Here"
date: 2026-10-11
tags: [index]
aliases: ["Trelamium World Map"]
---

# Trelamium World Map

The lore of Trelamium, one note per thing: cosmology, eras, realms, peoples, factions, characters and magick. Each note links to everything it touches, so Obsidian can draw the whole world as one connected map.

## How to explore

- **Graph view** (Ctrl+G): every note is a node, colored by category. This page, the sources, the templates and Open Questions are filtered out so the web stays readable. Hover a node to light up its neighbors; click to open it.
- **[World Map](World%20Map.canvas):** a hand-laid map of the present-day story, grouped by realm and faction, with the key relationships drawn as labeled arrows.
- **[Deep History](Deep%20History.canvas):** the old world, much of it inherited from the earlier Reverie Mod: the Ages, Excellia and the Monster Empire, Yakvala and the Three Witches, Chaotica's people, and the demiurges.
- **[Open Questions](Open%20Questions.md):** every gap, contradiction and suggestion in one list. The notes themselves hold only what's settled or clearly marked.

**Graph colors:** Cosmology gold · Timeline slate blue · Realms green · Peoples orange · Factions red · Characters sky blue · Magick and Systems violet · Jobs rose · Alchemy teal.

**Status**, in each note's properties: `canon` is stated in the sources; `concept` is named but barely defined; `proposed` is a suggestion that isn't canon yet. *(inferred)* marks a link this map assumed, and each one is listed in Open Questions.

**Adding to the world:** create a note, insert a template from `_Templates` (Ctrl+P, then "Templates: Insert template"), fill in its Connections, and add it to this page.


## Sources

The writing everything else is drawn from.

- [Chronicle of Source](Sources/Chronicle%20of%20Source.md): The in-world scripture, from Awakening I to Revelation IV, kept as written.
- [Lore Bible](Sources/Lore%20Bible.md): The design bible: cosmology, the cult, Cthulhu and the Crusade, dimensions, systems and characters.
- [Latest Retcons](Sources/Latest%20Retcons.md): Peoples, groups, ranks and characters from the creator's voice notes, cleaned up.
- [Legacy Content](Sources/Legacy%20Content.md): Lore from old chats with Gerjingle, the co-director, August 2025 to September 2026, summarized by date.

## Cosmology

What the world is made of.

- [The Vault](Cosmology/The%20Vault.md): The vault of potential energy where the spirits of light and dark festered before anything had quality.
- [Luminance](Cosmology/Luminance.md): The Source of light. It rendered Illuminance and sent a vessel to moderate the wars of the Anthropos.
- [Trelamium](Cosmology/Trelamium.md): The Source of dark and the essence of fear, doubt and uncertainty. It gives the mod its name and sits at the center of the Church's plan.
- [Illuminance](Cosmology/Illuminance.md): What light rendered: everything emergent and natural.
- [Silhouettes](Cosmology/Silhouettes.md): What darkness rendered: shape without light, the outline that architecture fills.
- [Architecture](Cosmology/Architecture.md): Built, imposed structure. It is the dark's product, and the Anthropos built it everywhere: in thought, science, technology and nations.
- [Esse](Cosmology/Esse.md): The fabric of being. Light and dark seeded themselves into it, which gave things quality.
- [Quality](Cosmology/Quality.md): The properties light and dark gave to things, the reason anything is distinct. The Church blames it for every wound.
- [Qualia](Cosmology/Qualia.md): Experiential power. Life exists to experience, and anything producing qualia in mass draws the watchers.
- [Chrysalis](Cosmology/Chrysalis.md): The shell that Anthropos quality hardened into as experience shaped it.
- [Sequela](Cosmology/Sequela.md): A lingering cultural or psychological pathology left by collective trauma. In the Chronicle, it is the chaos the Anthropos fell into after leaving their natural roots.
- [Demiurges](Cosmology/Demiurges.md): Mystical, esoteric beings who take a hand in shaping a universe. Anyone who goes far enough into the world's esoterica can become one.

## Timeline

Eras and events, in order.

- [Awakening I](Timeline/Awakening%20I.md): The Vault erupts. Light and dark seed esse and give things quality.
- [Awakening II](Timeline/Awakening%20II.md): Life emerges to experience. One species names itself Anthropos, and its quality hardens into a Chrysalis.
- [Primordial Age I](Timeline/Primordial%20Age%20I.md): The Anthropos build, war over resources, and split again and again until only their own architecture holds them. Dated ??? P.E.
- [The Ancient Great War](Timeline/The%20Ancient%20Great%20War.md): A great war of the old history. The Lore Bible says its dead became the Corruption and the Crimson; when it happened and who fought it are open.
- [Primordial Age II](Timeline/Primordial%20Age%20II.md): The Sources intervene. Luminance and Trelamium each send a vessel to earth while the Anthropos abandon their natural roots.
- [The Anthropic Revolution](Timeline/The%20Anthropic%20Revolution.md): The Anthropos abandon their old framework of understanding and work magick through the language of alchemy, producing dark forces, grimoires and new magick. Working name.
- [Primordial Age III](Timeline/Primordial%20Age%20III.md): A group of men forms the Church of Apathos, practitioners of apathos magick.
- [Revelation](Timeline/Revelation.md): The Church seeks the end of wanting. One member gives everything away, Iniki fits the emptied vessel, and Trelamium gains its deity.
- [The Seaforth Revolution](Timeline/The%20Seaforth%20Revolution.md): Denied the throne of Seaforth, Cthulhu revolts, discovers Apothos, and turns the revolt into the Assailant Crusade.
- [The Present Age](Timeline/The%20Present%20Age.md): The game's era, called Neruppu in the chats. The Assailant Crusade targets Terraria, and the Hero's qualia draws the Eye.
- [The Elcion Calendar](Timeline/The%20Elcion%20Calendar.md): The old dating system: P.E. (Pre-Elcion) for the early Thanneer Epoch, when the universe was being formed, and E. (Elcion) for its middle and late stretches.
- [Thanneer Epoch](Timeline/Thanneer%20Epoch.md): The first age of the chats' timeline. Its early stretch, Pre-Elcion, is when the universe was being formed.
- [Bhoomi](Timeline/Bhoomi.md): The second age, named for earth. It ended in Elcion 3534, after which a new calendar was adopted.
- [Kaatru](Timeline/Kaatru.md): The Age of Air, which began after Bhoomi ended and a new calendar was adopted. It led into Neruppu, the present.
- [The Call of Light](Timeline/The%20Call%20of%20Light.md): An event in the old history after which Yakvala lost faith in the future of the worlds. Its year isn't set.
- [The Man and Monster War](Timeline/The%20Man%20and%20Monster%20War.md): A war between the realms of men and the "monster"-harboring worlds, during which Queen Flaropha tortured Yakvala into madness.

## Realms

Dimensions and places.

- [Terraria](Realms/Terraria.md): The vanilla world, the epicenter of the universe, and the first dimension the Assailants target.
- [Ingress](Realms/Ingress.md): An inner state played as a full subworld: a forest of wooden folk over a maze of caverns, with the Scar of Ingress guarded at its heart. The Hero goes there to learn self-understanding.
- [Temple of Ingress](Realms/Temple%20of%20Ingress.md): The temple, or Ligneous Fortress, that the Wooden Warden protects. The Hero awakens the Warden at its Altar of Ingress.
- [Scar of Ingress](Realms/Scar%20of%20Ingress.md): A wound in Ingress that the Wooden Warden was ordered to protect, along with whatever lies behind it.
- [Seaforth](Realms/Seaforth.md): Cthulhu's homeland, ruled by a nobility that denied him the throne. The Sea Folk come from here.
- [Archaea](Realms/Archaea.md): A world split between a massive, fast-moving cyberpunk city and the traditional Vespers of Cactus County on its outskirts. Its hero, Eustace, warded off the Crusade.
- [Sylvanwalde](Realms/Sylvanwalde.md): The Dryad's homeland: a taiga subworld split into three districts and ruled from the surface by classist elves. Dahlia turned back the Crusade here.
- [Hyperborea](Realms/Hyperborea.md): A frozen dimension, home of the Hyperboreans and of the frost giant Permafrost, who lives on one of its frozen mountains.
- [Chaotica](Realms/Chaotica.md): An old name for ancient hell, possibly made by Behema. Home of Pyron, and of Dram and his family.
- [The Corruption](Realms/The%20Corruption.md): An evil biome in Terraria that Fullbone created, and the Assailants' first stronghold.
- [The Crimson](Realms/The%20Crimson.md): An evil biome in Terraria that Fullbone created, and one of the Assailants' strongholds.
- [Reverie](Realms/Reverie.md): The Library of Reverie, a subworld where every book that has ever existed rests somewhere. Edith keeps the front desk and lends books that teach lore and magick.
- [Shadowmire](Realms/Shadowmire.md): The district of Sylvanwalde where the Gleplins live and mine coal and other resources.
- [Druid's Garden](Realms/Druid's%20Garden.md): One of the three districts of Sylvanwalde.
- [Sylvanwalde Surface](Realms/Sylvanwalde%20Surface.md): The surface district of Sylvanwalde, where the ruling elves live and the fairies are treated as second-class citizens.
- [Glowshroom Grotto](Realms/Glowshroom%20Grotto.md): An underground microbiome that always spawns inside one of the world's glowing mushroom biomes. Argie lives there.
- [Excellia](Realms/Excellia.md): A realm of the old history whose royals the Dryads turned against the Monster Empire. Yakvala's story belongs to it.
- [Obsidian Forest](Realms/Obsidian%20Forest.md): A planned cavern-layer biome just above hell, and one of the Assailants' three strongholds.
- [Nimbus Kingdom](Realms/Nimbus%20Kingdom.md): A sky dimension filled with Greedy Gods, the nimbus people, ruled by Aureolus. Working name.
- [The Underworld](Realms/The%20Underworld.md): The vanilla Underworld: one of the "monster"-harboring worlds betrayed in the old wars, and the Wall of Flesh's domain.
- [Archaea City](Realms/Archaea%20City.md): Archaea's massive cyberpunk city: very progressive and super fast with technology, at the cost of the land and of how it treats others. Working name.
- [Cactus County](Realms/Cactus%20County.md): The outskirts of Archaea's cyber city, where the traditional Vespers live.
- [Elysia](Realms/Elysia.md): The Elysians' home planet, completely eradicated by the Paladin Nisha.

## Peoples

Races, kinds and creatures.

- [Anthropos](Peoples/Anthropos.md): Humanity and anything anthropic: the species that named itself, built architecture, and divided itself endlessly. Plural Anthropoi.
- [Hybrid Anthropoi](Peoples/Hybrid%20Anthropoi.md): People of mixed Anthropos and other lineage, such as Eosforos, who is half goat.
- [Entfolk](Peoples/Entfolk.md): Beings made of wood, native to Ingress. Edith is one of them.
- [Mud-Spirit Folk](Peoples/Mud-Spirit%20Folk.md): Ingress beings made of mud and spirit, distinct from the Entfolk. Name pending.
- [Sea Folk](Peoples/Sea%20Folk.md): The people of Seaforth.
- [Cephalopods](Peoples/Cephalopods.md): Octopus-like beings. Cthulhu is tentatively one.
- [Archaeans](Peoples/Archaeans.md): The general term for the people of Archaea, from the residents of its cyber city to the Vespers of Cactus County.
- [Hyperboreans](Peoples/Hyperboreans.md): Individuals from Hyperborea.
- [Dryads and Druids](Peoples/Dryads%20and%20Druids.md): Dryads and druids are one people. The Dryad belongs to it; in the old wars, the Dryads were among the worst actors.
- [Elves](Peoples/Elves.md): The ruling people of Sylvanwalde: proud, classist and discriminatory, with two exceptions, Dahlia and her son.
- [Gleplins](Peoples/Gleplins.md): Worker creatures who live in Shadowmire, a district of Sylvanwalde, and mine coal and other resources.
- [Goblins](Peoples/Goblins.md): A whole race of people. One unnamed tribe hates technology, wants power, and fights for the Assailants as the Goblin Army.
- [Skeletons](Peoples/Skeletons.md): Undead bone creatures. Their place in the lore is not yet defined.
- [Zombies](Peoples/Zombies.md): Undead. Their place in the lore is not yet defined.
- [Watchers](Peoples/Watchers.md): Demon eyes and every eye-type creature. They survey worlds for beings that produce mass qualia.
- [Slimes](Peoples/Slimes.md): Gelatinous creatures. King Slime rules them.
- [Frost Giants](Peoples/Frost%20Giants.md): A race with exactly one member in the story: Permafrost.
- [Demons](Peoples/Demons.md): Demonic beings of Chaotica, including the Bone Demons. Pyron is a demon warrior, and the Wall of Flesh was made to protect the demons from a purge.
- [Elysians](Peoples/Elysians.md): The people of Elysia, a planet the Paladin Nisha completely destroyed. Sophie is one of them.
- [Archivers](Peoples/Archivers.md): Ancient historians who recorded world history and the types of magick. In the old history they also rekindled Terraria's survival, and later planned to purge the demons.
- [Living Spirits](Peoples/Living%20Spirits.md): Spirits that live as beings. Not yet defined.
- [Martians](Peoples/Martians.md): Vanilla's Martians. Their place in the lore is not yet defined.
- [Myconids](Peoples/Myconids.md): Mushroom creatures. Fungore is a Myconid boss.
- [Annelids](Peoples/Annelids.md): The setting's worms. Annelida is the scientific phylum for segmented worms.
- [Sycophants](Peoples/Sycophants.md): Parasite-type creatures.
- [Iniki Manifestations](Peoples/Iniki%20Manifestations.md): Beings of darkness incarnate, extensions of Iniki.
- [Fairies](Peoples/Fairies.md): A people living on Sylvanwalde's surface, where the elves treat them as second-class citizens.
- [Quints](Peoples/Quints.md): A people named in passing: Saint Jerwin is a Quint. Not yet defined.
- [Vespers](Peoples/Vespers.md): The traditional people of Cactus County in Archaea: shadowy silhouettes with golden-yellow laser eyes, whose culture centers on their own form of magick.
- [Bone Demons](Peoples/Bone%20Demons.md): A kind of demon. Dram is half Bone Demon.
- [Nimbus People](Peoples/Nimbus%20People.md): The people of the Nimbus Kingdom, also called the Greedy Gods.
- [Taijitons](Peoples/Taijitons.md): The Terrarians of the ancient world, who were much bigger than people today.

## Factions

Groups with goals.

- [The Church of Apothos](Factions/The%20Church%20of%20Apothos.md): The original alchemist cult and the true central antagonist: ancient Anthropos who worshipped the end of wanting and made the Trelamium God. Older and larger in scope than Cthulhu.
- [The Assailant Crusade](Factions/The%20Assailant%20Crusade.md): Cthulhu's multidimensional empire of cultists, warriors and soldiers of every race. It serves Trelamium whether Cthulhu knows it or not.
- [Seaforth Nobility](Factions/Seaforth%20Nobility.md): The noble class of Seaforth that refused Cthulhu the throne because of his common blood.
- [The Goblin Army](Factions/The%20Goblin%20Army.md): The war band of an unnamed goblin tribe that hates technology and wants power. On the Assailants' orders, it raids the Hero's town for resources.
- [The Three Witches](Factions/The%20Three%20Witches.md): Three women of great significance in Terraria's story, who created the souls inside the mechanical bosses: Malicia, Saraphine and Farewynn.
- [The Void Whisperers](Factions/The%20Void%20Whisperers.md): Followers of Apothos, which its first followers called the Void Hymn. They helped spread Cthulhu's influence to the other worlds; Yakvala is one of their remnants.
- [The Monster Empire](Factions/The%20Monster%20Empire.md): The alliance of "monster"-harboring worlds that the Dryads branded unholy and that Queen Flaropha set out to destroy.
- [Heroes of the Land](Factions/Heroes%20of%20the%20Land.md): The title for those who led their worlds in fighting off Cthulhu's Assailant Crusade. Their worlds aren't entirely safe, but the Crusade has been warded off.

### Assailant ranks

Lowest to highest.

- [Fiends](Factions/Assailant%20Ranks/Fiends.md): The lowest rank of the Assailant Crusade, commanded by the Supreme Fiend Corithian. Fiend troops hold the Corruption and Crimson camps.
- [Sinners](Factions/Assailant%20Ranks/Sinners.md): The second rank of the Assailant Crusade.
- [Disasters](Factions/Assailant%20Ranks/Disasters.md): The third rank of the Assailant Crusade.
- [Tragedies](Factions/Assailant%20Ranks/Tragedies.md): The fourth rank of the Assailant Crusade.
- [Honoraries](Factions/Assailant%20Ranks/Honoraries.md): The fifth rank of the Assailant Crusade.
- [The Elect](Factions/Assailant%20Ranks/The%20Elect.md): The sixth rank of the Assailant Crusade, just below the Paladins.
- [Paladins](Factions/Assailant%20Ranks/Paladins.md): The top rank of the Assailant Crusade, right below the Moon Lord. Four Paladins serve Cthulhu, each with private goals.

### Assailant troops

Fiend-rank enemy types in the Assailant camps.

- [Soma Whisperer](Factions/Assailant%20Troops/Soma%20Whisperer.md): A Fiend-rank Assailant fought in the Corruption and Crimson camps. A combat type with no special lore.
- [Null Herald](Factions/Assailant%20Troops/Null%20Herald.md): A Fiend-rank Assailant fought in the Corruption and Crimson camps. A combat type with no special lore.
- [Echo Knight](Factions/Assailant%20Troops/Echo%20Knight.md): A Fiend-rank Assailant fought in the Corruption and Crimson camps. A combat type with no special lore.

## Characters

Named individuals.

- [The Hero](Characters/The%20Hero.md): The player. They produce qualia in mass amounts, which draws the watchers, and must stop the Moon Lord and then Iniki, becoming the hero of Terraria and finally of reality.
- [The Dryad](Characters/The%20Dryad.md): A dryad from Sylvanwalde and the Hero's guide into Ingress. An old friend of the Guide, she crosses over through a rift after the Eye falls.
- [Iniki](Characters/Iniki.md): Darkness incarnate and the final antagonist. It waited since the Vault for a form that would not resist it, then filled the Trelamium God.
- [The Trelamium God](Characters/The%20Trelamium%20God.md): An Anthropos who gave away his name, history and wanting, then was filled by Iniki. He walks toward the Vault to close it. Name pending.
- [Vessel of Luminance](Characters/Vessel%20of%20Luminance.md): The vessel of light that Luminance sent to moderate the Anthropos' wars. It shines through their architecture.
- [Vessel of Trelamium](Characters/Vessel%20of%20Trelamium.md): The vessel Trelamium sent into the earth. It planted seeds inside the Anthropos' architecture.
- [Cthulhu](Characters/Cthulhu.md): The half-commoner prince of Seaforth who found Apothos and leads the Assailant Crusade. The Hero fights him as the Moon Lord.
- [Eye of Cthulhu](Characters/Eye%20of%20Cthulhu.md): Cthulhu's literal eye, the Watcher, which surveys Terraria for anything producing mass qualia. Its death breaks a seal and lets Apothos back into the world.
- [Fullbone](Characters/Fullbone.md): A Paladin of the Crusade and a power-hungry maniac with no morality. Responsible for the Corruption and the Crimson.
- [Erahoka](Characters/Erahoka.md): A Paladin of the Crusade with a private agenda.
- [Nisha](Characters/Nisha.md): A Paladin of the Crusade who completely destroyed Elysia, the Elysians' home planet, and has it out for the Anthropi.
- [Callisto](Characters/Callisto.md): A Paladin of the Crusade with a private agenda.
- [Eosforos](Characters/Eosforos.md): Half goat, half Anthropos, with a goofy personality. He works under the Assailants for Cthulhu and is planned as a pre-hardmode boss.
- [Saint Jerwin](Characters/Saint%20Jerwin.md): A priest and a Quint who practices Illuminant Magick. After the Guide dies, he finds a way to revive him through the Shimmer.
- [Pyron](Characters/Pyron.md): A demon warrior from Chaotica, Permafrost's rival, and one of the four new bosses. He stands at a level only beings like Permafrost reach.
- [Permafrost](Characters/Permafrost.md): The only frost giant in the story: a sorcerer of ice magick who studied Apothos, learned of Iniki, met the Trelamium God, and is climbing toward becoming a demiurge. He judges whether the Hero is worth teaching.
- [Glacier](Characters/Glacier.md): Permafrost's eye, a Hyperborean watcher that works like a summon or stand. The Hero fights Glacier on Permafrost's frozen mountain as his challenge. One of the four new bosses.
- [Wooden Warden](Characters/Wooden%20Warden.md): The Guardian of Ingress: a sentient wooden golem ordered to protect the Scar of Ingress and what lies behind it. Awakened at the Altar of Ingress.
- [Edith](Characters/Edith.md): An Entfolk who keeps the front desk of the Library of Reverie and lends its books.
- [Fungore](Characters/Fungore.md): The Malevolent Myconid, a standalone boss with no part in the Crusade.
- [King Slime](Characters/King%20Slime.md): The Gelatinous Monarch: an ordinary blue slime given a crown filled with Apothos magick, which surged it with power.
- [Eater of Worlds](Characters/Eater%20of%20Worlds.md): Proposed tie-in: the dead soldiers' twisted souls, compacted by Fullbone into one devouring body.
- [Brain of Cthulhu](Characters/Brain%20of%20Cthulhu.md): Proposed tie-in: grown by Fullbone from the dead soldiers' blood. It is literally Cthulhu's brain, a remote organ that thinks through Apothos.
- [Silvian](Characters/Silvian.md): A friendly herb gardener of about 24 and the nephew of John Substrate, the greatest alchemist who ever lived. After his first job he gives the Hero his late uncle's Alchemist's Almanac.
- [John Substrate](Characters/John%20Substrate.md): The greatest alchemist who ever existed, uncle of Silvian, teacher of Argie, and author of the Alchemist's Almanac. He died at about 43, most likely at the Assailants' hands.
- [Argie](Characters/Argie.md): Argie, or Argentina: a mycologist who lives in the Glowshroom Grotto and was once John Substrate's young apprentice. A sideline character early on who matters later.
- [The Guide](Characters/The%20Guide.md): The Hero's first friend in Terraria. The Guide gives the first job, recognizes Apothos when the Eye dies, calls in the Dryad, and dies going into hardmode before Saint Jerwin brings him back.
- [Goblin Tinkerer](Characters/Goblin%20Tinkerer.md): A goblin inventor whose anti-technology tribe set him up for execution during its raid. Freed by the Hero, he joins the town and builds contraptions.
- [Laine L](Characters/Laine%20L.md): A rational Anthropos philosopher of the 1800s P.E., steeped in phenomenology, who slid into paranoia about illuminance, silhouettes and architecture, and came to believe he had corrupted the woman he loved, Hesper.
- [Hesper](Characters/Hesper.md): A country woman Laine L. loved and pulled into his world, who was never the same after. She will be a significant character in the future.
- [Dahlia](Characters/Dahlia.md): An elf and the hero of Sylvanwalde. One of the only elves free of the elves' prejudice, she and her crew stopped Cthulhu's Crusade there.
- [The Tamer](Characters/The%20Tamer.md): A woman in Dahlia's crew, known as the Tamer. Her name isn't settled yet.
- [Sophie](Characters/Sophie.md): An Elysian engineer of gadgets and androids who lives in Archaea's cyber city. She is the city resident the Vespers respect most.
- [Sonder](Characters/Sonder.md): A mysterious, esoteric wanderer who appears at random and trades stories for an answer to one question: have you felt sonder?
- [Kraken](Characters/Kraken.md): A wanderer type, like Sonder. Not yet defined beyond that.
- [Corithian](Characters/Corithian.md): The Supreme Fiend: commander of the Assailants' lowest rank, a priest-like practitioner of Apothos, and the opposite of Saint Jerwin.
- [Yakvala](Characters/Yakvala.md): The ancient lead engineer of the Elysians, who built the mechanical bosses as protectors and later twisted them into monsters. Dead by the present.
- [Von Kraft](Characters/Von%20Kraft.md): One of Yakvala's last creations, newly designed by Gerjingle in September 2026.
- [Queen Flaropha](Characters/Queen%20Flaropha.md): A queen of the old wars who, aided by the Dryads, set out to destroy the less "divine" worlds, and who tortured Yakvala.
- [Malicia](Characters/Malicia.md): The Witch of Fright. She made Fright Energy to control how fear spreads, so the world could find its bravery, and became fear's personification.
- [Saraphine](Characters/Saraphine.md): The Witch of Sight. She made Sight Energy to see the truth of the world and of every person, and lives as three personalities.
- [Farewynn](Characters/Farewynn.md): The Witch of Might, from Gerjingle's notes. She made Might Energy to grant power to whatever she chooses, for the entertainment of watching the conflict that follows.
- [The Red God](Characters/The%20Red%20God.md): Red, the personification of creation: a demiurge who designed the Terraria universe and answers to higher forces. He steps in only when someone tries to do too much.
- [The Celestial Torment](Characters/The%20Celestial%20Torment.md): Red's opposite and eternal equal, a demiurge who co-designed the Terraria universe.
- [Behema](Characters/Behema.md): A figure who may be a demiurge, which would explain how Behema made Chaotica.
- [Gouhtri](Characters/Gouhtri.md): An ancient knight so devoted to knighthood that he never removes his armor and has become it, living far past any human lifespan. Close to a demiurge, with no wish to be more.
- [Titan](Characters/Titan.md): Dram's grandfather, being redesigned as "a special case". Nothing else is set.
- [Dram](Characters/Dram.md): A Chaotican, half Vesper (an Archaean people) and half Bone Demon, who is Titan's grandson and Naka's partner. He stands 5 ft 2 in.
- [Naka](Characters/Naka.md): Dram's partner. Nothing else is set.
- [Cumulor](Characters/Cumulor.md): The Exiled Son: a boss of the Nimbus Kingdom and son of its ruler, Aureolus. One of the four new bosses.
- [Aureolus](Characters/Aureolus.md): Ruler of the Nimbus Kingdom and father of Cumulor.
- [The Azolinth](Characters/The%20Azolinth.md): One of the four new bosses named in September 2026. Nothing else is defined.
- [Tax Collector](Characters/Tax%20Collector.md): The one soul released by the Wall of Flesh that wasn't beyond saving.
- [The Trash Beast](Characters/The%20Trash%20Beast.md): A planned static mini-boss that hoards everything it finds beneath spawn. Defeated, it turns out to be a tiny creature in a pot, and it becomes a town pet. Working name, from the 2025 plan.
- [Wall of Flesh](Characters/Wall%20of%20Flesh.md): A guardian gone wild, made with destructive magick to protect the demons from a planned purge. It holds the souls of the billions it consumed.
- [The Mechanical Bosses](Characters/The%20Mechanical%20Bosses.md): The hardmode mechs: built by Yakvala as benevolent protectors, inhabited by souls the Three Witches created, and later twisted into monsters.
- [Eustace](Characters/Eustace.md): A cowboy, the Vespers' leader and most respected figure, and the hero of Archaea. He has an apprentice who hasn't been named yet.

## Magick and systems

Magick types and the game systems built on them.

- [Alchemy](Magick%20and%20Systems/Alchemy.md): The language and symbolism the Anthropos used to work magick after their revolution. The Church practiced it; the Hero learns it from John Substrate's almanac.
- [Apothos](Magick%20and%20Systems/Apothos.md): The ancient magick of Cthulhu and the Assailants. It nullifies whatever it takes hold of; a sword can't fight it, but clarifying language and self-understanding can mitigate it.
- [Clarifying Language](Magick%20and%20Systems/Clarifying%20Language.md): The counter to Apothos: language that clarifies, and the self-understanding the Hero gains in Ingress.
- [Illuminant Magick](Magick%20and%20Systems/Illuminant%20Magick.md): A type of magick practiced by Saint Jerwin. Not yet defined.
- [Magick Practitioners](Magick%20and%20Systems/Magick%20Practitioners.md): A role some characters hold across factions: practitioners of a school of magick.
- [Experiential Points](Magick%20and%20Systems/Experiential%20Points.md): The game's form of qualia, earned from sandbox actions rather than kills and spent on skills. Implemented.
- [Alchemist's Almanac](Magick%20and%20Systems/Alchemist's%20Almanac.md): John Substrate's handwritten alchemy book. Silvian gives it to the Hero, and it teaches alchemy one earned page at a time.
- [Mycology](Magick%20and%20Systems/Mycology.md): The study of fungi, and the way into low-level alchemy that Argie opens for the Hero.
- [The Chronicles](Magick%20and%20Systems/The%20Chronicles.md): In-world books, planned in 2025, that carry the early story and lead up to the Eye of Cthulhu.

## Jobs

The mod's missions and quests, and the formula that builds them.

- [Jobs](Jobs/Jobs.md): Every job in the mod, who gives it, what it asks and what it teaches.
- [The Job Formula](Jobs/The%20Job%20Formula.md): Every interaction is a narrative payoff. Characters act as living people, and what they ask for points at a game system.
- [Silvian's First Job](Jobs/Silvian's%20First%20Job.md): Seed beds, magnolias and salt for Silvian's garden, the model for the formula.

## Alchemy

The alchemy system's design, kept apart from the lore of alchemy.

- [Alchemy System](Alchemy%20System.canvas): A canvas of the language of alchemy: solvent, solute, reagent and solution, the seven principles, the six temperaments, how a brew resolves, and every item the Almanac registers.
- [Farming Overhaul](Alchemy/Farming%20Overhaul.md): Seed beds, herbs, flowers and salt, the inputs of alchemy.
- [Controller Class](Alchemy/Controller%20Class.md): The chemical weapon class built on alchemy: controlled spatial damage and crowd control.
