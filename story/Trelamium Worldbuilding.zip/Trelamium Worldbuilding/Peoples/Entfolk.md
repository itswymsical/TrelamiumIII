---
title: "Entfolk"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Ligneous folk", "Wooden folk"]
---

# Entfolk

*Beings made of wood, native to Ingress. Edith is one of them.*

The Lore Bible describes Ingress as a fantasy forest of ligneous folk.

## Connections

- **Native to:** [Ingress](../Realms/Ingress.md)
- **Known members:** [Edith](../Characters/Edith.md)
- **Neighbors:** [Mud-Spirit Folk](Mud-Spirit%20Folk.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
