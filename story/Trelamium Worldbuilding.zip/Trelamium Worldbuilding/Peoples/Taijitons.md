---
title: "Taijitons"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Ancient world Terrarians"]
---

# Taijitons

*The Terrarians of the ancient world, who were much bigger than people today.*

For scale: [Gouhtri](../Characters/Gouhtri.md) stands 11 ft 8 in, while [The Guide](../Characters/The%20Guide.md), a modern Terrarian, is 5 ft 8 in.

## Connections

- **Likely member:** [Gouhtri](../Characters/Gouhtri.md) *(inferred)*
- **Related:** [Anthropos](Anthropos.md) *(inferred)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
