---
title: "Quints"
date: 2026-10-11
type: people
status: concept
tags: [people]
---

# Quints

*A people named in passing: Saint Jerwin is a Quint. Not yet defined.*

## Connections

- **Known members:** [Saint Jerwin](../Characters/Saint%20Jerwin.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
