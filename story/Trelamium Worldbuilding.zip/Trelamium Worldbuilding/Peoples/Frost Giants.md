---
title: "Frost Giants"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Frost Giants

*A race with exactly one member in the story: Permafrost.*

## Connections

- **Only member:** [Permafrost](../Characters/Permafrost.md)
- **Homeland:** [Hyperborea](../Realms/Hyperborea.md) *(inferred)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
