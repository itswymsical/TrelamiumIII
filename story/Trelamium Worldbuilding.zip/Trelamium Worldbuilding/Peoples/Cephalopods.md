---
title: "Cephalopods"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Octopi"]
---

# Cephalopods

*Octopus-like beings. Cthulhu is tentatively one.*

## Connections

- **Members:** [Cthulhu](../Characters/Cthulhu.md) *(tentative)*
- **Homeland:** [Seaforth](../Realms/Seaforth.md) *(inferred from Cthulhu)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
