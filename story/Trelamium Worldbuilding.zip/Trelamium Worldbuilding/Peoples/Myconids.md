---
title: "Myconids"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Myconids

*Mushroom creatures. Fungore is a Myconid boss.*

## Connections

- **Known members:** [Fungore](../Characters/Fungore.md)
- **Found in:** [Terraria](../Realms/Terraria.md), in the mushroom biomes *(inferred)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
