---
title: "Fairies"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Fairies

*A people living on Sylvanwalde's surface, where the elves treat them as second-class citizens.*

In the 2025 early-game plan, fairies in Terraria lead the Hero to loot, and a whole group of them leads the Hero to the [Trash Beast](../Characters/The%20Trash%20Beast.md)'s lair.

## Connections

- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **District:** [Sylvanwalde Surface](../Realms/Sylvanwalde%20Surface.md)
- **Looked down on by:** [Elves](Elves.md)
- **Lead the Hero to:** [The Trash Beast](../Characters/The%20Trash%20Beast.md) *(2025 plan)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
