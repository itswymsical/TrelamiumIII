---
title: "Sycophants"
date: 2026-10-11
type: people
status: concept
tags: [people]
aliases: ["Parasites"]
---

# Sycophants

*Parasite-type creatures.*

In English a sycophant is a flatterer who feeds off the powerful, which suits a parasite.

## Connections

- **Related:** [Annelids](Annelids.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
