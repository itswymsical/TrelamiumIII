---
title: "Sea Folk"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Sea Folk

*The people of Seaforth.*

## Connections

- **Homeland:** [Seaforth](../Realms/Seaforth.md)
- **Ruled by:** [Seaforth Nobility](../Factions/Seaforth%20Nobility.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
