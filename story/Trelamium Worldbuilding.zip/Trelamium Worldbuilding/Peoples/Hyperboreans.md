---
title: "Hyperboreans"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Hyperboreans

*Individuals from Hyperborea.*

## Connections

- **Homeland:** [Hyperborea](../Realms/Hyperborea.md)
- **Related:** [Glacier](../Characters/Glacier.md), a Hyperborean watcher

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
