---
title: "Archivers"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["The Archivers"]
---

# Archivers

*Ancient historians who recorded world history and the types of magick. In the old history they also rekindled Terraria's survival, and later planned to purge the demons.*

In Gerjingle's August 2025 notes, when the other worlds had given up on Terraria, the Archivers rekindled its survival. In the September 2026 notes, they joined [Excellia](../Realms/Excellia.md) and [Sylvanwalde](../Realms/Sylvanwalde.md) in planning to purge the [Demons](Demons.md), and the [Wall of Flesh](../Characters/Wall%20of%20Flesh.md) was made to stop them. Gerjingle rates them better than the Dryads, "at least in motivations". In the oldest version of the lore, before the retcon, the Archivers played the villain role the Dryads play now.

## Connections

- **Documented:** world history and the types of magick, such as [Alchemy](../Magick%20and%20Systems/Alchemy.md), [Apothos](../Magick%20and%20Systems/Apothos.md) and [Illuminant Magick](../Magick%20and%20Systems/Illuminant%20Magick.md) *(inferred)*
- **Rekindled:** [Terraria](../Realms/Terraria.md)
- **Planned to purge:** [Demons](Demons.md), with [Excellia](../Realms/Excellia.md) and [Sylvanwalde](../Realms/Sylvanwalde.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
