---
title: "Skeletons"
date: 2026-10-11
type: people
status: concept
tags: [people]
---

# Skeletons

*Undead bone creatures. Their place in the lore is not yet defined.*

## Connections

- **Found in:** [Terraria](../Realms/Terraria.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
