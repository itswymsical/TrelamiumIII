---
title: "Goblins"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Goblins

*A whole race of people. One unnamed tribe hates technology, wants power, and fights for the Assailants as the Goblin Army.*

Goblins are an entire race, not one army. One tribe, still unnamed, is opposed to technology and wants only power. In the [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md)'s words, its "archaic mindset is the reason they even got into the Assailants' cult". That tribe raids Terraria as the [Goblin Army](../Factions/The%20Goblin%20Army.md).

## Connections

- **Found in:** [Terraria](../Realms/Terraria.md)
- **Tribe:** [The Goblin Army](../Factions/The%20Goblin%20Army.md)
- **Known members:** [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
