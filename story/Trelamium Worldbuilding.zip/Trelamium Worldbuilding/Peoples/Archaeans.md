---
title: "Archaeans"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Archaeans

*The general term for the people of Archaea, from the residents of its cyber city to the Vespers of Cactus County.*

## Connections

- **Homeland:** [Archaea](../Realms/Archaea.md)
- **Includes:** the people of [Archaea City](../Realms/Archaea%20City.md), the [Vespers](Vespers.md)
- **Notable residents:** [Eustace](../Characters/Eustace.md); [Sophie](../Characters/Sophie.md), an Elysian

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
