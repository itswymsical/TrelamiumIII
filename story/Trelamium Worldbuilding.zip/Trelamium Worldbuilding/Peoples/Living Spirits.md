---
title: "Living Spirits"
date: 2026-10-11
type: people
status: concept
tags: [people]
---

# Living Spirits

*Spirits that live as beings. Not yet defined.*


Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
