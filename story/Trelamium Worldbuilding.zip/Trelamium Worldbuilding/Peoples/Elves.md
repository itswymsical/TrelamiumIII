---
title: "Elves"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Elves

*The ruling people of Sylvanwalde: proud, classist and discriminatory, with two exceptions, Dahlia and her son.*

The elves hold power in [Sylvanwalde](../Realms/Sylvanwalde.md) and rule from its [Sylvanwalde Surface](../Realms/Sylvanwalde%20Surface.md). They think highly of themselves, don't like anyone beneath them, and treat the [Fairies](Fairies.md) as second-class citizens. Most are racist. [Dahlia](../Characters/Dahlia.md) and her son are the exceptions.

## Connections

- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **District:** [Sylvanwalde Surface](../Realms/Sylvanwalde%20Surface.md)
- **Look down on:** [Fairies](Fairies.md), and likely the [Gleplins](Gleplins.md) *(inferred)*
- **Exceptions:** [Dahlia](../Characters/Dahlia.md) and her son

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
