---
title: "Anthropos"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Anthropoi", "Anthropi", "Humanity"]
---

# Anthropos

*Humanity and anything anthropic: the species that named itself, built architecture, and divided itself endlessly. Plural Anthropoi.*

The in-world word for humanity and anything anthropic.

In [Awakening II](../Timeline/Awakening%20II.md), one species organized itself into something intelligent, gave itself qualities, and named itself Anthropos. They built language, nations, technology and shared understanding, and their [Quality](../Cosmology/Quality.md) hardened into a [Chrysalis](../Cosmology/Chrysalis.md).

Before they divided, the Anthropos were a monolithic utopia, working together like a hive on a system built from their shared mythos. Then some began to doubt. Those skeptics were the first break, and they formed a secret society, the seed of the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) *(inferred)*.

In [Primordial Age I](../Timeline/Primordial%20Age%20I.md) they warred over resources and divided again and again in language, ideology, narrative and appearance. They adapted to the world but walled themselves inside their own [Architecture](../Cosmology/Architecture.md). In [Primordial Age II](../Timeline/Primordial%20Age%20II.md) their [Sequela](../Cosmology/Sequela.md) sprawled out of control: they abandoned their natural roots and profaned the gifts of [Luminance](../Cosmology/Luminance.md).

Out of them came the [Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md), the Church, and the man who became the [Trelamium God](../Characters/The%20Trelamium%20God.md).

## Connections

- **Emerged in:** [Awakening II](../Timeline/Awakening%20II.md)
- **Built:** [Architecture](../Cosmology/Architecture.md)
- **Quality hardened into:** [Chrysalis](../Cosmology/Chrysalis.md)
- **Afflicted by:** [Sequela](../Cosmology/Sequela.md)
- **Founded:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Gave the vessel for:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)
- **Mixed lines:** [Hybrid Anthropoi](Hybrid%20Anthropoi.md)
- **Ancient forebears:** [Taijitons](Taijitons.md) *(inferred)*

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
