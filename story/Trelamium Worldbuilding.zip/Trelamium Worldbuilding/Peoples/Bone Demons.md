---
title: "Bone Demons"
date: 2026-10-11
type: people
status: concept
tags: [people]
---

# Bone Demons

*A kind of demon. Dram is half Bone Demon.*

## Connections

- **Kind of:** [Demons](Demons.md) *(inferred)*
- **Known members:** [Dram](../Characters/Dram.md), half

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
