---
title: "Martians"
date: 2026-10-11
type: people
status: concept
tags: [people]
---

# Martians

*Vanilla's Martians. Their place in the lore is not yet defined.*


Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
