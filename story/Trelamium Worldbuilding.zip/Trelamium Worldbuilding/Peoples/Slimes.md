---
title: "Slimes"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Slimes

*Gelatinous creatures. King Slime rules them.*

## Connections

- **Ruler:** [King Slime](../Characters/King%20Slime.md)
- **Found in:** [Terraria](../Realms/Terraria.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
