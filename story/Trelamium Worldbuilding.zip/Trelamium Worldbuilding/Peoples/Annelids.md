---
title: "Annelids"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Worms", "Vermes"]
---

# Annelids

*The setting's worms. Annelida is the scientific phylum for segmented worms.*

Terraria's worms (Devourers, Giant Worms, Diggers, Bone Serpents, the Eater of Worlds) have segmented bodies, which matches **Annelida**, the phylum of segmented worms. Two alternatives:

- **Vermes:** Linnaeus's old catch-all class for every worm. It sounds older, which suits a lore term.
- **Helminths:** parasitic worms. This one may fit [Sycophants](Sycophants.md) better.

## Connections

- **Known members:** [Eater of Worlds](../Characters/Eater%20of%20Worlds.md) *(proposed boss)*
- **Found in:** [Terraria](../Realms/Terraria.md)
- **Related:** [Sycophants](Sycophants.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
