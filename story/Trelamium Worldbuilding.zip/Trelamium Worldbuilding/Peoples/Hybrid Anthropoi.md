---
title: "Hybrid Anthropoi"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Hybrids"]
---

# Hybrid Anthropoi

*People of mixed Anthropos and other lineage, such as Eosforos, who is half goat.*

## Connections

- **Parent people:** [Anthropos](Anthropos.md)
- **Known members:** [Eosforos](../Characters/Eosforos.md) (half goat, half Anthropos)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
