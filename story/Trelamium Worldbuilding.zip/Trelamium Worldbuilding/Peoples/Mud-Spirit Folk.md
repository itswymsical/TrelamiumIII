---
title: "Mud-Spirit Folk"
date: 2026-10-11
type: people
status: concept
tags: [people]
aliases: ["Mud and spirit folk"]
---

# Mud-Spirit Folk

*Ingress beings made of mud and spirit, distinct from the Entfolk. Name pending.*

"Mud-Spirit Folk" is a working name.

## Connections

- **Native to:** [Ingress](../Realms/Ingress.md)
- **Neighbors:** [Entfolk](Entfolk.md)
- **Possibly related:** [Living Spirits](Living%20Spirits.md) (suggestion)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
