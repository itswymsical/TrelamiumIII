---
title: "Iniki Manifestations"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Iniki Manifestations

*Beings of darkness incarnate, extensions of Iniki.*

## Connections

- **Source:** [Iniki](../Characters/Iniki.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
