---
title: "Vespers"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Cactus people"]
---

# Vespers

*The traditional people of Cactus County in Archaea: shadowy silhouettes with golden-yellow laser eyes, whose culture centers on their own form of magick.*

They're sometimes called the cactus people, though they aren't cactus at all; they just live out in [Cactus County](../Realms/Cactus%20County.md), beyond [Archaea City](../Realms/Archaea%20City.md), and sometimes wear cactus garments. Otherwise they dress like anyone else.

The Vespers are very traditional and conservative. They don't want to associate with the city's people because of what those people have done to the land and how they treat others. Their culture revolves around a specific form of magick. The person they respect most is [Eustace](../Characters/Eustace.md), and of all the city's residents they respect [Sophie](../Characters/Sophie.md) most, because she comes to them empty-handed and with open arms.

Vesper is Latin for the evening star, the same star [Hesper](../Characters/Hesper.md) is named for in Greek.

## Connections

- **Homeland:** [Cactus County](../Realms/Cactus%20County.md), in [Archaea](../Realms/Archaea.md)
- **Part of:** [Archaeans](Archaeans.md)
- **Most respected:** [Eustace](../Characters/Eustace.md)
- **Respect:** [Sophie](../Characters/Sophie.md)
- **Known descendants:** [Dram](../Characters/Dram.md), half Vesper

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
