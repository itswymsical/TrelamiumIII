---
title: "Gleplins"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Gleplins

*Worker creatures who live in Shadowmire, a district of Sylvanwalde, and mine coal and other resources.*

## Connections

- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **District:** [Shadowmire](../Realms/Shadowmire.md)
- **Ruled by:** [Elves](Elves.md) *(inferred)*

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
