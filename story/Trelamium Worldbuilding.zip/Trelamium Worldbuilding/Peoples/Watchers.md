---
title: "Watchers"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Demon Eyes", "Eyes"]
---

# Watchers

*Demon eyes and every eye-type creature. They survey worlds for beings that produce mass qualia.*

## Connections

- **Known members:** [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md), [Glacier](../Characters/Glacier.md)
- **Hunt:** [Qualia](../Cosmology/Qualia.md)
- **Found in:** [Terraria](../Realms/Terraria.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md)
