---
title: "Demons"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Demons

*Demonic beings of Chaotica, including the Bone Demons. Pyron is a demon warrior, and the Wall of Flesh was made to protect the demons from a purge.*

## Connections

- **Known members:** [Pyron](../Characters/Pyron.md)
- **Kinds:** [Bone Demons](Bone%20Demons.md)
- **Homeland:** [Chaotica](../Realms/Chaotica.md) *(inferred)*
- **Protected by:** [Wall of Flesh](../Characters/Wall%20of%20Flesh.md)
- **Targeted by:** [Archivers](Archivers.md), [Excellia](../Realms/Excellia.md), [Sylvanwalde](../Realms/Sylvanwalde.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
