---
title: "Dryads and Druids"
date: 2026-10-11
type: people
status: canon
tags: [people]
aliases: ["Dryads", "Druids"]
---

# Dryads and Druids

*Dryads and druids are one people. The Dryad belongs to it; in the old wars, the Dryads were among the worst actors.*

In Gerjingle's August 2025 history, the more the lore grew, the more villainous the Dryads became. They carried out ethnic cleansing and instigated betrayals between empires and kingdoms. They convinced the Royals of [Excellia](../Realms/Excellia.md) that the [Monster Empire](../Factions/The%20Monster%20Empire.md) was "unholy" and should be purged, and they aided [Queen Flaropha](../Characters/Queen%20Flaropha.md) against the monster worlds. Their descendants haven't changed, which makes the reveal of what their ancestors did hit harder.

## Connections

- **Known members:** [The Dryad](../Characters/The%20Dryad.md)
- **Homeland:** [Sylvanwalde](../Realms/Sylvanwalde.md)
- **District:** [Druid's Garden](../Realms/Druid's%20Garden.md) *(inferred from its name)*
- **Turned:** [Excellia](../Realms/Excellia.md) against the [Monster Empire](../Factions/The%20Monster%20Empire.md)
- **Aided:** [Queen Flaropha](../Characters/Queen%20Flaropha.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
