---
title: "Nimbus People"
date: 2026-10-11
type: people
status: concept
tags: [people]
aliases: ["Greedy Gods"]
---

# Nimbus People

*The people of the Nimbus Kingdom, also called the Greedy Gods.*

## Connections

- **Homeland:** [Nimbus Kingdom](../Realms/Nimbus%20Kingdom.md)
- **Known members:** [Aureolus](../Characters/Aureolus.md), [Cumulor](../Characters/Cumulor.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
