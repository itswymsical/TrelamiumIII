---
title: "Elysians"
date: 2026-10-11
type: people
status: canon
tags: [people]
---

# Elysians

*The people of Elysia, a planet the Paladin Nisha completely destroyed. Sophie is one of them.*

The Elysians come from another planet, [Elysia](../Realms/Elysia.md), which [Nisha](../Characters/Nisha.md) eradicated. In the older lore, [Yakvala](../Characters/Yakvala.md) was their lead engineer, and engineering still runs through them: [Sophie](../Characters/Sophie.md) builds gadgets and androids.

## Connections

- **Homeworld:** [Elysia](../Realms/Elysia.md), destroyed by [Nisha](../Characters/Nisha.md)
- **Known members:** [Sophie](../Characters/Sophie.md)
- **Lead engineer:** [Yakvala](../Characters/Yakvala.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
