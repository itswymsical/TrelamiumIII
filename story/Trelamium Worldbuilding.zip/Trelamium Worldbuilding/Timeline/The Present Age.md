---
title: "The Present Age"
date: 2026-10-11
type: era
status: concept
tags: [era]
aliases: ["Neruppu", "Age of Fire"]
---

# The Present Age

*The game's era, called Neruppu in the chats. The Assailant Crusade targets Terraria, and the Hero's qualia draws the Eye.*

In the chats' timeline this is Neruppu, which follows [Kaatru](Kaatru.md). Little between [Revelation](Revelation.md) and the game has been charted. The [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md) picks [Terraria](../Realms/Terraria.md) as its first target, and [The Hero](../Characters/The%20Hero.md) produces qualia in mass amounts, which draws the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md). Other worlds have already fought the Crusade off, led by their [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md).

**How the story runs:** the early story doesn't center the Hero. It's everyone else's story playing out in the background, and the Hero stumbles into it through missions and events.

The early game, as the mod and the Lore Bible lay it out:

1. [The Guide](../Characters/The%20Guide.md) gives the Hero their first job: build a town.
2. [Silvian](../Characters/Silvian.md) asks for help with his herb garden. After that first job he hands over his late uncle's [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md), and the Hero starts learning [Alchemy](../Magick%20and%20Systems/Alchemy.md). [Argie](../Characters/Argie.md) later opens up [Mycology](../Magick%20and%20Systems/Mycology.md).
3. The [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) attacks. When it dies, Assailants using [Apothos](../Magick%20and%20Systems/Apothos.md) pull its remains into a [Trelamium](../Cosmology/Trelamium.md) vortex, and a seal breaks that lets Apothos back into the world.
4. The Guide explains what woke and calls in an old friend from another world: [The Dryad](../Characters/The%20Dryad.md), who crosses over from [Ingress](../Realms/Ingress.md) through a rift.
5. The Dryad sends the Hero through the rift into Ingress, past the [Wooden Warden](../Characters/Wooden%20Warden.md), to find the Library of [Reverie](../Realms/Reverie.md), where [Edith](../Characters/Edith.md) keeps the front desk.
6. Also in this stretch: the [Goblin Army](../Factions/The%20Goblin%20Army.md) raids the Hero's town on the Assailants' orders. Once it's beaten, the Hero frees the [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md) from the stake.
7. Proposed: the Assailant strongholds and [Fullbone](../Characters/Fullbone.md) come next, starting in [The Corruption](../Realms/The%20Corruption.md), where Fiend troops like the [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md) and [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md) hold the camps. An older plan ran this stretch through [The Chronicles](../Magick%20and%20Systems/The%20Chronicles.md).
8. When the [Wall of Flesh](../Characters/Wall%20of%20Flesh.md) falls, the Guide dies. The Hero and the town push through early hardmode looking for a way back, and [Saint Jerwin](../Characters/Saint%20Jerwin.md) revives him through the Shimmer.
9. Later: [Cthulhu](../Characters/Cthulhu.md) as the Moon Lord, then [Iniki](../Characters/Iniki.md). Stopping Iniki makes the Hero the hero of reality.

**Bosses in the works:** [Glacier](../Characters/Glacier.md), [Pyron](../Characters/Pyron.md), [Cumulor](../Characters/Cumulor.md) and [The Azolinth](../Characters/The%20Azolinth.md) are the new bosses. [Eosforos](../Characters/Eosforos.md) is planned as a pre-hardmode boss, and a barbarian Assailant boss for the Corruption camps, fought before the Eater of Worlds, has been floated.

## Connections

- **Previous:** [Revelation](Revelation.md) in the Chronicle; [Kaatru](Kaatru.md) in the Ages
- **Began with:** [The Seaforth Revolution](The%20Seaforth%20Revolution.md)
- **Key figures:** [The Hero](../Characters/The%20Hero.md), [Cthulhu](../Characters/Cthulhu.md), [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Latest Retcons](../Sources/Latest%20Retcons.md) · [Legacy Content](../Sources/Legacy%20Content.md)
