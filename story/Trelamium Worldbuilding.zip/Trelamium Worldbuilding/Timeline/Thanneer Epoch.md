---
title: "Thanneer Epoch"
date: 2026-10-11
type: era
status: canon
tags: [era]
---

# Thanneer Epoch

*The first age of the chats' timeline. Its early stretch, Pre-Elcion, is when the universe was being formed.*

The age names in this timeline are Tamil words for the classical elements: *thanneer* (water), *bhoomi* (earth), *kaatru* (air) and *neruppu* (fire).

## Connections

- **Dated by:** [The Elcion Calendar](The%20Elcion%20Calendar.md)
- **Next:** [Bhoomi](Bhoomi.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
