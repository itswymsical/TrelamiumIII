---
title: "Primordial Age I"
date: 2026-10-11
type: era
status: canon
tags: [era]
aliases: ["Awakening III", "The Primordial Age"]
---

# Primordial Age I

*The Anthropos build, war over resources, and split again and again until only their own architecture holds them. Dated ??? P.E.*

The Anthropos have qualic uniformity and strive to experience. They build [Architecture](../Cosmology/Architecture.md): societies, technologies and arts. They also war with each other over resources and over "whose seed would bear the land".

The wars divide them into different languages, ideologies and narratives. The biomes of the world divide too, "changing their structure within their domain of purity". The Anthropos adapt, begin to look different, and split into new distinctions in an endless spiral, until shared qualities are "infinitesimal and sparse against walls". This spiral is a natural origin for the world's many peoples *(inferred)*.

The Chronicle dates the age "??? P.E.". In the chats, P.E. means Pre-Elcion: the early [Thanneer Epoch](Thanneer%20Epoch.md), when the universe was being formed (see [The Elcion Calendar](The%20Elcion%20Calendar.md)).

## Connections

- **Previous:** [Awakening II](Awakening%20II.md)
- **Next:** [Primordial Age II](Primordial%20Age%20II.md)
- **Key figures:** [Anthropos](../Peoples/Anthropos.md), [Architecture](../Cosmology/Architecture.md)
- **Dated by:** [The Elcion Calendar](The%20Elcion%20Calendar.md)
- **Possibly the same as:** [The Ancient Great War](The%20Ancient%20Great%20War.md) *(unconfirmed)*

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Legacy Content](../Sources/Legacy%20Content.md)
