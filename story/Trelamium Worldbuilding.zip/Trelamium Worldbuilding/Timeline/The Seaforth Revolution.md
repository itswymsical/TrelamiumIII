---
title: "The Seaforth Revolution"
date: 2026-10-11
type: event
status: canon
tags: [event]
aliases: ["Cthulhu's Revolution"]
---

# The Seaforth Revolution

*Denied the throne of Seaforth, Cthulhu revolts, discovers Apothos, and turns the revolt into the Assailant Crusade.*

1. [Cthulhu](../Characters/Cthulhu.md) is half commoner: his mother was a commoner, his father the king.
2. The king dies of an illness, and a story spreads that Cthulhu killed him.
3. The [Seaforth Nobility](../Factions/Seaforth%20Nobility.md) refuses him the throne because of his common blood.
4. He starts a revolution and, during it, discovers [Apothos](../Magick%20and%20Systems/Apothos.md).
5. Taking [Seaforth](../Realms/Seaforth.md) is no longer enough. In his words, humanity and all beings must be controlled because their own interpretations elude them from the truth.
6. The revolt becomes the [Assailant Crusade](../Factions/The%20Assailant%20Crusade.md).

## Connections

- **Place:** [Seaforth](../Realms/Seaforth.md)
- **Led by:** [Cthulhu](../Characters/Cthulhu.md)
- **Against:** [Seaforth Nobility](../Factions/Seaforth%20Nobility.md)
- **Discovered:** [Apothos](../Magick%20and%20Systems/Apothos.md)
- **Became:** [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
