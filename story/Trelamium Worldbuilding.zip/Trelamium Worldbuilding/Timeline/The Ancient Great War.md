---
title: "The Ancient Great War"
date: 2026-10-11
type: event
status: concept
tags: [event]
aliases: ["The Great War"]
---

# The Ancient Great War

*A great war of the old history. The Lore Bible says its dead became the Corruption and the Crimson; when it happened and who fought it are open.*

The Lore Bible says [Fullbone](../Characters/Fullbone.md) turned the dead of an ancient great war into biomes, [The Corruption](../Realms/The%20Corruption.md) and [The Crimson](../Realms/The%20Crimson.md).

The August 2025 chats describe a transition era leading up to the Great War. The other worlds had given up on Terraria, and the [Archivers](../Peoples/Archivers.md) rekindled its survival. At the same time Apothos, which its first followers called the Void Hymn, was growing out of order, and the [Void Whisperers](../Factions/The%20Void%20Whisperers.md) were helping spread [Cthulhu](../Characters/Cthulhu.md)'s influence to the other worlds.

## Connections

- **Dead used by:** [Fullbone](../Characters/Fullbone.md)
- **Became:** [The Corruption](../Realms/The%20Corruption.md), [The Crimson](../Realms/The%20Crimson.md)
- **Led up to by:** the rise of [Apothos](../Magick%20and%20Systems/Apothos.md), the [Void Whisperers](../Factions/The%20Void%20Whisperers.md)
- **Candidates:** [Primordial Age I](Primordial%20Age%20I.md), [The Man and Monster War](The%20Man%20and%20Monster%20War.md) *(unconfirmed)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
