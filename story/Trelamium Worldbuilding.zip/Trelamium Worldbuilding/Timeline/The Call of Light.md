---
title: "The Call of Light"
date: 2026-10-11
type: event
status: concept
tags: [event]
---

# The Call of Light

*An event in the old history after which Yakvala lost faith in the future of the worlds. Its year isn't set.*

In the August 2025 version of [Yakvala](../Characters/Yakvala.md)'s story, the worlds were still working together and his mechanical creations were benevolent protectors until the Call of Light. After it, he lost faith in the future of the worlds and was corrupted by [Apothos](../Magick%20and%20Systems/Apothos.md).

## Connections

- **Broke:** [Yakvala](../Characters/Yakvala.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
