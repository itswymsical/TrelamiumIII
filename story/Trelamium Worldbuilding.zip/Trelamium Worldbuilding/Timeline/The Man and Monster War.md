---
title: "The Man and Monster War"
date: 2026-10-11
type: event
status: concept
tags: [event]
---

# The Man and Monster War

*A war between the realms of men and the "monster"-harboring worlds, during which Queen Flaropha tortured Yakvala into madness.*

In the September 2026 version, [Yakvala](../Characters/Yakvala.md) lost his mind during this war after [Queen Flaropha](../Characters/Queen%20Flaropha.md) tortured him, then turned the mechs into what they are in the game. The August 2025 notes set up the sides: Flaropha, aided by the [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md), set out to destroy the less "divine" worlds, betraying [The Underworld](../Realms/The%20Underworld.md), [Archaea](../Realms/Archaea.md), [Seaforth](../Realms/Seaforth.md) and the other worlds that harbored "monsters".

## Connections

- **Sides:** [Excellia](../Realms/Excellia.md) against the [Monster Empire](../Factions/The%20Monster%20Empire.md) *(inferred)*
- **Key figures:** [Queen Flaropha](../Characters/Queen%20Flaropha.md), [Yakvala](../Characters/Yakvala.md), [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md)
- **Possibly the same as:** [The Ancient Great War](The%20Ancient%20Great%20War.md) *(unconfirmed)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
