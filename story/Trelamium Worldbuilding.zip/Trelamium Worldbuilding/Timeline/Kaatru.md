---
title: "Kaatru"
date: 2026-10-11
type: era
status: canon
tags: [era]
aliases: ["Age of Air"]
---

# Kaatru

*The Age of Air, which began after Bhoomi ended and a new calendar was adopted. It led into Neruppu, the present.*

## Connections

- **Previous:** [Bhoomi](Bhoomi.md)
- **Next:** [The Present Age](The%20Present%20Age.md), called Neruppu

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
