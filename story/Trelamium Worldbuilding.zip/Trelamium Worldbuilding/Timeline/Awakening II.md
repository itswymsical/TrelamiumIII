---
title: "Awakening II"
date: 2026-10-11
type: era
status: canon
tags: [era]
---

# Awakening II

*Life emerges to experience. One species names itself Anthropos, and its quality hardens into a Chrysalis.*

Life emerges from the quality of the earth with one function: to Experience. Rock meets water, water meets organism, organism meets kin, kin meets [Qualia](../Cosmology/Qualia.md). One species organizes itself into something intelligent, gives itself qualities, and names itself [Anthropos](../Peoples/Anthropos.md). They create language, nations, technology and shared understanding. As they experience, their quality hardens into a [Chrysalis](../Cosmology/Chrysalis.md).

## Connections

- **Previous:** [Awakening I](Awakening%20I.md)
- **Next:** [Primordial Age I](Primordial%20Age%20I.md)
- **Key figures:** [Anthropos](../Peoples/Anthropos.md), [Qualia](../Cosmology/Qualia.md), [Chrysalis](../Cosmology/Chrysalis.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
