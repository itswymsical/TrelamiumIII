---
title: "Awakening I"
date: 2026-10-11
type: era
status: canon
tags: [era]
aliases: ["The Eruption"]
---

# Awakening I

*The Vault erupts. Light and dark seed esse and give things quality.*

The spirits of light and dark erupt from [The Vault](../Cosmology/The%20Vault.md) under an unspoken condition, releasing kinetic energy across actuality. They seed themselves into [Esse](../Cosmology/Esse.md) and give things [Quality](../Cosmology/Quality.md). In the image of light, [Luminance](../Cosmology/Luminance.md) renders [Illuminance](../Cosmology/Illuminance.md); in the silhouette of darkness, [Trelamium](../Cosmology/Trelamium.md) produces [Architecture](../Cosmology/Architecture.md).

## Connections

- **Next:** [Awakening II](Awakening%20II.md)
- **Key figures:** [The Vault](../Cosmology/The%20Vault.md), [Luminance](../Cosmology/Luminance.md), [Trelamium](../Cosmology/Trelamium.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
