---
title: "Primordial Age II"
date: 2026-10-11
type: era
status: canon
tags: [era]
---

# Primordial Age II

*The Sources intervene. Luminance and Trelamium each send a vessel to earth while the Anthropos abandon their natural roots.*

[Luminance](../Cosmology/Luminance.md) sees the destruction of the Anthropos and sends the [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md) to moderate their wars. [Trelamium](../Cosmology/Trelamium.md) sends the [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md). The light's vessel shines through the Anthropos' [Architecture](../Cosmology/Architecture.md); the dark's vessel plants seeds within it.

Meanwhile the [Sequela](../Cosmology/Sequela.md) of the Anthropos sprawls beyond containment. Man embraces its own structure, abandons its natural roots, outsources to lower deities and profanes the gifts of luminance.

## Connections

- **Previous:** [Primordial Age I](Primordial%20Age%20I.md)
- **Next:** [Primordial Age III](Primordial%20Age%20III.md)
- **Key figures:** [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md), [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md), [Sequela](../Cosmology/Sequela.md)
- **Likely contains:** [The Anthropic Revolution](The%20Anthropic%20Revolution.md) *(inferred)*

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
