---
title: "The Anthropic Revolution"
date: 2026-10-11
type: event
status: concept
tags: [event]
aliases: ["The Revolution"]
---

# The Anthropic Revolution

*The Anthropos abandon their old framework of understanding and work magick through the language of alchemy, producing dark forces, grimoires and new magick. Working name.*

The Lore Bible describes this without a name; "Anthropic Revolution" is a placeholder. The [Anthropos](../Peoples/Anthropos.md) abandoned their old framework of understanding and began working magick through the language and symbolism of [Alchemy](../Magick%20and%20Systems/Alchemy.md). The shift produced dark forces, grimoires and new types of magick. The [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) formed after it.

This map places it in [Primordial Age II](Primordial%20Age%20II.md), which describes the same turn: man began "to embrace its own structure, abandoning its natural roots" *(inferred)*.

## Connections

- **Carried out by:** [Anthropos](../Peoples/Anthropos.md)
- **Produced:** [Alchemy](../Magick%20and%20Systems/Alchemy.md), and likely [Apothos](../Magick%20and%20Systems/Apothos.md) *(inferred)*
- **Led to:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Era:** [Primordial Age II](Primordial%20Age%20II.md) *(inferred)*

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
