---
title: "The Elcion Calendar"
date: 2026-10-11
type: calendar
status: canon
tags: [calendar]
aliases: ["P.E.", "E.", "Pre-Elcion", "Elcion"]
---

# The Elcion Calendar

*The old dating system: P.E. (Pre-Elcion) for the early Thanneer Epoch, when the universe was being formed, and E. (Elcion) for its middle and late stretches.*

- **P.E., Pre-Elcion:** the early [Thanneer Epoch](Thanneer%20Epoch.md), when the universe was being formed.
- **E., Elcion:** the middle and late Thanneer Epoch.

The chats also say [Bhoomi](Bhoomi.md) ended in Elcion 3534 (or simply "year 3534"), after which people adopted a new calendar and [Kaatru](Kaatru.md) began. The Chronicle dates [Primordial Age I](Primordial%20Age%20I.md) "??? P.E.", which fits a Pre-Elcion date.

## Connections

- **Dates:** [Thanneer Epoch](Thanneer%20Epoch.md), [Primordial Age I](Primordial%20Age%20I.md)
- **Ended with:** [Bhoomi](Bhoomi.md), in Elcion 3534

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
