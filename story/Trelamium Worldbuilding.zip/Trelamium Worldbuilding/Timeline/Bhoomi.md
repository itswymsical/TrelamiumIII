---
title: "Bhoomi"
date: 2026-10-11
type: era
status: canon
tags: [era]
---

# Bhoomi

*The second age, named for earth. It ended in Elcion 3534, after which a new calendar was adopted.*

## Connections

- **Previous:** [Thanneer Epoch](Thanneer%20Epoch.md)
- **Next:** [Kaatru](Kaatru.md)
- **Dated by:** [The Elcion Calendar](The%20Elcion%20Calendar.md)

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
