---
title: "Primordial Age III"
date: 2026-10-11
type: era
status: canon
tags: [era]
---

# Primordial Age III

*A group of men forms the Church of Apathos, practitioners of apathos magick.*

The Chronicle names the group the Church of Apathos. This map treats it as [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md); see that note. Its members practice [Apothos](../Magick%20and%20Systems/Apothos.md) (spelled "apathos" in the Chronicle).

## Connections

- **Previous:** [Primordial Age II](Primordial%20Age%20II.md)
- **Next:** [Revelation](Revelation.md)
- **Key figures:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
