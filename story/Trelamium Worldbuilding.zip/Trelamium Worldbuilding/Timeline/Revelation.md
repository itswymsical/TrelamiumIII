---
title: "Revelation"
date: 2026-10-11
type: era
status: canon
tags: [era]
aliases: ["Revelation I-IV"]
---

# Revelation

*The Church seeks the end of wanting. One member gives everything away, Iniki fits the emptied vessel, and Trelamium gains its deity.*

- **I.** The Church does not worship the dark; it worships the end of wanting. Studying [Architecture](../Cosmology/Architecture.md), its members find that every wound of the Anthropos begins with [Quality](../Cosmology/Quality.md) (difference, desire, memory) and seek to unmake it.
- **II.** One member completes the rite. He gives away his name, then his history, then the ache beneath his history, until he is "a silhouette with no one inside it."
- **III.** [Iniki](../Characters/Iniki.md), which had waited since [The Vault](../Cosmology/The%20Vault.md) for a form that would not resist it, enters. This is fit, not possession. Trelamium has its deity: the [Trelamium God](../Characters/The%20Trelamium%20God.md).
- **IV.** He walks toward the Vault to close it again.

## Connections

- **Previous:** [Primordial Age III](Primordial%20Age%20III.md)
- **Next:** [The Present Age](The%20Present%20Age.md)
- **Key figures:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md), [Iniki](../Characters/Iniki.md), [The Trelamium God](../Characters/The%20Trelamium%20God.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
