---
title: "Farming Overhaul"
date: 2026-10-11
type: system
status: canon
tags: [system, alchemy]
---

# Farming Overhaul

*The mod's reworked farming, which supplies alchemy's inputs. The player meets it through Silvian's garden.*

Farming is introduced in character rather than by tutorial. [Silvian's First Job](../Jobs/Silvian's%20First%20Job.md) asks for **seed beds**, **magnolias**, which expedite growth, and **salt** for the soil. Each is an input to the overhaul, and magnolias and salt also feed [alchemy](../Alchemy%20System.canvas).

## What exists

- **Seed beds** come in dirt, mud, sand and ash. They plant food, herbs and flowers and grow plants five times faster than normal soil and planter boxes. Herbs placed on one are protected from being cut.
- **Herbs** include daybloom, moonglow, blinkroot, deathweed, waterleaf, fireblossom and shiverthorn.
- **Magnolia** is an alchemy plant, alkaline and catalytic, leaning Harmony and Vital.
- **Salt** comes as rock salt, pure salt and frigorific salt, and is a reagent in brewing.
- **Food and flowers:** a wide set of crops and foods, and a flower satchel that catalogs flowers.

## Connections

- **Introduced by:** [Silvian's First Job](../Jobs/Silvian's%20First%20Job.md)
- **Feeds:** [Alchemy System](../Alchemy%20System.canvas)
- **Shown through:** [Silvian](../Characters/Silvian.md)
- **Threatened by:** [Slimes](../Peoples/Slimes.md), who trampled Silvian's first seed beds

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
