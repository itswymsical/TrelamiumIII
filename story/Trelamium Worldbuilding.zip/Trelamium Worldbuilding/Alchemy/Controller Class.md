---
title: "Controller Class"
date: 2026-10-11
type: system
status: canon
tags: [system, alchemy]
---

# Controller Class

*The chemical weapon class built on alchemy: controlled spatial damage and crowd control. Implemented.*

Controller weapons release chemicals that afflict enemies over time rather than dealing a single hit. They draw on the same principles and temperaments as [alchemy](../Alchemy%20System.canvas), so the class is alchemy turned into combat.

## What a controller weapon shows

Each weapon lists, under its damage line, the stats of its chemical release:

- **Damage per second** of the element it afflicts with.
- **Reaction chance** and **reaction damage**: elements can react when they meet on a target.
- **Duration** of the affliction.
- **Concentration** and **catalysis**, which feed the reactions.

## Modifiers

Releases roll modifiers drawn from alchemy's own vocabulary: the six temperaments (acidic, alkaline, volatile, kinetic, catalytic, inert), the strengths diluted, concentrated and saturated, and the principles. The principle modifiers that are written out so far:

- **Vital:** reactions heal you for a share of the damage they deal.
- **Specular:** reactions are likelier on targets with more concentration.
- **Martial:** reactions deal more damage for each other element on the target.
- **Harmonious:** hits also afflict nearby enemies at reduced strength.
- **Baneful:** reactions lower the target's defense for a few seconds.

Thermal weapons roll their own set (combustible and others).

## Connections

- **Built on:** [Alchemy System](../Alchemy%20System.canvas)
- **Lore root:** [Alchemy](../Magick%20and%20Systems/Alchemy.md)
- **Used by:** [The Hero](../Characters/The%20Hero.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
