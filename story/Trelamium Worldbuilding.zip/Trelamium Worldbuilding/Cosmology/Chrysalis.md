---
title: "Chrysalis"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
---

# Chrysalis

*The shell that Anthropos quality hardened into as experience shaped it.*

In [Awakening II](../Timeline/Awakening%20II.md), once the [Anthropos](../Peoples/Anthropos.md) became self-sufficient and structured, the [Quality](Quality.md) in their [Esse](Esse.md) hardened. Each experience shifted it, and it began "defining itself into a Chrysalis."

## Connections

- **Formed by:** [Anthropos](../Peoples/Anthropos.md)
- **Made of:** [Quality](Quality.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
