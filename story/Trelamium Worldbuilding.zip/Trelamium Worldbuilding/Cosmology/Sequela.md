---
title: "Sequela"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Sequelae"]
---

# Sequela

*A lingering cultural or psychological pathology left by collective trauma. In the Chronicle, it is the chaos the Anthropos fell into after leaving their natural roots.*

**se·que·la** /sɪˈkwɛlə/, noun, plural *sequelae*. A philosophical and psychedelic neologism:

> A lingering cultural or psychological pathology resulting from a collective historical trauma or evolutionary shift; specifically, the modern socio-political conditions arising from humanity's historical separation from the shamanic, nomadic lifestyle.

In [Primordial Age II](../Timeline/Primordial%20Age%20II.md), "the sequela of Anthropos had sprawled into such chaos it could no longer be contained." Man embraced its own structure, abandoned its natural roots, outsourced to lower deities and profaned the gifts of [Luminance](Luminance.md).

## Connections

- **Afflicts:** [Anthropos](../Peoples/Anthropos.md)
- **Arises in:** [Primordial Age II](../Timeline/Primordial%20Age%20II.md)
- **Leads toward:** [The Anthropic Revolution](../Timeline/The%20Anthropic%20Revolution.md) *(inferred)*

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
