---
title: "Luminance"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Light", "Source of Light", "Spirit of Light"]
---

# Luminance

*The Source of light. It rendered Illuminance and sent a vessel to moderate the wars of the Anthropos.*

One of the two ancient spirits released from [The Vault](The%20Vault.md). In the image of light it rendered [Illuminance](Illuminance.md): everything emergent and natural.

In [Primordial Age II](../Timeline/Primordial%20Age%20II.md), Luminance saw the Anthropos destroying each other and sent the [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md) to earth. That vessel chose to shine through the [Architecture](Architecture.md) the Anthropos had built. In the same era the Anthropos turned to their own structures, profaning "the natural gifts of luminance".

Together with [Trelamium](Trelamium.md), Luminance is the cosmic baseline: "basically God and the universe". Explanations of magick, Anthropos psychology and natural behavior all build on the pair, and the gods of the older lore become [Demiurges](Demiurges.md) operating within them.

## Connections

- **Origin:** [The Vault](The%20Vault.md)
- **Renders:** [Illuminance](Illuminance.md)
- **Sent:** [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md)
- **Counterpart:** [Trelamium](Trelamium.md)
- **Profaned by:** [Anthropos](../Peoples/Anthropos.md)
- **Frames:** [Demiurges](Demiurges.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
