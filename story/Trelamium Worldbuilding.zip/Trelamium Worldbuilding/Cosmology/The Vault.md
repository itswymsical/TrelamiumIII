---
title: "The Vault"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Vault of Potential Energy"]
---

# The Vault

*The vault of potential energy where the spirits of light and dark festered before anything had quality.*

In the beginning, the ancient spirits of light and dark festered in the Vault as pure potential energy. Under a condition that is never spoken, it erupted and released kinetic energy across actuality ([Awakening I](../Timeline/Awakening%20I.md)). Light and dark seeded themselves into [Esse](Esse.md), and from then on things had [Quality](Quality.md).

Because both essences came out of one ruptured source, everything in actuality carries light, dark, or both.

The Vault is also where the story is headed. The [Trelamium God](../Characters/The%20Trelamium%20God.md) walks toward it "to close it again", and the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) wants to make a new Vault within itself. [Iniki](../Characters/Iniki.md) carries it as "the dark's oldest memory", the place where nothing had yet been given quality.

## Connections

- **Released:** [Luminance](Luminance.md) (light) and [Trelamium](Trelamium.md) (dark)
- **Event:** [Awakening I](../Timeline/Awakening%20I.md)
- **Sought by:** [The Trelamium God](../Characters/The%20Trelamium%20God.md), [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Remembered by:** [Iniki](../Characters/Iniki.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md)
