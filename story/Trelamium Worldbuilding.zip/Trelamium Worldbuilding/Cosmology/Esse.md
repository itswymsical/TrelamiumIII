---
title: "Esse"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
---

# Esse

*The fabric of being. Light and dark seeded themselves into it, which gave things quality.*

Latin for "to be". In [Awakening I](../Timeline/Awakening%20I.md), light and dark seeded themselves into the fabric of esse, giving things [Quality](Quality.md). Anything with the esse of the [Anthropos](../Peoples/Anthropos.md) carries patterns of [Architecture](Architecture.md).

## Connections

- **Seeded by:** [Luminance](Luminance.md) and [Trelamium](Trelamium.md)
- **Gives rise to:** [Quality](Quality.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md)
