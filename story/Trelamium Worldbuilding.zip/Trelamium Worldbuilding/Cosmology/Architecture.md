---
title: "Architecture"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
---

# Architecture

*Built, imposed structure. It is the dark's product, and the Anthropos built it everywhere: in thought, science, technology and nations.*

In the silhouette of darkness, the eruption of [The Vault](The%20Vault.md) produced architecture. It means any designed structure: buildings, but also language, nations, ideology, science and technology.

The [Anthropos](../Peoples/Anthropos.md) became its great builders. By [Primordial Age I](../Timeline/Primordial%20Age%20I.md) they had divided themselves so many times that the walls of their own architecture were nearly all they shared: "They have built themselves a home they are free to traverse, inside."

Both Sources answered it. The [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md) shines through architecture, and the [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md) plants seeds within it. The [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) studied architecture until they decided every wound began with [Quality](Quality.md). The [Trelamium God](../Characters/The%20Trelamium%20God.md) would fold every quality "into the silence of structure": architecture with nothing inside it.

## Connections

- **Produced by:** [Trelamium](Trelamium.md), through [Silhouettes](Silhouettes.md)
- **Built by:** [Anthropos](../Peoples/Anthropos.md)
- **Shone through by:** [Vessel of Luminance](../Characters/Vessel%20of%20Luminance.md)
- **Seeded by:** [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md)
- **Studied by:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md)
