---
title: "Quality"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
---

# Quality

*The properties light and dark gave to things, the reason anything is distinct. The Church blames it for every wound.*

When light and dark seeded [Esse](Esse.md), things gained quality. Life emerged "from the quality of the earth". The [Anthropos](../Peoples/Anthropos.md) were the first species that could give itself qualities (language, nations, technology), and as they experienced, their quality shifted and hardened into a [Chrysalis](Chrysalis.md).

Qualities work like seeds, in a fractal pattern: light and dark gave things qualities, and things acted on them in turn. [Apothos](../Magick%20and%20Systems/Apothos.md) and everything dark grow from the dark's side of that seeding.

The wars of [Primordial Age I](../Timeline/Primordial%20Age%20I.md) divided quality itself, until shared qualities became "infinitesimal and sparse".

The [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) decided every wound begins with quality (the quality of difference, of desire, of memory) and set out to unmake it. The [Trelamium God](../Characters/The%20Trelamium%20God.md) is what remains when all of it is given away.

## Connections

- **Arises from:** [Esse](Esse.md)
- **Experienced as:** [Qualia](Qualia.md)
- **Hardens into:** [Chrysalis](Chrysalis.md)
- **Seeds:** [Apothos](../Magick%20and%20Systems/Apothos.md), on the dark's side
- **Targeted by:** [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Absent in:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Legacy Content](../Sources/Legacy%20Content.md)
