---
title: "Trelamium"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Dark Source", "Essence of Fear"]
---

# Trelamium

*The Source of dark and the essence of fear, doubt and uncertainty. It gives the mod its name and sits at the center of the Church's plan.*

The name is Latin-rooted: trepidation + essence. Trelamium is one of the two ancient spirits released from [The Vault](The%20Vault.md). In the silhouette of darkness it produced [Architecture](Architecture.md) and rendered [Silhouettes](Silhouettes.md).

In [Primordial Age II](../Timeline/Primordial%20Age%20II.md) it sent the [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md) into the earth. The light's vessel shone through the Anthropos' architecture; Trelamium's vessel planted seeds inside it.

After the rite in [Revelation](../Timeline/Revelation.md), "Trelamium had its deity": the [Trelamium God](../Characters/The%20Trelamium%20God.md), filled by [Iniki](../Characters/Iniki.md).

In the present age Trelamium also exists as a substance. When the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) dies, Assailants using [Apothos](../Magick%20and%20Systems/Apothos.md) pull its remains into a Trelamium vortex.

Together with [Luminance](Luminance.md), Trelamium is the cosmic baseline that every other power in the setting, [Demiurges](Demiurges.md) included, operates within. The story's antagonist is meant to feel divine and unholy at once: a source in the sense of everything in totality.

## Connections

- **Origin:** [The Vault](The%20Vault.md)
- **Renders:** [Silhouettes](Silhouettes.md), [Architecture](Architecture.md)
- **Sent:** [Vessel of Trelamium](../Characters/Vessel%20of%20Trelamium.md)
- **Deity:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)
- **Center of:** the plans of [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md)
- **Takes in:** the remains of the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)
- **Counterpart:** [Luminance](Luminance.md)
- **Frames:** [Demiurges](Demiurges.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
