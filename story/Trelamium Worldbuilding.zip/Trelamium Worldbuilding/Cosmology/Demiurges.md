---
title: "Demiurges"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Demiurge"]
---

# Demiurges

*Mystical, esoteric beings who take a hand in shaping a universe. Anyone who goes far enough into the world's esoterica can become one.*

Demiurges connect the cosmic baseline of [Luminance](Luminance.md) and [Trelamium](Trelamium.md) with the gods of the older lore. They exist and operate within those forces, not above them, the way Zeus or Saturn shaped a world without being its source.

- **Form follows perception.** Like thoughtforms, a demiurge's shape isn't fixed; it takes form from the expectations of whoever beholds it.
- **Anyone can climb.** Characters who go far into the world's esoterica grow powerful enough to become demiurges or gods. Ideals and perception reshape who they are, and the deeper someone goes, the more it changes what they are. The [Alchemy](../Magick%20and%20Systems/Alchemy.md) system is meant to carry the same idea.
- **Purpose sets the ceiling.** A being devoted to the material world, like [Gouhtri](../Characters/Gouhtri.md), stays below those who pursue knowledge or the infinite, like [Permafrost](../Characters/Permafrost.md) and [Pyron](../Characters/Pyron.md).

## Connections

- **Operate within:** [Luminance](Luminance.md), [Trelamium](Trelamium.md)
- **Known or likely demiurges:** [The Red God](../Characters/The%20Red%20God.md), [The Celestial Torment](../Characters/The%20Celestial%20Torment.md), [Behema](../Characters/Behema.md) *(possibly)*
- **Close to one:** [Gouhtri](../Characters/Gouhtri.md)
- **Climbing toward it:** [Permafrost](../Characters/Permafrost.md)
- **On that level:** [Pyron](../Characters/Pyron.md) *(implied)*

Sources: [Legacy Content](../Sources/Legacy%20Content.md)
