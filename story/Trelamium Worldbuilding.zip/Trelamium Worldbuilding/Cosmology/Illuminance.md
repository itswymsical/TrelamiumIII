---
title: "Illuminance"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Illuminants"]
---

# Illuminance

*What light rendered: everything emergent and natural.*

[Luminance](Luminance.md) rendered Illuminance "in the image of light". The Lore Bible calls what it rendered Illuminants. Illuminance is the natural, emergent side of reality, the opposite of imposed [Architecture](Architecture.md).

Tribalism enters the mythos when Illuminant beings begin channeling [Iniki](../Characters/Iniki.md).

## Connections

- **Rendered by:** [Luminance](Luminance.md)
- **Opposite:** [Silhouettes](Silhouettes.md)
- **Corrupted through:** [Iniki](../Characters/Iniki.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md) · [Legacy Content](../Sources/Legacy%20Content.md)
