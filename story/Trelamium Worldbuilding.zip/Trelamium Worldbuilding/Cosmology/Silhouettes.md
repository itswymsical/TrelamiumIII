---
title: "Silhouettes"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
---

# Silhouettes

*What darkness rendered: shape without light, the outline that architecture fills.*

[Trelamium](Trelamium.md) rendered Silhouettes. Where light gave things illumination, darkness gave them outline, and [Architecture](Architecture.md) grows from that outline.

The word comes back in [Revelation](../Timeline/Revelation.md). The man who completed the rite became "a silhouette with no one inside it", the one form [Iniki](../Characters/Iniki.md) could fit.

## Connections

- **Rendered by:** [Trelamium](Trelamium.md)
- **Produces:** [Architecture](Architecture.md)
- **Opposite:** [Illuminance](Illuminance.md)
- **Echoed in:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md)
