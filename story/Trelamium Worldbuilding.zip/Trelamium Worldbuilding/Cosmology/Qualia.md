---
title: "Qualia"
date: 2026-10-11
type: cosmology
status: canon
tags: [cosmology]
aliases: ["Experience", "Experiential power"]
---

# Qualia

*Experiential power. Life exists to experience, and anything producing qualia in mass draws the watchers.*

In [Awakening II](../Timeline/Awakening%20II.md), life entered the world with one function: to Experience. Qualia is that experience as a force.

[The Hero](../Characters/The%20Hero.md) produces it in mass amounts, so the [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md) and other [Watchers](../Peoples/Watchers.md) hunt them. In game, qualia is earned as [Experiential Points](../Magick%20and%20Systems/Experiential%20Points.md).

The [Trelamium God](../Characters/The%20Trelamium%20God.md) is its opposite: "nothing in him could be called experience."

## Connections

- **Produced by:** [The Hero](../Characters/The%20Hero.md)
- **Hunted by:** [Watchers](../Peoples/Watchers.md), [Eye of Cthulhu](../Characters/Eye%20of%20Cthulhu.md)
- **Game form:** [Experiential Points](../Magick%20and%20Systems/Experiential%20Points.md)
- **Absent in:** [The Trelamium God](../Characters/The%20Trelamium%20God.md)

Sources: [Chronicle of Source](../Sources/Chronicle%20of%20Source.md) · [Lore Bible](../Sources/Lore%20Bible.md)
