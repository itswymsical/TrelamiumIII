---
title: "The Job Formula"
date: 2026-10-11
type: job
status: canon
tags: [job, design]
---

# The Job Formula

*Every interaction is a narrative payoff. The player is never walked through a fixed plot; they meet characters who act like living people, and the job falls out of what those people would really do.*

## The principle

Treat the characters the player interacts with as living creatures. Their actions and choices have to be realistic to how a person with that personality would act in that situation. The job is what happens when the player meets that person at a moment when they want something.

This closes the gap between three things that usually sit apart: the **game system** being taught, the **character's personality**, and the **narrative**. The character's voice is the tutorial, and the system is the reason the character asks.

## The beats

1. **The character notices the player.** The meeting has a reason on the character's side. They perceive the Hero and react to what they see, not to a quest flag.
2. **They probe.** The character asks questions that gauge where the player's head is at. The player answers in tone: a friendly option, a fourth-wall-breaking option, and a dark-path option. The answer is the player's voice and may color the conversation, but it does not gate the offer.
3. **They make the offer.** A plain, in-character ask: would you do a job for me? There is a good reward in it.
4. **They explain the need in their own terms.** The problem is concrete and belongs to the character, with a cause in the world and a clock if it fits (a trampled garden, a seasonal change).
5. **They list what they need, and each item points at a system.** The character justifies every item from their own knowledge and personality. The player learns what the system does because the character needs it, not because a tutorial says so.
6. **The reward pays off the relationship.** What the character gives back is something this person would plausibly give.

7. **They keep reacting while the job runs.** The character is still a person mid-job. When the player does it wrong or over-grinds, they say so in their own voice: the Merchant's [Gold Mine](Jobs.md) caps each kind of copper and he comments when a category fills up, and the Guide talks on a shorter leash because he is a talker.

## How the code carries it

A job in the mod is an ordered chain of task sets (gather, then build, then report back), a payout, and the NPC who hands it out. The task sets only count events; the job's own overrides are the **narrative layer**: what the provider says as stages turn over and when the player is doing it wrong. A job's dialogue lives in the NPC's dialogue library and its tasks and description in the Jobs localization, so the character's voice stays separate from the tracking.

## Checks for a new job

- Would this person really ask for this, in this way, for these reasons?
- Does each requested item map to a system the player is meant to meet next?
- Is the explanation in the character's voice rather than the designer's?
- Does the player's answer to the probe change anything the character says or does, even slightly?
- Does the job leave the character a person with more going on than the job?

## Worked example

[Silvian's First Job](Silvian's%20First%20Job.md) is the model. Silvian senses the Hero's qualia and probes, offers a job, and asks for seed beds, magnolias and salt, which open the farming overhaul and alchemy.

## Connections

- **Index:** [Jobs](Jobs.md)
- **Worked example:** [Silvian's First Job](Silvian's%20First%20Job.md)
- **Systems it teaches:** [Alchemy System](../Alchemy%20System.canvas), [Farming Overhaul](../Alchemy/Farming%20Overhaul.md)
- **Why characters notice the Hero:** [Qualia](../Cosmology/Qualia.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
