---
title: "Silvian's First Job"
date: 2026-10-11
type: job
status: canon
tags: [job]
aliases: ["Seed Beds and Salt", "Herbal Forager"]
---

# Silvian's First Job

*The first job the Hero can take from Silvian: gather seed beds, magnolias and salt for his garden. It is the model for [The Job Formula](The%20Job%20Formula.md).*

## How it plays

**Meeting.** The Hero encounters [Silvian](../Characters/Silvian.md). He introduces himself and asks the player's name. Behind the introduction, he has noticed the high levels of [qualia](../Cosmology/Qualia.md), the energy that marks [the Hero](../Characters/The%20Hero.md), so he asks probing questions to gauge where the player's head is at.

**The probes.**

1. **Their name.** The player gives their name, a false one, or stays silent. Silvian answers each in kind: he warms to the truth, shrugs at a lie ("or whatever your name is"), and takes silence in stride ("I ain't in it to pry").
2. **Why they're here.** He asks what a stranger is doing in these parts. The player has four answers:
   - **Trying to find my way around.** The ordinary answer. He offers to be a guide.
   - **Speedrunning.** The fourth-wall break. He has no clue what it means, but it sounds alright.
   - **Here for trouble.** The dark-path answer. He cuts the stranger some slack and warns that talk like that isn't met kindly here, then reads them as the feisty type.
   - **Silence.** He lets it go.

Whichever the player picks, Silvian then asks the same thing: would you be interested in doing a job for me? There is a good reward in it.

**The need.** If the player agrees, Silvian explains that slimes trampled his previous seed beds, and that he is trying to gather new crops before the seasonal change.

**The list:**

| Silvian asks for | His reason | System it opens |
| --- | --- | --- |
| Seed beds | Slimes trampled his old ones | [Farming Overhaul](../Alchemy/Farming%20Overhaul.md) |
| Magnolias | Their growth-expediting properties let him pick up the pace after what he lost | [Alchemy System](../Alchemy%20System.canvas), [Farming Overhaul](../Alchemy/Farming%20Overhaul.md) |
| Salt | For the soil | [Farming Overhaul](../Alchemy/Farming%20Overhaul.md), and a reagent in [Alchemy](../Magick%20and%20Systems/Alchemy.md) |

**The hand-in and payoff.** The player brings the items back, and Silvian pays the reward and says he'll need extra hands again soon, so keep in touch. At the end of his line he gives the Hero his late uncle's [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md).

## Why it works

Every ask is a gardener's ask: a problem he actually has, with a reason in his own voice. The player ends up gathering the inputs of the farming overhaul and alchemy without a tutorial saying so, and Silvian is established as a perceptive, friendly local with a garden and a clock.

## In the code today

The mod's current `HerbalForager` job (`Content/Jobs/Jobs.Silvian.cs`) is the earlier version of this job: talk to Silvian, then gather three dayblooms, two blinkroots and five magnolias, then hand them in. It pays 75 silver coins, two herb bags and a Sapling Maker, and queues the Almanac hand-off behind the completion line. The probe dialogue above is already implemented as written. The seed bed and salt version is the new design.

## Connections

- **Given by:** [Silvian](../Characters/Silvian.md)
- **Done by:** [The Hero](../Characters/The%20Hero.md)
- **Method:** [The Job Formula](The%20Job%20Formula.md)
- **Teaches:** [Alchemy System](../Alchemy%20System.canvas), [Farming Overhaul](../Alchemy/Farming%20Overhaul.md)
- **Reward leads to:** [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md)
- **Hostile slimes:** [Slimes](../Peoples/Slimes.md)

Sources: [Latest Retcons](../Sources/Latest%20Retcons.md)
