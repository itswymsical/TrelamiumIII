---
title: "Jobs"
date: 2026-10-11
type: job
status: canon
tags: [job, index]
aliases: ["Missions", "Quests"]
---

# Jobs

*The mod's missions and quests. "Mission" was the system's original name; they are jobs now. Every job is a narrative payoff, delivered by a character who behaves like a living person.*

A job is not a fixed plot the player walks through. It is a request from a character with their own personality, problems and reasons, and the player's part in it is how the world's systems get taught: each thing the character asks for points at a game system, and the character's own voice is what explains it.

How a job is built is in [The Job Formula](The%20Job%20Formula.md). Jobs that have their own note are linked below.

## Jobs in the mod

| Job | Given by | The ask | What it teaches |
| --- | --- | --- | --- |
| [Silvian's First Job](Silvian's%20First%20Job.md) (Herbal Forager) | [Silvian](../Characters/Silvian.md) | Seed beds, magnolias and salt | Farming and alchemy |
| Home Forager | [The Guide](../Characters/The%20Guide.md) | Logs and stone, then three approved rooms, then check in | Building housing for town NPCs |
| Gold Mine | The Merchant | Copper in variety: ore, bars, furniture and tools each cap out | Not grinding one item family |
| Explosive Architecture | [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md) | Bars, dud bombs, lodestone and coils, then walls | His first prototype, the W.A.L.L. |
| Crossing Over | [The Dryad](../Characters/The%20Dryad.md) | Enter Ingress, defeat the Wooden Warden, find the Library of Reverie | The Ingress arc |
| Odd Job | Wandering jobbers | Repeatable gathering: ore, timber, gems, blocks or an accessory | A steady sink for the sandbox economy |

Jobs show on the provider's board, with an indicator over their head, once their unlock condition is met (a world day, a rescued NPC, a settled arrival).

## Connections

- **Method:** [The Job Formula](The%20Job%20Formula.md)
- **First giver:** [Silvian](../Characters/Silvian.md)
- **Taught through jobs:** [Alchemy System](../Alchemy%20System.canvas), [Farming Overhaul](../Alchemy/Farming%20Overhaul.md)
- **Done by:** [The Hero](../Characters/The%20Hero.md)

Sources: [Lore Bible](../Sources/Lore%20Bible.md)
