---
title: "Creator Notes 2026-10-11"
date: 2026-10-11
tags: [source]
---

# Latest Retcons

Peoples, groups and characters from the creator's dictated notes, cleaned up and linked. Spellings taken from voice notes are flagged where unsure.

## Peoples

- [Anthropos](../Peoples/Anthropos.md)
- [Entfolk](../Peoples/Entfolk.md): Ingress creatures made of wood
- [Mud-Spirit Folk](../Peoples/Mud-Spirit%20Folk.md): Ingress beings of mud and spirit, different from the Entfolk; no name yet
- [Sea Folk](../Peoples/Sea%20Folk.md): from Seaforth
- [Archaeans](../Peoples/Archaeans.md): general term for the nation of Archaea
- [Hyperboreans](../Peoples/Hyperboreans.md): individuals from Hyperborea
- [Dryads and Druids](../Peoples/Dryads%20and%20Druids.md): one class
- [Elves](../Peoples/Elves.md): live in Sylvanwalde
- [Gleplins](../Peoples/Gleplins.md): miners of coal and resources in Sylvanwalde
- [Goblins](../Peoples/Goblins.md), [Skeletons](../Peoples/Skeletons.md), [Zombies](../Peoples/Zombies.md)
- [Watchers](../Peoples/Watchers.md): demon eyes and any eye-related creature
- [Slimes](../Peoples/Slimes.md)
- [Frost Giants](../Peoples/Frost%20Giants.md): Permafrost is the only one
- [Demons](../Peoples/Demons.md)
- [Elysians](../Peoples/Elysians.md)
- [Archivers](../Peoples/Archivers.md): ancient historians who documented world history and phenomena, including magick types
- [Living Spirits](../Peoples/Living%20Spirits.md)
- [Cephalopods](../Peoples/Cephalopods.md): octopi; Cthulhu is probably one
- [Hybrid Anthropoi](../Peoples/Hybrid%20Anthropoi.md): people mixed with other races, such as Eosforos
- [Martians](../Peoples/Martians.md)
- [Myconids](../Peoples/Myconids.md): mushroom creatures
- [Annelids](../Peoples/Annelids.md): worms; needed a scientific name
- [Sycophants](../Peoples/Sycophants.md): parasite-type creatures
- [Iniki Manifestations](../Peoples/Iniki%20Manifestations.md): darkness incarnate

## Groups

- [The Church of Apothos](../Factions/The%20Church%20of%20Apothos.md): the original cult, around Awakening II–III and the Primordial Ages; no name yet
- [The Assailant Crusade](../Factions/The%20Assailant%20Crusade.md): Cthulhu's entire empire; "Assailants" is the umbrella term
- [The Trelamium God](../Characters/The%20Trelamium%20God.md): the Iniki God; no name yet
- [Magick Practitioners](../Magick%20and%20Systems/Magick%20Practitioners.md): a role some characters play

## Assailant ranks, lowest to highest

[Fiends](../Factions/Assailant%20Ranks/Fiends.md), [Sinners](../Factions/Assailant%20Ranks/Sinners.md), [Disasters](../Factions/Assailant%20Ranks/Disasters.md), [Tragedies](../Factions/Assailant%20Ranks/Tragedies.md), [Honoraries](../Factions/Assailant%20Ranks/Honoraries.md), [The Elect](../Factions/Assailant%20Ranks/The%20Elect.md), [Paladins](../Factions/Assailant%20Ranks/Paladins.md), with the Moon Lord above them. "Corinthians" was also mentioned; where it fits is open.

## Characters and places

- [The Hero](../Characters/The%20Hero.md): the player
- [The Dryad](../Characters/The%20Dryad.md): from [Sylvanwalde](../Realms/Sylvanwalde.md) (also written Sylvan Wald), where the Elves live
- [Eosforos](../Characters/Eosforos.md): half goat, half Anthropos; works under the Assailants for Cthulhu
- [Saint Jerwin](../Characters/Saint%20Jerwin.md): practitioner of [Illuminant Magick](../Magick%20and%20Systems/Illuminant%20Magick.md) (spelling unconfirmed)
- [Pyron](../Characters/Pyron.md): demon warrior from [Chaotica](../Realms/Chaotica.md), an old term for ancient hell; rival of Permafrost
- [Permafrost](../Characters/Permafrost.md): the only frost giant; has a minion, Glacier
- [Glacier](../Characters/Glacier.md): a Hyperborean watcher, classed as a watcher
## Corrections and additions, second pass

- Spellings: [Erahoka](../Characters/Erahoka.md) (was Arahoka), [Eosforos](../Characters/Eosforos.md), [Fungore](../Characters/Fungore.md), and [Sylvanwalde](../Realms/Sylvanwalde.md) with an e.
- "Magic" is spelled **magick** in-world (retcon).
- Reverie Magic is [Illuminant Magick](../Magick%20and%20Systems/Illuminant%20Magick.md).
- The Breviary books are the books of [Reverie](../Realms/Reverie.md).
- The Alchemist Cult is the [Church of Apothos](../Factions/The%20Church%20of%20Apothos.md) (or the Church of Anthropos).
- [Silvian](../Characters/Silvian.md) (Sylvian in the notes) is the nephew of [John Substrate](../Characters/John%20Substrate.md), the greatest alchemist who ever existed: "a joke name, but also serious". After the first job he gives the Hero, he hands over the [Alchemist's Almanac](../Magick%20and%20Systems/Alchemist's%20Almanac.md), which teaches alchemy. The system is complex, so the learning continues all game.
- [Goblins](../Peoples/Goblins.md) are a whole race. One unnamed tribe opposes technology and wants power; the higher Assailants send it to raid the Hero's town as the [Goblin Army](../Factions/The%20Goblin%20Army.md). It brings the [Goblin Tinkerer](../Characters/Goblin%20Tinkerer.md) tied to a stake for execution. After the army is defeated, the Hero frees him and he joins the town.
- [Fungore](../Characters/Fungore.md) is a filler character, not part of the Crusade.
- [King Slime](../Characters/King%20Slime.md) was one blue slime, given a crown filled with Apothos magick that surged it with power. It isn't that powerful.
- [Edith](../Characters/Edith.md) is an Entfolk.
- [Laine L](../Characters/Laine%20L.md) (Lane L in the notes) is a philosopher deep into phenomenology, an Anthropos of the 1800s P.E. ("post era"). His story will be rewritten; the general idea is in his note. [Hesper](../Characters/Hesper.md) will be a significant character in the future.
- [Sylvanwalde](../Realms/Sylvanwalde.md) has three districts: the [Sylvanwalde Surface](../Realms/Sylvanwalde%20Surface.md), the [Druid's Garden](../Realms/Druid's%20Garden.md) and [Shadowmire](../Realms/Shadowmire.md), where the [Gleplins](../Peoples/Gleplins.md) live and mine. The [Elves](../Peoples/Elves.md) rule and are classist and racist, except [Dahlia](../Characters/Dahlia.md) and her son. The [Fairies](../Peoples/Fairies.md) live on the surface as second-class citizens. Dahlia, the hero of Sylvanwalde, stopped the Crusade there with her crew: a mage, [The Tamer](../Characters/The%20Tamer.md), and others.

## Third pass

- Settled: **Apothos** and the **Church of Apothos**. Silvian hands over the Almanac after his first job.
- [Sophie](../Characters/Sophie.md) is an engineer who creates gadgets and androids.
- [Sonder](../Characters/Sonder.md) is mysterious and esoteric and appears at random. The [Kraken](../Characters/Kraken.md) is a wanderer type too.
- [Argie](../Characters/Argie.md) (Argentina) is a mycologist living in the [Glowshroom Grotto](../Realms/Glowshroom%20Grotto.md), an underground microbiome that always spawns inside a random glowing mushroom biome. As a kid she wanted to learn mycology and became [John Substrate](../Characters/John%20Substrate.md)'s apprentice, inspired by him. She's about 25, [Silvian](../Characters/Silvian.md) about 24, and John was about 43 when he died. Silvian calls her a friend, and the Almanac asks him to let her know he has the book. She's a sideline character early on, giving access to [Mycology](../Magick%20and%20Systems/Mycology.md) and low-level alchemy, and becomes important later.
- Old chat logs with Gerjingle were added as a source: [Legacy Content](Legacy%20Content.md).

## Fourth pass

- The King Slime crown rework supersedes Farewynn's creation of King Slime from the 2025 notes.
- The Corruption stays Fullbone's work; the "unstable Land of Night" idea is dropped.
- Permafrost and Glacier live on a frozen mountain in [Hyperborea](../Realms/Hyperborea.md), not at Sylvanwalde's edge.
- Everything that said Apathia now says Apothos.
- The contradictions come from folding the earlier Reverie Mod's lore into Trelamium as internal world history.
- Fiend-rank troops in the Corruption and Crimson camps: the [Soma Whisperer](../Factions/Assailant%20Troops/Soma%20Whisperer.md), the [Null Herald](../Factions/Assailant%20Troops/Null%20Herald.md) and the [Echo Knight](../Factions/Assailant%20Troops/Echo%20Knight.md). They're plain combat types.

## Fifth pass

- [Archaea](../Realms/Archaea.md) is a massive, very progressive cyberpunk city ([Archaea City](../Realms/Archaea%20City.md)) with [Cactus County](../Realms/Cactus%20County.md) on its outskirts.
- The [Vespers](../Peoples/Vespers.md) live in Cactus County. They're called the cactus people but aren't cactus; they sometimes wear cactus garments. They're shadowy silhouettes with golden-yellow laser eyes, traditional and conservative, and keep away from the city because of what it has done to the land and how it treats others. Their culture centers on a form of magick still to be decided.
- [Eustace](../Characters/Eustace.md), a cowboy, is the person the Vespers respect most and the hero of Archaea. He has an unnamed apprentice.
- [Heroes of the Land](../Factions/Heroes%20of%20the%20Land.md): worlds that fought off the Assailant Crusade honor the leaders of those fights as heroes of their land. The Hero becomes the hero of Terraria, and finally the hero of reality by stopping Iniki.
- [Sophie](../Characters/Sophie.md) lives in the city and is an Elysian. She deeply respects Cactus County and Eustace, and visits without her tech, which is why the Vespers respect her most of all Archaeans.
- The [Elysians](../Peoples/Elysians.md) come from another planet, [Elysia](../Realms/Elysia.md), which the Paladin [Nisha](../Characters/Nisha.md) completely destroyed. Nisha has it out for the Anthropi, for reasons not yet recalled.

