---
title: "Lore Bible: Alchemy, Apothos & Ingress"
date: 2026-10-11
tags: [source]
---

# Lore Bible // Alchemy, Apothos & Ingress

Oct 11, 2026 · @wymsical

## Cosmology

Everything in actuality carries light, dark, or both, because both came from one ruptured source: the Vault.

- **The Vault.** In the beginning, the spirits of light and dark festered in a vault of potential energy. Under a condition that is never spoken, it erupted, and their essences spread across actuality.
- **Light** rendered **Illuminants** and everything emergent and natural.
- **Dark** rendered **Silhouettes** and architecture: built, imposed structure.
- **Trelamium.** Latin-rooted for trepidation + essence: the essence of fear, doubt and uncertainty. It is the substance at the center of the cult's plans and of the Eye of Cthulhu's fate.
- **Apothos.** A form of magic, used by Cthulhu and the Assailants. It cannot be fought with a sword or bow; it is countered by clarifying language and self-understanding.
- **Qualia.** Experiential power. Beings that produce it in mass amounts, like the player, draw the attention of watchers such as the Eye.

## The Anthropos and the alchemist cult

The alchemist cult is the true central antagonist, older and larger in scope than Cthulhu, and everything the player does with alchemy echoes its practice.

- **Anthropos** is the in-world term for humanity and anything anthropic (plural: *Anthropoi*).
- **The revolution (unnamed).** The Anthropos abandoned their old framework of understanding and began working magic through the language and symbolism of alchemy. This shift produced dark forces, grimoires and new types of magic.
- **The cult** formed after this revolution, from among the ancient Anthropos.
- **Iniki** is dark incarnate, likely created by the cult.
- **The Trelamium God (unnamed)** runs on Trelamium. It inhabits an Anthropos vessel that merges with Iniki and loses all sense of self, becoming purely operational.
- **Goal.** Not to eradicate light, but to become the subsuming overseer of reality: to fold everything back into darkness and make a new Vault within itself.
- **Relation to Cthulhu.** Cthulhu's crusade serves the same end whether he knows it or not. If he succeeds, Trelamium takes over regardless of his desires.

## Cthulhu and the Assailant Crusade

Cthulhu wants control of all realities because a noble class once denied him his own; Apothos turned that grievance into a multidimensional crusade.

**Origin in Seaforth**

1. Cthulhu is half commoner: his mother was a commoner, his father a king.
2. The king died of an illness, and a narrative spread that Cthulhu had killed him.
3. The nobility refused him the throne because of his common blood.
4. He started a revolution, and during it discovered Apothos magic.
5. Taking Seaforth was no longer enough. In his words, humanity and all beings must be controlled because their own interpretations elude them from the truth.
6. This begins the Assailant Crusade.

**The Assailants**

- Cultists, warriors and soldiers of every shape, size, race and ethnicity, scattered across Terraria and other dimensions.
- They believe the crusade holds something for them. It doesn't; Cthulhu is manipulating them.
- In game, they read as a standard villain faction. Some camp in the Corruption and Crimson in small fortresses and camps the player can fight for loot, likely with a mini-boss or two.

**The Paladins**

The top echelon of the Crusade. Four serve Cthulhu, each with private goals; he knows this and works to keep them from gaining the upper hand. The result is a five-way power struggle.

- **Fullbone** (created by the co-director): a power-hungry maniac with no morality. Responsible for the Crimson and Corruption.
- **Arahoka**
- **Nisha**
- **Callisto**

**The Eye of Cthulhu**

The literal eye of the being later fought as the Moon Lord. It is a watcher, surveying Terraria for anything producing mass amounts of qualia. The player is one, so it attacks. On its death, Assailants using Apothos pull its remains into a Trelamium vortex (cutscene implemented).

## Dimensions

Six dimensions are named; Terraria is the Crusade's first target, and Ingress is the only one that is an inner state rather than a place.

| Dimension  | What we know                                                                                                                         | Role so far                                       |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------- |
| Terraria   | The vanilla world                                                                                                                    | First dimension the Assailants target; early game |
| Ingress    | An internal state, presented as a full subworld: a fantasy forest of ligneous folk, a temple, the Wooden Warden, the Scar of Ingress | Early-game self-understanding arc                 |
| Seaforth   | Cthulhu's homeland; ruled by a nobility                                                                                              | Cthulhu's backstory                               |
| Archaea    | Not yet defined                                                                                                                      | Open                                              |
| Sylvanwald | Not yet defined                                                                                                                      | Open                                              |
| Hyperborea | Not yet defined                                                                                                                      | Open                                              |

## Early-game progression

The Eye of Cthulhu is the turning point: before it, the player learns alchemy; after it, the Dryad sends them inward to Ingress.


The dashed stage is a proposal (see Open questions); the rest is implemented or planned.

## Systems tied to the lore

The early game's spine is alchemy, then Apothos, then Ingress; each system below should teach one of those.

- **Alchemy (implemented).** Transmute items into potions and serums, turn liquids into other liquid types, craft gear. The player practices the same language the cult used, though not with the same intention.
- **Experiential points (implemented).** Earned from sandbox actions rather than kills: collecting specific items, breaking specific blocks, building certain structures, and encountering enemies, which keeps the economy from relying only on trivial repeatable acts like breaking pots, looting chests or selling. Thematically, this is qualia, the same thing the Eye hunts.
- **Skills.** Bought with experiential points. Examples: a custom dash, accessory effects, throwing the pickaxe as a boomerang. Some are implemented.
- **Elemental and chemical damage.** Damage types and boosts rooted in alchemy's chemicals and elements.
- **Controller class.** A chemical class built on controlled spatial damage and crowd control.
- **Breviary books.** Rented from Edith; teach world lore and magic types, and grant experiential points when read.
- **World NPCs (implemented).** Fully dynamic NPCs with missions and quests; they can follow the player and may fight them.

## Characters

| Character | Faction | Role | Status |
| --- | --- | --- | --- |
| The player ("the Hero") | None | Produces mass qualia; must stop the Moon Lord, then Iniki | Implemented |
| Iniki | Alchemist cult | Dark incarnate; final antagonist | Post-Moon Lord |
| Trelamium God (unnamed) | Alchemist cult | Runs on Trelamium through an Anthropos vessel fused with Iniki | Concept |
| Cthulhu / Moon Lord | Assailant Crusade | Half-commoner prince of Seaforth turned conqueror; a pawn of the larger plan | Vanilla boss |
| Eye of Cthulhu | Assailant Crusade | Watcher hunting qualia; remains taken into Trelamium | Cutscene implemented |
| Fullbone | Paladin | Amoral power-seeker; made the Crimson and Corruption | Concept |
| Arahoka | Paladin | Own agenda | Concept |
| Nisha | Paladin | Own agenda | Concept |
| Callisto | Paladin | Own agenda | Concept |
| The Dryad | Ally | After the Eye, sends the Hero inward to understand themselves | Planned dialogue |
| Wooden Warden | Ingress | Guards the gate in Ingress's temple | Planned boss |
| Edith | Breviary | Bookkeeper; lends books of lore and magic | Planned NPC |
| Fungor | Unaligned so far | Myconid boss | Implemented |
| King Slime | Unaligned so far | Reworked vanilla boss | Implemented |

## Open questions and suggested tie-ins

The biggest gap is what links Ingress to the evil-biome bosses; the suggestions below are proposals, not canon.

**Open questions**

- [ ] What is the name of the Anthropos revolution?
- [ ] What is the Trelamium God's name?
- [ ] What does the cult ultimately want with Trelamium: fuel, weapon, or the material of the new Vault?
- [ ] When was the ancient great war, who fought it, and how did Fullbone turn its dead into biomes?
- [ ] Did the cult create Apothos, or did Cthulhu find something older?
- [ ] What do Arahoka, Nisha and Callisto each want?
- [ ] What does Ingress unlock mechanically after the Warden and Breviary?

**Suggested tie-ins: Eater of Worlds and Brain of Cthulhu**

- Both are Fullbone's work. The Eater of Worlds is the soldiers' twisted souls compacted into one devouring body; the Brain of Cthulhu is grown from their blood.
- The Brain is literally Cthulhu's, a second remote organ like the Eye. Where the Eye watches, the Brain thinks through Apothos, which fits its illusion-based fight.
- An Assailant fortress in each evil biome holds the summoning ritual. Clearing the camp mini-boss gives the summon item or a lore page about Fullbone.
- On death, echo the Eye's cutscene but vary it: Fullbone's Apothos tries to reclaim the remains, and the Hero's Ingress training lets them resist. This shows the player's growth.

**Suggested direction after Ingress**

- The Dryad says Apothos can't be fought with a sword; Ingress gives the player the clarifying language to fight it. Make that a tangible unlock: a skill or alchemical rite that breaks Apothos shields or Assailant wards.
- Breviary books could point toward the evil biomes, giving the player a reason to go after Fullbone next.
- Breviary books could also hint at the other dimensions, seeding Archaea, Sylvanwald and Hyperborea for later.

