---
title: "Chronicle of Source"
date: 2026-10-11
tags: [source, scripture]
aliases: ["Trelamium: Chronicle of Source"]
---

# Trelamium: Chronicle of Source

> [!NOTE]
> In-world scripture, kept as written. The lore notes quote it by section.

## Awakening I

In the beginning, the ancient spirits of light and dark festered in a vault of potential energy. Under a condition, they erupted from the vault and released kinetic energy across actuality. The light and dark seeded themselves into the fabric of esse, giving things quality. In the image of light, it rendered Illuminance. and In the silhouette of darkness, it produced architecture.

## Awakening II

Life emerged from the quality of the earth. They begat into a world with a simple function; to Experience. And so they did, the qualities experienced actuality. The rock interacted with the water, the water with the organism, the organism with its kin, the kin with their qualia. Life began taking form, and so lifeforms became kinetic. Eventually, a particular species would organize itself into something intelligent. This species would be capable of giving itself qualities, and so naturally it did. They called themselves Anthropos. They became the crafters of their own realities creating language, nations, technology, and shared understanding. Anthropos had become self-sufficient and structured; the very quality within anthropos’ esse hardened; as the anthropos would experience, their inherent quality would shift with them. Their quality began defining itself into a Chrysalis.

## Awakening III / Primordial Age

*??? P.E*

In the Primordial Age, lived anthropos. These beings had qualic uniformity and strived to experience. The anthropos built architecture; societies, technologies, and arts. And In this age of advancement, anthropos, in the most personal sense, found themselves battling wars against one another. Conflicts and disputes over resources –over whose seed would bear the land. This created division and the anthropos became internally divided. anthropos came to it with different language, seeded with different ideology, and different narratives. The Biomes of the world also became divided, changing their structure within their domain of purity. Anthropos began looking differently, adapting different qualities. Anthropos inevitably divided themselves into another distinction. This would continue on in an endless spiral, until shared qualities became so infinitesimal and sparse against walls – that being, the walls against their own architecture. Anthropos had become so divided, yet so profoundly adaptive to the world around them. It was something in their desire to survive that drove their persistence. Whether or not that was a good thing, be it was. And so, they built Architecture. The designed structures in their thought, in their science, in their technology; patterns of rigidity were ridden across anything with the esse of anthropos. They have built themselves a home they are free to traverse, inside.

## Primordial Age II

Luminance saw the destruction of anthropos and decided to send a vessel of light. It had emerged on the Earth to moderate the qualms and wars of anthropos. Similarly, Trelamium sent a vessel into the earth. The sources chose to intervene, witnessing the profaned Nature of turmoil. The vessel of Luminance chose to shine through the architecture Anthropos had built, whilst Trelamium had chosen to plant seeds within the architecture.

The sequela of Anthropos had sprawled into such chaos it could no longer be contained. Man began to embrace its own structure, abandoning its natural roots, Outsourcing to lower deities And profaning the natural gifts of luminance.

## Primordial Age III

A group of men had formed known as the Church of Apathos.These individuals were practitioners of apathos magick.

> **se·que·la** /sɪˈkwɛlə/
> (Philosophical & Psychedelic Neologism)
> Noun (plural: sequelae)
>
> 1. A lingering cultural or psychological pathology resulting from a collective historical trauma or evolutionary shift; specifically, the modern socio-political conditions arising from humanity’s historical separation from the shamanic, nomadic lifestyle.

## Revelation I

The Church of Apathos did not worship the dark. They worshipped the end of wanting. In their long study of architecture, they found that every wound of the Anthropos began with quality: the quality of difference, of desire, of memory. And so they sought to unmake it.

## Revelation II

One among them completed the rite. He gave away his name, then his history, then the ache beneath his history, until nothing in him could be called experience. He was no longer anthropos. He was a silhouette with no one inside it.

## Revelation III

Iniki, which had waited since the vault for a form that would not resist it, entered. This was not possession, for there was no one left to possess. It was fit. Trelamium had its deity, and the deity had no will but the dark's oldest memory: the vault, where nothing had yet been given quality.

## Revelation IV

And so he walks toward the vault to close it again, with every quality of the world folded into the silence of structure.

---

Related: [Awakening I](../Timeline/Awakening%20I.md) · [Awakening II](../Timeline/Awakening%20II.md) · [Primordial Age I](../Timeline/Primordial%20Age%20I.md) · [Primordial Age II](../Timeline/Primordial%20Age%20II.md) · [Primordial Age III](../Timeline/Primordial%20Age%20III.md) · [Revelation](../Timeline/Revelation.md) · [Sequela](../Cosmology/Sequela.md)

