---
title: Legacy Content
date: 2026-10-11
tags:
  - source
---

# Legacy Content
Much of the older material comes from the team's earlier mod, Reverie Mod, whose lore is being folded into Trelamium as internal world history. That is where most of the contradictions come from. Where it conflicts with a newer decision, the newer decision wins: King Slime's Apothos crown, and Fullbone's Corruption. [Open Questions](../Open%20Questions.md) lists what's still unsettled.

## August 2025

- [Three Witches](../Factions/The%20Three%20Witches.md) ([Malicia](../Characters/Malicia.md), [Saraphine](../Characters/Saraphine.md) and [Farewynn](../Characters/Farewynn.md)), who made the souls of the [Mechanical Bosses](../Characters/The%20Mechanical%20Bosses.md). Farewynn also created King Slime in these notes, now superseded by the crown rework.
- [Dram](../Characters/Dram.md) of [Chaotica](../Realms/Chaotica.md): half Vesper, half Bone Demon, [Titan](../Characters/Titan.md)'s grandson, dating [Naka](../Characters/Naka.md). The early-game plan: the story runs in the background while the Hero stumbles into it. It includes [The Chronicles](../Magick%20and%20Systems/The%20Chronicles.md), the [Trash Beast](../Characters/The%20Trash%20Beast.md), [Fairies](../Peoples/Fairies.md) leading the Hero to loot, slime rain, and Assailant strongholds in the Corruption, the Crimson and the [Obsidian Forest](../Realms/Obsidian%20Forest.md).
- **The transition era before the Great War: the [Archivers](../Peoples/Archivers.md) rekindle Terraria, Apothos (the Void Hymn) grows, and the [Void Whisperers](../Factions/The%20Void%20Whisperers.md) aid Cthulhu. Also covered: [Yakvala](../Characters/Yakvala.md) and the mechs, [Queen Flaropha](../Characters/Queen%20Flaropha.md), the Dryads' crimes and the [Monster Empire](../Factions/The%20Monster%20Empire.md), and [Sylvanwalde](../Realms/Sylvanwalde.md)'s districts, RPG surface and great tree. Ideas for magick beyond weapons: movement, searching, shaping the world, magick-locked areas and temporary platforms.

## September 2026

- [Von Kraft](../Characters/Von%20Kraft.md). Yakvala is recast as the Elysians' lead engineer, broken in the [Man and Monster War](../Timeline/The%20Man%20and%20Monster%20War.md) by Flaropha's torture. The Call of Light's year is still unset.
-  The [Elcion Calendar](../Timeline/The%20Elcion%20Calendar.md) and the Ages ([Thanneer Epoch](../Timeline/Thanneer%20Epoch.md), [Bhoomi](../Timeline/Bhoomi.md), [Kaatru](../Timeline/Kaatru.md) and Neruppu). Light and Trelamium become the cosmic baseline, with the older gods recast as [Demiurges](../Cosmology/Demiurges.md), including [The Red God](../Characters/The%20Red%20God.md) and [The Celestial Torment](../Characters/The%20Celestial%20Torment.md). Also: the Anthropos' monolithic utopia and the first skeptics' secret society, and a planned period of worlds modeled on our 12th to 19th centuries.
- ** [Gouhtri](../Characters/Gouhtri.md) and the [Taijitons](../Peoples/Taijitons.md). The Guide dies going into hardmode, and [Saint Jerwin](../Characters/Saint%20Jerwin.md) revives him through the Shimmer. Also: the [Wall of Flesh](../Characters/Wall%20of%20Flesh.md), the [Tax Collector](../Characters/Tax%20Collector.md), and Sylvanwalde as a taiga subworld. Gerjingle's idea that the Corruption is an unstable "Land of Night" was later dropped; the Corruption stays Fullbone's work. Permafrost's mountain was placed at Sylvanwalde's edge, since moved to Hyperborea.
- Demiurges as thoughtforms. [Permafrost](../Characters/Permafrost.md) and [Glacier](../Characters/Glacier.md) split into the mage and his eye. Also: [Behema](../Characters/Behema.md) and Chaotica, and [Cumulor](../Characters/Cumulor.md) and [Aureolus](../Characters/Aureolus.md). The new bosses are Glacier, Pyron, Cumulor and the [Azolinth](../Characters/The%20Azolinth.md). "Aether", the fifth element, means "superior" or "beyond".
- [Eosforos](../Characters/Eosforos.md) as a pre-hardmode boss, a possible barbarian Assailant boss, and the Assailant rank naming that gives us [Corithian](../Characters/Corithian.md), the Supreme Fiend.

