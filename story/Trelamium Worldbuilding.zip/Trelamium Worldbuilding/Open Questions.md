---
title: "Open Questions"
date: 2026-10-11
tags: [index]
---

# Open Questions

Everything still open in one place: contradictions, spelling checks, links this map assumed, suggestions to accept or reject, and each note's open threads. The notes themselves hold only what's settled or clearly marked. Settle a question here, then update the note it points to.

Most contradictions come from folding the earlier Reverie Mod's lore into Trelamium as internal world history. When the two disagree, your newer decision wins.

## Contradictions and spelling checks

- **P.E.** The chats define P.E. as Pre-Elcion, the early Thanneer Epoch when the universe was being formed, not "post era". That clashes with [Laine L](Characters/Laine%20L.md) living in "1800 P.E.". Which calendar dates Laine, and where in the Ages do the worlds modeled on our 12th to 19th centuries fall? See [The Elcion Calendar](Timeline/The%20Elcion%20Calendar.md).
- **Iniki's origin.** The Lore Bible says Iniki was "likely created by the cult"; the Chronicle says it "had waited since the vault". The map follows the Chronicle. See [Iniki](Characters/Iniki.md).
- **Yakvala's fall.** In 2025, the Call of Light broke his faith and Apothos corrupted him, in Flaropha's favor. In 2026, Flaropha tortured him during the Man and Monster War. See [Yakvala](Characters/Yakvala.md).
- **The Dryads.** The Dryad is the Hero's ally, while the Dryads as a people were among the worst actors of the old wars. Is that tension intended? See [Dryads and Druids](Peoples/Dryads%20and%20Druids.md).
- **The Archivers.** Your notes make them ancient historians; Gerjingle's make them Terraria's rescuers who later planned to purge the demons. See [Archivers](Peoples/Archivers.md).
- **Temple of Ingress or Ligneous Fortress.** The Lore Bible says temple; the Warden's bestiary says Ligneous Fortress. See [Temple of Ingress](Realms/Temple%20of%20Ingress.md).
- **Illuminance or Illuminants.** The Chronicle says Illuminance; the Lore Bible says Illuminants. The map files both under [Illuminance](Cosmology/Illuminance.md).
- **Spellings:** the map follows the code for Silvian and Laine L.

## Older lore to reconfirm

The chats run from August 2025 to September 2026, and the 2025 material may predate the current direction:

- The early-game plan built on [The Chronicles](Magick%20and%20Systems/The%20Chronicles.md) and the [Trash Beast](Characters/The%20Trash%20Beast.md), now that Silvian's and the Dryad's jobs exist.
- The [Three Witches](Factions/The%20Three%20Witches.md): Malicia, Saraphine and Farewynn, Gerjingle's witches of Fright, Sight and Might, who made the mechs' souls.
- [Yakvala](Characters/Yakvala.md) as a remnant of the [Void Whisperers](Factions/The%20Void%20Whisperers.md).
- The [Obsidian Forest](Realms/Obsidian%20Forest.md) as the third Assailant stronghold.
- Druids needing to live on Sylvanwalde's surface.
- [Dram](Characters/Dram.md) as half Vesper, now that the [Vespers](Peoples/Vespers.md) are an Archaean people.
- [Archaea](Realms/Archaea.md) as one of the "monster" worlds Flaropha betrayed.

## Ideas without a home yet

- **Aether:** "representing the fifth element, it means superior or beyond". The Ages are named for water, earth, air and fire. Is Aether a fifth age to come, or something else? (suggestion)

## Links this map assumed

- [The Anthropic Revolution](Timeline/The%20Anthropic%20Revolution.md) happens during [Primordial Age II](Timeline/Primordial%20Age%20II.md).
- The skeptics' secret society among the early Anthropos grew into the [Church of Apothos](Factions/The%20Church%20of%20Apothos.md).
- [Cthulhu](Characters/Cthulhu.md) is a Cephalopod (the notes say "I think"), and [Cephalopods](Peoples/Cephalopods.md) live in [Seaforth](Realms/Seaforth.md).
- The [Frost Giants](Peoples/Frost%20Giants.md) come from [Hyperborea](Realms/Hyperborea.md), because [Permafrost](Characters/Permafrost.md) lives there.
- [Demons](Peoples/Demons.md) come from [Chaotica](Realms/Chaotica.md); [Bone Demons](Peoples/Bone%20Demons.md) are demons; [Titan](Characters/Titan.md) and [Naka](Characters/Naka.md) belong to Chaotica.
- [Dryads and Druids](Peoples/Dryads%20and%20Druids.md) live in the [Druid's Garden](Realms/Druid's%20Garden.md).
- [Shadowmire](Realms/Shadowmire.md) lies beneath the [Sylvanwalde Surface](Realms/Sylvanwalde%20Surface.md).
- The [Scar of Ingress](Realms/Scar%20of%20Ingress.md) opens onto [Reverie](Realms/Reverie.md).
- The [Temple of Ingress](Realms/Temple%20of%20Ingress.md) is what "was built at the heart of the Ingress caverns".
- The Assailants killed [John Substrate](Characters/John%20Substrate.md), going by the Almanac's foreword.
- [Illuminant Magick](Magick%20and%20Systems/Illuminant%20Magick.md) draws on [Luminance](Cosmology/Luminance.md), going by its name.
- The [Archivers](Peoples/Archivers.md) documented [Alchemy](Magick%20and%20Systems/Alchemy.md), [Apothos](Magick%20and%20Systems/Apothos.md) and [Illuminant Magick](Magick%20and%20Systems/Illuminant%20Magick.md).
- The [Myconids](Peoples/Myconids.md) live in Terraria's mushroom biomes.
- [Queen Flaropha](Characters/Queen%20Flaropha.md) is the queen of [Excellia](Realms/Excellia.md).
- [Eustace](Characters/Eustace.md) is a Vesper, and his people fought the Crusade off from [Archaea](Realms/Archaea.md).
- The [Man and Monster War](Timeline/The%20Man%20and%20Monster%20War.md) was fought between Excellia and the [Monster Empire](Factions/The%20Monster%20Empire.md), which includes [The Underworld](Realms/The%20Underworld.md), [Archaea](Realms/Archaea.md) and [Seaforth](Realms/Seaforth.md).
- [Gouhtri](Characters/Gouhtri.md) is one of the [Taijitons](Peoples/Taijitons.md), and his blessing comes from [Farewynn](Characters/Farewynn.md), maker of the Blessed Swordsman.
- The [Taijitons](Peoples/Taijitons.md), the chats' "ancient world Terrarians", are Anthropos.

## Found in the mod, not mapped yet

- **NPCs:** the Nerdy Slime, Shinobi, the Bodyguard, the Wandering Employer, and the Merchant's quest against the "forest investors".
- **Books:** *Corridor of Darkness*, *Annie's Diary* and *A Proclamation* are in the mod's book files but not tied to any character yet. See [Reverie](Realms/Reverie.md).




## Open threads, note by note

### Cosmology

**[The Vault](Cosmology/The%20Vault.md)**

- What was the condition that made the Vault erupt?
- Is the "new Vault" the cult wants to build the same Vault the Trelamium God walks toward, or a second one?

**[Luminance](Cosmology/Luminance.md)**

- Does Luminance act directly in the present age, or only through vessels?
- Should [The Dryad](Characters/The%20Dryad.md) or [Sylvanwalde](Realms/Sylvanwalde.md) have a tie to Luminance? Nothing says so yet.

**[Trelamium](Cosmology/Trelamium.md)**

- What does the Church want with Trelamium: fuel, a weapon, or the material of the new Vault?
- Is the substance the Source itself, or something the Source leaves behind?

**[Illuminance](Cosmology/Illuminance.md)**

- Are Illuminants beings, or the quality that natural things carry? The chats speak of "Illuminant beings".

**[Chrysalis](Cosmology/Chrysalis.md)**

- What emerges from the Chrysalis, and has it happened yet?
- Suggestion: [Ingress](Realms/Ingress.md) is about self-understanding, so the Hero's time there could be framed as working inside their own Chrysalis.

### Timeline

**[Primordial Age I](Timeline/Primordial%20Age%20I.md)**

- Are the Primordial wars the ancient great war whose dead [Fullbone](Characters/Fullbone.md) turned into biomes?

**[The Ancient Great War](Timeline/The%20Ancient%20Great%20War.md)**

- When was the war, who fought it, and how did Fullbone turn its dead into biomes?
- Is the Great War the same as the Man and Monster War?

**[Primordial Age II](Timeline/Primordial%20Age%20II.md)**

- Who are the "lower deities" the Anthropos outsourced to?

**[The Anthropic Revolution](Timeline/The%20Anthropic%20Revolution.md)**

- What is the revolution called?

**[The Seaforth Revolution](Timeline/The%20Seaforth%20Revolution.md)**

- How long before the present age did this happen?

**[The Present Age](Timeline/The%20Present%20Age.md)**

- How far is the present from the 1800s, when [Laine L](Characters/Laine%20L.md) lived?
- Where does the Goblin Army raid fall in the early-game order?

**[The Elcion Calendar](Timeline/The%20Elcion%20Calendar.md)**

- If Elcion covers only the middle and late Thanneer Epoch, how did Bhoomi end in Elcion 3534? Did the count run on past the Thanneer Epoch?
- What is the calendar adopted after Elcion 3534 called?

**[Thanneer Epoch](Timeline/Thanneer%20Epoch.md)**

- How do the Ages line up with the Chronicle's Awakenings, Primordial Age and Revelation?

**[The Call of Light](Timeline/The%20Call%20of%20Light.md)**

- What was the Call of Light, and when did it happen? The name suggests a tie to [Luminance](Cosmology/Luminance.md) (suggestion).

**[The Man and Monster War](Timeline/The%20Man%20and%20Monster%20War.md)**

- When was it fought?

### Realms

**[Ingress](Realms/Ingress.md)**

- What does Ingress unlock mechanically after the Warden and the Library?
- Is Ingress the Hero's inner state alone, or an inner world others can enter too? The Dryad was there when the seal broke.
- What was built at the heart of the caverns?

**[Temple of Ingress](Realms/Temple%20of%20Ingress.md)**

- Is the Temple the same place as the Ligneous Fortress, and which name is canon?

**[Scar of Ingress](Realms/Scar%20of%20Ingress.md)**

- What made the Scar? Since Ingress is an inner state, a wound in the Hero's own psyche would fit (suggestion).
- Who ordered the Warden to guard it?

**[Seaforth](Realms/Seaforth.md)**

- Who rules Seaforth now: the Crusade, or what is left of the nobility?

**[Archaea](Realms/Archaea.md)**

- The real-world archaea are among the oldest life on Earth. If that echo is intended, Archaea could tie to [Awakening II](Timeline/Awakening%20II.md), when life first emerged (suggestion).

**[Sylvanwalde](Realms/Sylvanwalde.md)**

- When did the Crusade come to Sylvanwalde, and how did Dahlia stop it?

**[Chaotica](Realms/Chaotica.md)**

- Is Chaotica the same place as today's Underworld, or what came before it?

**[Reverie](Realms/Reverie.md)**

- Who wrote the books Edith lends? The [Archivers](Peoples/Archivers.md) would fit (suggestion).
- Proposed in the Lore Bible: the books can point toward the evil biomes, giving the Hero a reason to go after [Fullbone](Characters/Fullbone.md) next, and hint at [Archaea](Realms/Archaea.md), [Sylvanwalde](Realms/Sylvanwalde.md) and [Hyperborea](Realms/Hyperborea.md).
- Are *Corridor of Darkness*, *Annie's Diary* and *A Proclamation* shelved in Reverie? Who wrote *Corridor of Darkness*?
- Laine's books cite Locke and Leiden, and Lincoln's proclamation is in the files. Is real-world history part of this world's past?

**[Shadowmire](Realms/Shadowmire.md)**

- Is Shadowmire underground, beneath the elves' surface? The elves looking down on those "beneath them" suggests it.

**[Druid's Garden](Realms/Druid's%20Garden.md)**

- Who lives in the Druid's Garden, and where does it sit in Sylvanwalde's hierarchy?

**[Glowshroom Grotto](Realms/Glowshroom%20Grotto.md)**

- Do the Myconids or [Fungore](Characters/Fungore.md) have anything to do with the Grotto? (suggestion)

**[Excellia](Realms/Excellia.md)**

- Is Queen Flaropha Excellia's queen?

**[Archaea City](Realms/Archaea%20City.md)**

- What is the city called?

**[Elysia](Realms/Elysia.md)**

- When was Elysia destroyed, and why?

### Peoples

**[Anthropos](Peoples/Anthropos.md)**

- Is [The Hero](Characters/The%20Hero.md) an Anthropos?
- Which peoples descend from the Primordial divisions, and which came from elsewhere?
- The chats call people "Terrarians" (the Taijitons are "ancient world Terrarians"). Is Terrarian the same as Anthropos?

**[Hybrid Anthropoi](Peoples/Hybrid%20Anthropoi.md)**

- Do hybrids get a collective name?
- Is "goat" a people of its own, such as a beastfolk, or an animal lineage?

**[Mud-Spirit Folk](Peoples/Mud-Spirit%20Folk.md)**

- Name. Options that follow the setting's Greek and Latin roots: *Pelopneuma* (Greek pēlos "clay, mud" + pneuma "spirit"), *Lutumfolk* (Latin lutum "mud, clay"), or plain *Loamkin*.

**[Sea Folk](Peoples/Sea%20Folk.md)**

- How do the Sea Folk relate to the [Cephalopods](Peoples/Cephalopods.md)? Are they one people, or two that share Seaforth?
- Was Cthulhu's commoner mother one of the Sea Folk?

**[Cephalopods](Peoples/Cephalopods.md)**

- Confirm that Cthulhu is a Cephalopod.
- Is the Moon Lord's tentacled form his natural body, or something Apothos made of him?

**[Dryads and Druids](Peoples/Dryads%20and%20Druids.md)**

- What separates a dryad from a druid?
- The 2025 chat says Druids need to live on Sylvanwalde's surface for the lore to work. Does that still hold now that they have the Druid's Garden?
- How does the Dryad, the Hero's ally, sit with her people's history?

**[Elves](Peoples/Elves.md)**

- What is the name of Dahlia's son?

**[Gleplins](Peoples/Gleplins.md)**

- Who do the Gleplins mine for? The ruling elves would fit.

**[Goblins](Peoples/Goblins.md)**

- What is the tribe called? Are there other goblin tribes, and where do they live?

**[Skeletons](Peoples/Skeletons.md)**

- A Paladin named [Fullbone](Characters/Fullbone.md) who makes biomes out of the dead seems a natural master for skeletons (suggestion).

**[Zombies](Peoples/Zombies.md)**

- Could zombies be the restless dead of [The Ancient Great War](Timeline/The%20Ancient%20Great%20War.md)? (suggestion)

**[Watchers](Peoples/Watchers.md)**

- Do all watchers serve Cthulhu, or is watching a nature they share across factions? Glacier serves Permafrost, which suggests the second.

**[Frost Giants](Peoples/Frost%20Giants.md)**

- Why is Permafrost the only frost giant? Last of a dead race, or the first of a new one?

**[Demons](Peoples/Demons.md)**

- Are demon eyes ([Watchers](Peoples/Watchers.md)) demons, or only named like them?

**[Elysians](Peoples/Elysians.md)**

- Are the Elysians Anthropi? Nisha has it out for the Anthropi and destroyed their world.
- Where did the surviving Elysians go?

**[Archivers](Peoples/Archivers.md)**

- Suggestion: the Archivers could be the in-world authors of the [Chronicle of Source](Sources/Chronicle%20of%20Source.md) and the source of [Edith](Characters/Edith.md)'s [Reverie](Realms/Reverie.md) books.

**[Living Spirits](Peoples/Living%20Spirits.md)**

- Could the Living Spirits be related to the [Mud-Spirit Folk](Peoples/Mud-Spirit%20Folk.md), or to the ancient spirits of light and dark in [The Vault](Cosmology/The%20Vault.md)? (suggestion)

**[Martians](Peoples/Martians.md)**

- Are the Martians another dimension's people, Assailant allies, or something else?

**[Sycophants](Peoples/Sycophants.md)**

- What do Sycophants feed on: their hosts' bodies, or their [Qualia](Cosmology/Qualia.md)? (suggestion)

**[Iniki Manifestations](Peoples/Iniki%20Manifestations.md)**

- Do manifestations appear before the final arc, as a hint of what is behind the Crusade?

**[Fairies](Peoples/Fairies.md)**

- Are Terraria's fairies the same people as Sylvanwalde's?

**[Quints](Peoples/Quints.md)**

- Who are the Quints?

**[Vespers](Peoples/Vespers.md)**

- What form of magick do the Vespers practice?
- Vespers look like living silhouettes. Is there a tie to the [Silhouettes](Cosmology/Silhouettes.md) darkness rendered? (suggestion)
- Is the echo with Hesper intentional?

### Factions

**[The Church of Apothos](Factions/The%20Church%20of%20Apothos.md)**

- Does the Church still exist as people in the present age, or only through the Trelamium God?
- Did the Church create Apothos, or did Cthulhu find something older? The Chronicle's "apathos magick" suggests the Church had it first.
- How do the [Void Whisperers](Factions/The%20Void%20Whisperers.md), the first followers of the Void Hymn, relate to the Church?

**[The Assailant Crusade](Factions/The%20Assailant%20Crusade.md)**

- Which other worlds has the Crusade reached?
- Who are the Supremes of the other ranks?

**[Seaforth Nobility](Factions/Seaforth%20Nobility.md)**

- Who spread the story that Cthulhu killed the king, and was it true?
- Is any of the nobility still alive?

**[The Goblin Army](Factions/The%20Goblin%20Army.md)**

- What is the tribe called?
- Which Assailant rank gives the goblins their orders?

**[The Void Whisperers](Factions/The%20Void%20Whisperers.md)**

- Are the Void Whisperers the Hymn's first followers, and how do they relate to the Church of Apothos?

**[Heroes of the Land](Factions/Heroes%20of%20the%20Land.md)**

- Do other worlds, like [Seaforth](Realms/Seaforth.md) or [Hyperborea](Realms/Hyperborea.md), have heroes of their own? (suggestion)

### Assailant ranks

**[Paladins](Factions/Assailant%20Ranks/Paladins.md)**

- What do Erahoka, Nisha and Callisto each want?

### Assailant troops

**[Soma Whisperer](Factions/Assailant%20Troops/Soma%20Whisperer.md)**

- Is "Soma" its own fiend type, or part of this one's name? Your notes say "a Soma Whisperer, a Soma".

### Characters

**[The Hero](Characters/The%20Hero.md)**

- What is the Hero's race? Anthropos by default?
- Why does the Hero produce so much more qualia than anyone else?

**[The Dryad](Characters/The%20Dryad.md)**

- How does the Dryad know about Apothos and Ingress, and why was she in Ingress when the seal broke?
- Is the Dryad tied to [Luminance](Cosmology/Luminance.md) or its vessel? (suggestion)

**[Iniki](Characters/Iniki.md)**

- The Lore Bible says Iniki was "likely created by the cult"; the Chronicle says it "had waited since the vault". The map follows the Chronicle. Which is canon?
- Are Iniki and the Trelamium God fought as one boss or two?

**[The Trelamium God](Characters/The%20Trelamium%20God.md)**

- What is his name, or the name he gave away?
- Is he the same being as the [Vessel of Trelamium](Characters/Vessel%20of%20Trelamium.md) from Primordial Age II?

**[Vessel of Luminance](Characters/Vessel%20of%20Luminance.md)**

- Who or what is the vessel, and does it survive into the present age?
- Could it be tied to [The Dryad](Characters/The%20Dryad.md), or be someone the Hero meets? (suggestion)

**[Vessel of Trelamium](Characters/Vessel%20of%20Trelamium.md)**

- Were the seeds it planted [The Church of Apothos](Factions/The%20Church%20of%20Apothos.md), or [The Anthropic Revolution](Timeline/The%20Anthropic%20Revolution.md)? (suggestion)
- Is it the same being as the [Trelamium God](Characters/The%20Trelamium%20God.md), who appears later in [Revelation](Timeline/Revelation.md)?

**[Eye of Cthulhu](Characters/Eye%20of%20Cthulhu.md)**

- What seal did the Eye hold, and who set it?

**[Fullbone](Characters/Fullbone.md)**

- What does Fullbone want?

**[Erahoka](Characters/Erahoka.md)**

- What does Erahoka want?

**[Nisha](Characters/Nisha.md)**

- Why does Nisha hate the Anthropi, and why destroy Elysia?
- What does Nisha want inside the Paladins' power struggle?

**[Callisto](Characters/Callisto.md)**

- What does Callisto want?

**[Eosforos](Characters/Eosforos.md)**

- What is his rank?

**[Saint Jerwin](Characters/Saint%20Jerwin.md)**

- Whose downward spiral does the revival start, the Guide's or Saint Jerwin's?
- Who made him a saint?

**[Pyron](Characters/Pyron.md)**

- The names set up fire against frost. What started the rivalry?

**[Wooden Warden](Characters/Wooden%20Warden.md)**

- Who ordered the Warden to guard the Scar?
- What is the Warden protecting the Hero from, or protecting from the Hero?

**[Edith](Characters/Edith.md)**

- Where do Edith's books come from? The [Archivers](Peoples/Archivers.md) would fit (suggestion).

**[King Slime](Characters/King%20Slime.md)**

- Who gave King Slime the crown, and why?

**[Silvian](Characters/Silvian.md)**

- What is Silvian's people, and where does he live?
- Does Silvian know how his uncle died?

**[John Substrate](Characters/John%20Substrate.md)**

- Why did the Assailants want John Substrate dead?
- When did he live, and did he ever cross paths with the [Church of Apothos](Factions/The%20Church%20of%20Apothos.md)?

**[Argie](Characters/Argie.md)**

- What is Argie's later role?

**[The Guide](Characters/The%20Guide.md)**

- Where did the Guide read about Apothos?

**[Laine L](Characters/Laine%20L.md)**

- Is Laine's "false light" the same thing the [Watchers](Peoples/Watchers.md) hunt, [Qualia](Cosmology/Qualia.md)? Hesper's fixed, unchanging state also echoes [Apothos](Magick%20and%20Systems/Apothos.md), which nullifies what it touches (suggestion).
- *Illuminance II* is still empty. What does it cover?

**[Hesper](Characters/Hesper.md)**

- What is Hesper's role in the future story?

**[Dahlia](Characters/Dahlia.md)**

- What is her son's name?
- Who else was in her crew?

**[The Tamer](Characters/The%20Tamer.md)**

- What is the Tamer's name, and what does she tame?

**[Sophie](Characters/Sophie.md)**

- Sophie is an Elysian engineer, as [Yakvala](Characters/Yakvala.md) was the Elysians' lead engineer long ago. Is there a link? (suggestion)

**[Sonder](Characters/Sonder.md)**

- Who is Sonder, and why does Sonder appear when it does?

**[Kraken](Characters/Kraken.md)**

- Is the Kraken a [Cephalopod](Peoples/Cephalopods.md), or from [Seaforth](Realms/Seaforth.md)? (suggestion)

**[Von Kraft](Characters/Von%20Kraft.md)**

- Who is Von Kraft, and does she appear in the game?

**[The Red God](Characters/The%20Red%20God.md)**

- How do Red and the Torment sit with Luminance and Trelamium? Are they each Source's demiurge? (suggestion)

**[Behema](Characters/Behema.md)**

- Is Behema a he or a she, and a demiurge?

**[Gouhtri](Characters/Gouhtri.md)**

- Is Gouhtri the Blessed Swordsman Farewynn created? Whose blessing does he carry?

**[Titan](Characters/Titan.md)**

- Who is Titan, and what makes him a special case?

**[Cumulor](Characters/Cumulor.md)**

- Why was Cumulor exiled?

**[The Azolinth](Characters/The%20Azolinth.md)**

- What is the Azolinth?

**[Wall of Flesh](Characters/Wall%20of%20Flesh.md)**

- Your September 16, 2026 idea: is the Wall a second Vault, where the material forms of light and dark, as biomes, get sealed away? The prehardmode evil biomes would need an angle to fit.

**[Eustace](Characters/Eustace.md)**

- What is his apprentice's name?

### Jobs

**[The Job Formula](Jobs/The%20Job%20Formula.md)**

- Does the player's answer to the probe (passing through, speedrunning, here for trouble) change anything beyond Silvian's immediate reply, such as later dialogue or how he treats the Hero? Today it never gates the offer.
- Should every provider follow all seven beats, or are some jobs (the Guide's housing job, the Merchant's Gold Mine) allowed to skip the probe?

**[Silvian's First Job](Jobs/Silvian's%20First%20Job.md)**

- The code still ships the earlier Herbal Forager job (dayblooms, blinkroots, magnolias). When the seed beds, magnolias and salt version lands, should [Silvian](Characters/Silvian.md)'s note drop the herb list too?
- What is the reward of the new version? The old one paid 75 silver, two herb bags and a Sapling Maker before the Almanac hand-off.
- Why can Silvian perceive the Hero's qualia? Is it his alchemical attunement, his uncle's teaching, or a quirk of the gardener?
- What does "salt for the soil" do in the farming overhaul, mechanically?

### Alchemy

**[Alchemy System](Alchemy%20System.canvas)**

- The alchemy philosophy and the Controller class philosophy aren't written down in the notes or the memory yet, only the rules and mechanics. What is the philosophy behind each? (You can dictate it and I'll write it into this section.)
- **Reagents.** In the code a reagent is a solute with no principle (Charcoal, Pitch, plain fish, Ice and Sand blocks). Silvian's lesson calls "salts, acids, powders" reagents, but Rock Salt, Spirit of Salt and Black Powder are authored with principles. Which is intended: change the lesson, or give the salts no principle?
- **Traits.** Oxidizer is defined but no item carries it yet. Is it planned?
- **Dewdrop Bonnet** has an item and tile but no Almanac entry (no principle, temperaments or role), and Indigo Cap has only textures so far. Should they become solutes?

**[Controller Class](Alchemy/Controller%20Class.md)**

- What is the Controller class's identity beyond "controlled spatial damage and crowd control"? Which principles and temperaments define its playstyle, and how does it fit the lore of the cult's alchemy?

### Magick and systems

**[Apothos](Magick%20and%20Systems/Apothos.md)**

- Did the Church create Apothos, or did Cthulhu find something older?

**[Illuminant Magick](Magick%20and%20Systems/Illuminant%20Magick.md)**

- What does Illuminant Magick do, and does it draw on Luminance?

**[The Chronicles](Magick%20and%20Systems/The%20Chronicles.md)**

- Is this plan still current alongside Silvian's and the Dryad's jobs? Are the Chronicles related to the [Chronicle of Source](Sources/Chronicle%20of%20Source.md)? (suggestion)
